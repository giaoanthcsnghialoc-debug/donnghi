/**
 * Util.gs – các hàm dùng chung, không phụ thuộc dữ liệu.
 */

var APP_VERSION = '0.3.0';

/** Lỗi nghiệp vụ trả về cho giao diện bằng tiếng Việt. */
function AppError(code, message, data) {
  this.code = code;
  this.message = message;
  this.data = data || null;
}
AppError.prototype = Object.create(Error.prototype);

function fail(code, message, data) {
  throw new AppError(code, message, data);
}

function assert(cond, code, message) {
  if (!cond) fail(code, message);
}

function nowIso() {
  return Utilities.formatDate(new Date(), 'Asia/Ho_Chi_Minh', "yyyy-MM-dd'T'HH:mm:ssXXX");
}

function todayStr() {
  return Utilities.formatDate(new Date(), 'Asia/Ho_Chi_Minh', 'yyyy-MM-dd');
}

function newId(prefix) {
  return prefix + '_' + Utilities.getUuid().replace(/-/g, '').slice(0, 16);
}

function bytesToHex(bytes) {
  var out = '';
  for (var i = 0; i < bytes.length; i++) {
    var b = bytes[i] & 0xff;
    out += (b < 16 ? '0' : '') + b.toString(16);
  }
  return out;
}

function hexToBytes(hex) {
  var out = [];
  for (var i = 0; i < hex.length; i += 2) {
    var v = parseInt(hex.substr(i, 2), 16);
    out.push(v > 127 ? v - 256 : v);
  }
  return out;
}

function sha256Hex(input) {
  var bytes = typeof input === 'string'
    ? Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, input, Utilities.Charset.UTF_8)
    : Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, input);
  return bytesToHex(bytes);
}

/** Chuỗi ngẫu nhiên khoảng 244 bit, dùng cho mã phiên và liên kết khôi phục. */
function randomToken() {
  return (Utilities.getUuid() + Utilities.getUuid()).replace(/-/g, '');
}

function randomPassword() {
  var chars = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
  var raw = Utilities.getUuid().replace(/-/g, '');
  var out = '';
  for (var i = 0; i < 10; i++) out += chars[parseInt(raw.substr(i * 2, 2), 16) % chars.length];
  return out + '9';
}

function escapeHtml(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function toBool(v) {
  return v === true || v === 'TRUE' || v === 'true' || v === '1' || v === 1;
}

function parseJson(s, fallback) {
  if (!s) return fallback;
  try { return JSON.parse(s); } catch (e) { return fallback; }
}

function splitList(s) {
  if (!s) return [];
  return String(s).split(/[;,]/).map(function (x) { return x.trim(); }).filter(String);
}

/** Định dạng ngày YYYY-MM-DD thành DD/MM/YYYY. */
function viDate(d) {
  if (!d) return '';
  var p = String(d).slice(0, 10).split('-');
  return p[2] + '/' + p[1] + '/' + p[0];
}

function viDateTime(iso) {
  if (!iso) return '';
  var d = new Date(iso);
  return Utilities.formatDate(d, 'Asia/Ho_Chi_Minh', 'HH:mm dd/MM/yyyy');
}

function pick(obj, keys) {
  var out = {};
  keys.forEach(function (k) { if (obj[k] !== undefined) out[k] = obj[k]; });
  return out;
}

"""Đóng gói: gộp backend thành một tệp Code.gs và chuẩn bị thư mục giao diện cho GitHub Pages.
Chạy: python3 build.py  → tạo thư mục dist/
"""
import os, shutil, glob

ROOT = os.path.dirname(os.path.abspath(__file__))
DIST = os.path.join(ROOT, 'dist')
ORDER = ['Util', 'Config', 'Db', 'Audit', 'Permissions', 'Auth', 'Users', 'LeaveCalc', 'Balance', 'Files',
         'Pdf', 'Notify', 'Leave', 'Delegation', 'Dashboard', 'Setup', 'Main']

shutil.rmtree(DIST, ignore_errors=True)
gas = os.path.join(DIST, '1_AppsScript')
os.makedirs(gas)
files = sorted(glob.glob(os.path.join(ROOT, 'backend', '*.gs')))
names = [os.path.splitext(os.path.basename(f))[0] for f in files]
assert sorted(names) == sorted(ORDER), 'Danh sách tệp backend thay đổi: ' + str(names)
with open(os.path.join(gas, 'Code.gs'), 'w', encoding='utf-8') as out:
    out.write('/**\n * HỆ THỐNG QUẢN LÝ VÀ DUYỆT ĐƠN XIN NGHỈ – mã máy chủ (Google Apps Script)\n'
              ' * Tệp gộp từ thư mục backend/. Dán toàn bộ vào tệp Code.gs của dự án Apps Script.\n */\n')
    for n in ORDER:
        out.write('\n// ======================================================================\n')
        out.write('// ' + n + '.gs\n')
        out.write('// ======================================================================\n')
        with open(os.path.join(ROOT, 'backend', n + '.gs'), encoding='utf-8') as f:
            out.write(f.read())
shutil.copy(os.path.join(ROOT, 'backend', 'appsscript.json'), gas)

pages = os.path.join(DIST, '2_GitHubPages', 'demo')
shutil.copytree(os.path.join(ROOT, 'frontend'), pages)
print('Đã tạo', DIST)

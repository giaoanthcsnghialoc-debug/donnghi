// Máy chủ thử: phục vụ giao diện + API giả lập (chạy backend thật trên Google giả lập).
const http = require('http'), fs = require('fs'), path = require('path'), vm = require('vm');
const { install } = require('./gas_mock');
const ctx = vm.createContext({}); install(ctx); ctx.globalThis = ctx;
const be = path.join(__dirname, '..', 'backend');
fs.readdirSync(be).filter(f => f.endsWith('.gs')).sort().forEach(f => vm.runInContext(fs.readFileSync(path.join(be, f), 'utf8'), ctx, { filename: f }));
ctx.setupDemo();
const root = process.argv[2];
const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.woff2': 'font/woff2', '.webmanifest': 'application/manifest+json' };
http.createServer((req, res) => {
  if (req.method === 'POST' && req.url === '/api') {
    let body = '';
    req.on('data', c => body += c);
    req.on('end', () => {
      let out;
      try { out = ctx.handleRequest(JSON.parse(body)); } catch (e) { out = { ok: false, error: { code: 'SERVER', message: String(e) } }; }
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(out));
    });
    return;
  }
  let p = decodeURIComponent(req.url.split('?')[0]);
  if (p.endsWith('/')) p += 'index.html';
  const file = path.join(root, p);
  if (!file.startsWith(root) || !fs.existsSync(file)) { res.writeHead(404); res.end('not found'); return; }
  res.writeHead(200, { 'Content-Type': types[path.extname(file)] || 'application/octet-stream' });
  fs.createReadStream(file).pipe(res);
}).listen(8099, () => console.log('ready'));

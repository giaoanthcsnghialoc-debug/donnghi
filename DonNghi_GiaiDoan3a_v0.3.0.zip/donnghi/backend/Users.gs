/**
 * Users.gs – tài khoản, hồ sơ cá nhân, ảnh chữ ký, điểm trường và tổ chuyên môn.
 */

var USER_STATUS = { ACTIVE: 'ACTIVE', LOCKED: 'LOCKED', DISABLED: 'DISABLED' };

function userNameMap() {
  var m = {};
  db_all('Users').forEach(function (u) { m[u.id] = u.fullName; });
  return m;
}

function userCampusIds(userId, onDate) {
  var d = onDate || todayStr();
  return db_filter('UserCampusAssignments', function (a) {
    return a.userId === userId && (!a.endDate || a.endDate >= d) && (!a.startDate || a.startDate <= d);
  }).map(function (a) { return a.campusId; });
}

function campusMap() {
  var m = {};
  db_all('Campuses').forEach(function (c) { m[c.id] = c; });
  return m;
}

function departmentMap() {
  var m = {};
  db_all('Departments').forEach(function (d) { m[d.id] = d; });
  return m;
}

function publicUser(u) {
  var roles = userRoles(u.id);
  var deps = departmentMap();
  return {
    id: u.id, staffCode: u.staffCode, fullName: u.fullName, username: u.username, email: u.email, phone: u.phone,
    zaloPhone: u.zaloPhone, zaloOptIn: toBool(u.zaloOptIn), positionTitle: u.positionTitle,
    departmentId: u.departmentId, departmentName: deps[u.departmentId] ? deps[u.departmentId].name : '',
    campusIds: userCampusIds(u.id), status: u.status, roles: Object.keys(roles.codes),
    adminPerms: Object.keys(roles.adminPerms), isPrimaryAdmin: roles.isPrimaryAdmin,
    themePref: u.themePref || 'auto', hasSignature: !!u.signatureFileId,
    emailOnApproved: toBool(u.emailOnApproved), mustChangePassword: toBool(u.mustChangePassword)
  };
}

/* ---------------- Hồ sơ cá nhân ---------------- */

function api_me_bootstrap(ctx) {
  var year = currentYear();
  var bal = year ? balanceSummary(ctx.user.id, year.id) : null;
  var d = activeDelegation();
  var names = userNameMap();
  return {
    user: publicUser(ctx.user),
    env: envName(),
    version: APP_VERSION,
    settings: publicSettings(),
    campuses: db_all('Campuses').filter(function (c) { return c.status !== 'DISABLED'; })
      .sort(function (a, b) { return (parseInt(a.order, 10) || 0) - (parseInt(b.order, 10) || 0); })
      .map(function (c) { return { id: c.id, name: c.name, shortName: c.shortName }; }),
    departments: db_all('Departments').filter(function (x) { return x.status !== 'DISABLED'; })
      .map(function (x) { return { id: x.id, name: x.name }; }),
    leaveTypes: db_all('LeaveTypes').filter(function (t) { return t.status !== 'DISABLED'; })
      .sort(function (a, b) { return (parseInt(a.order, 10) || 0) - (parseInt(b.order, 10) || 0); })
      .map(function (t) { return { id: t.id, name: t.name, code: t.code, deductsAnnual: toBool(t.deductsAnnual), requiresNote: toBool(t.requiresNote) }; }),
    year: year ? { id: year.id, name: year.name, startDate: year.startDate, endDate: year.endDate } : null,
    balance: bal,
    delegation: d ? { id: d.id, viceId: d.viceId, viceName: names[d.viceId], startAt: d.startAt, endAt: d.endAt } : null,
    canDecide: canDecide(ctx),
    canSubmit: canSubmitLeave(ctx),
    unread: unreadCount(ctx.user.id)
  };
}

function api_me_update(ctx, p) {
  return withLock(function () {
    var patch = pick(p, ['email', 'phone', 'zaloPhone', 'themePref']);
    if (p.zaloOptIn !== undefined) patch.zaloOptIn = p.zaloOptIn ? 'TRUE' : 'FALSE';
    if (p.emailOnApproved !== undefined) patch.emailOnApproved = p.emailOnApproved ? 'TRUE' : 'FALSE';
    if (patch.email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(patch.email)) fail('INVALID', 'Email không hợp lệ.');
    if (patch.themePref && ['light', 'dark', 'auto'].indexOf(patch.themePref) < 0) delete patch.themePref;
    var before = db_get('Users', ctx.user.id);
    var beforeCopy = pick(before, Object.keys(patch));
    var u = db_update('Users', ctx.user.id, patch, ctx.user.id);
    if (Object.keys(patch).some(function (k) { return k !== 'themePref'; })) {
      audit(ctx.user.id, 'user.update_self', 'Users', u.id, beforeCopy, patch);
    }
    return publicUser(u);
  });
}

/** Ảnh chữ ký: PNG nền trong suốt đã xóa nền trên điện thoại, tối đa 600 KB. */
function api_me_signature_upload(ctx, p) {
  var bytes = Utilities.base64Decode(String(p.pngBase64 || ''));
  if (bytes.length < 100 || bytes.length > 600 * 1024) fail('INVALID', 'Ảnh chữ ký không hợp lệ hoặc quá lớn (tối đa 600 KB).');
  if ((bytes[0] & 0xff) !== 0x89 || bytes[1] !== 0x50) fail('INVALID', 'Ảnh chữ ký phải là PNG.');
  return withLock(function () {
    var folder = folderPath('ChuKy');
    var file = folder.createFile(Utilities.newBlob(bytes, 'image/png', ctx.user.username + '_' + Date.now() + '.png'));
    var old = ctx.user.signatureFileId;
    db_update('Users', ctx.user.id, { signatureFileId: file.getId() }, ctx.user.id);
    audit(ctx.user.id, 'user.signature_upload', 'Users', ctx.user.id, { signatureFileId: old }, { signatureFileId: file.getId(), sha256: sha256Hex(bytes) });
    return true;
  });
}

/** Chỉ trả ảnh chữ ký của chính người đang đăng nhập. */
function api_me_signature_get(ctx) {
  if (!ctx.user.signatureFileId) return { pngBase64: '' };
  return { pngBase64: Utilities.base64Encode(DriveApp.getFileById(ctx.user.signatureFileId).getBlob().getBytes()) };
}

/* ---------------- Quản lý tài khoản (quản trị viên) ---------------- */

function api_users_list(ctx, p) {
  requireAdminPerm(ctx, 'users');
  return db_all('Users').map(publicUser).sort(function (a, b) { return a.fullName.localeCompare(b.fullName, 'vi'); });
}

function validateUserInput(p, existingId) {
  assert(String(p.fullName || '').trim(), 'INVALID', 'Thiếu họ và tên.');
  var username = String(p.username || '').trim().toLowerCase();
  assert(/^[a-z0-9._-]{3,40}$/.test(username), 'INVALID', 'Tên đăng nhập 3–40 ký tự, chỉ gồm chữ không dấu, số, dấu chấm, gạch.');
  var dup = findUserByUsername(username);
  if (dup && dup.id !== existingId) fail('INVALID', 'Tên đăng nhập "' + username + '" đã tồn tại.');
  if (p.staffCode) {
    var dupCode = db_find('Users', function (u) { return u.staffCode === String(p.staffCode).trim() && u.id !== existingId; });
    if (dupCode) fail('INVALID', 'Mã nhân viên "' + p.staffCode + '" đã tồn tại.');
  }
  if (p.email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(p.email)) fail('INVALID', 'Email không hợp lệ: ' + p.email);
  var roles = (p.roles || []).filter(function (r) { return ROLE[r]; });
  assert(roles.length > 0, 'INVALID', 'Chọn ít nhất một vai trò.');
  var campusIds = (p.campusIds || []).filter(function (c) { return db_get('Campuses', c); });
  if (roles.some(function (r) { return [ROLE.TEACHER, ROLE.STAFF, ROLE.LEADER, ROLE.VICE].indexOf(r) >= 0; })) {
    assert(campusIds.length > 0, 'INVALID', 'Chọn ít nhất một điểm trường công tác.');
  }
  if (p.departmentId) assert(db_get('Departments', p.departmentId), 'INVALID', 'Tổ chuyên môn không tồn tại.');
  return { username: username, roles: roles, campusIds: campusIds };
}

function createUserCore(ctx, p) {
  var v = validateUserInput(p, null);
  if (v.roles.indexOf(ROLE.PRINCIPAL) >= 0) {
    var existing = db_find('UserRoles', function (r) { return r.roleCode === ROLE.PRINCIPAL; });
    if (existing && db_get('Users', existing.userId) && db_get('Users', existing.userId).status !== 'DISABLED') {
      fail('INVALID', 'Hệ thống đã có Hiệu trưởng. Hãy vô hiệu hóa tài khoản cũ trước.');
    }
  }
  var u = db_insert('Users', {
    staffCode: String(p.staffCode || '').trim(), fullName: String(p.fullName).trim(), username: v.username,
    email: String(p.email || '').trim(), phone: String(p.phone || '').trim(), zaloPhone: String(p.zaloPhone || '').trim(),
    zaloOptIn: 'FALSE', positionTitle: String(p.positionTitle || '').trim(), departmentId: p.departmentId || '',
    status: USER_STATUS.ACTIVE, failedLogins: '0', themePref: 'auto', mustChangePassword: 'TRUE'
  }, ctx.user.id);
  var tempPassword = p.password || randomPassword();
  setUserPassword(u.id, tempPassword, ctx.user.id, true);
  v.roles.forEach(function (r) {
    db_insert('UserRoles', {
      userId: u.id, roleCode: r,
      extraPermissions: r === ROLE.ADMIN ? (p.adminPerms || []).filter(function (x) { return ADMIN_PERMS[x]; }).join(',') : '',
      isPrimaryAdmin: 'FALSE'
    }, ctx.user.id);
  });
  var today = todayStr();
  v.campusIds.forEach(function (c) {
    db_insert('UserCampusAssignments', { userId: u.id, campusId: c, startDate: today, changedBy: ctx.user.id }, ctx.user.id);
  });
  if (u.departmentId) db_insert('UserDepartmentHistory', { userId: u.id, departmentId: u.departmentId, startDate: today, changedBy: ctx.user.id }, ctx.user.id);
  if (u.positionTitle) db_insert('UserPositionHistory', { userId: u.id, positionTitle: u.positionTitle, startDate: today, changedBy: ctx.user.id }, ctx.user.id);
  audit(ctx.user.id, 'user.create', 'Users', u.id, null, publicUser(db_get('Users', u.id)));
  return { user: publicUser(db_get('Users', u.id)), tempPassword: tempPassword };
}

function api_users_create(ctx, p) {
  requireAdminPerm(ctx, 'users');
  return withLock(function () { return createUserCore(ctx, p); });
}

function api_users_update(ctx, p) {
  requireAdminPerm(ctx, 'users');
  return withLock(function () {
    var u = db_get('Users', p.id);
    if (!u) fail('NOT_FOUND', 'Không tìm thấy tài khoản.');
    var before = publicUser(u);
    if (before.isPrimaryAdmin && !isPrimaryAdmin(ctx)) fail('FORBIDDEN', 'Không được sửa tài khoản quản trị viên chính.');
    var v = validateUserInput(p, u.id);
    var today = todayStr();
    var patch = {
      staffCode: String(p.staffCode || '').trim(), fullName: String(p.fullName).trim(), username: v.username,
      email: String(p.email || '').trim(), phone: String(p.phone || '').trim(), zaloPhone: String(p.zaloPhone || '').trim(),
      positionTitle: String(p.positionTitle || '').trim(), departmentId: p.departmentId || ''
    };
    if (patch.departmentId !== u.departmentId) {
      closeOpen('UserDepartmentHistory', u.id, today, ctx.user.id);
      if (patch.departmentId) db_insert('UserDepartmentHistory', { userId: u.id, departmentId: patch.departmentId, startDate: today, changedBy: ctx.user.id }, ctx.user.id);
    }
    if (patch.positionTitle !== u.positionTitle) {
      closeOpen('UserPositionHistory', u.id, today, ctx.user.id);
      if (patch.positionTitle) db_insert('UserPositionHistory', { userId: u.id, positionTitle: patch.positionTitle, startDate: today, changedBy: ctx.user.id }, ctx.user.id);
    }
    db_update('Users', u.id, patch, ctx.user.id);
    // điểm trường
    var current = db_filter('UserCampusAssignments', function (a) { return a.userId === u.id && !a.endDate; });
    current.forEach(function (a) {
      if (v.campusIds.indexOf(a.campusId) < 0) db_update('UserCampusAssignments', a.id, { endDate: today, changedBy: ctx.user.id }, ctx.user.id);
    });
    v.campusIds.forEach(function (c) {
      if (!current.some(function (a) { return a.campusId === c; })) {
        db_insert('UserCampusAssignments', { userId: u.id, campusId: c, startDate: today, changedBy: ctx.user.id }, ctx.user.id);
      }
    });
    // vai trò (không đụng tới cờ quản trị viên chính)
    var roleRows = db_filter('UserRoles', function (r) { return r.userId === u.id; });
    roleRows.forEach(function (r) {
      if (v.roles.indexOf(r.roleCode) < 0 && !toBool(r.isPrimaryAdmin)) db_delete('UserRoles', r.id);
    });
    db_resetCache();
    v.roles.forEach(function (code) {
      var ex = db_find('UserRoles', function (r) { return r.userId === u.id && r.roleCode === code; });
      var perms = code === ROLE.ADMIN ? (p.adminPerms || []).filter(function (x) { return ADMIN_PERMS[x]; }).join(',') : '';
      if (!ex) db_insert('UserRoles', { userId: u.id, roleCode: code, extraPermissions: perms, isPrimaryAdmin: 'FALSE' }, ctx.user.id);
      else if (code === ROLE.ADMIN && !toBool(ex.isPrimaryAdmin)) db_update('UserRoles', ex.id, { extraPermissions: perms }, ctx.user.id);
    });
    db_resetCache();
    var after = publicUser(db_get('Users', u.id));
    audit(ctx.user.id, 'user.update', 'Users', u.id, before, after);
    return after;
  });
}

function closeOpen(table, userId, date, actorId) {
  db_filter(table, function (r) { return r.userId === userId && !r.endDate; })
    .forEach(function (r) { db_update(table, r.id, { endDate: date }, actorId); });
}

function api_users_setStatus(ctx, p) {
  requireAdminPerm(ctx, 'users');
  if (['ACTIVE', 'LOCKED', 'DISABLED'].indexOf(p.status) < 0) fail('INVALID', 'Trạng thái không hợp lệ.');
  return withLock(function () {
    var u = db_get('Users', p.id);
    if (!u) fail('NOT_FOUND', 'Không tìm thấy tài khoản.');
    if (userRoles(u.id).isPrimaryAdmin) fail('FORBIDDEN', 'Không được khóa quản trị viên chính.');
    db_update('Users', u.id, { status: p.status, failedLogins: '0', lockedUntil: '' }, ctx.user.id);
    if (p.status !== 'ACTIVE') revokeSessions(u.id, null);
    if (p.status === 'DISABLED') {
      var today = todayStr();
      db_filter('UserCampusAssignments', function (a) { return a.userId === u.id && !a.endDate; })
        .forEach(function (a) { db_update('UserCampusAssignments', a.id, { endDate: today }, ctx.user.id); });
    }
    audit(ctx.user.id, 'user.status_' + p.status.toLowerCase(), 'Users', u.id, { status: u.status }, { status: p.status, reason: p.reason || '' });
    return publicUser(db_get('Users', u.id));
  });
}

function api_users_resetPassword(ctx, p) {
  requireAdminPerm(ctx, 'users');
  return withLock(function () {
    var u = db_get('Users', p.id);
    if (!u) fail('NOT_FOUND', 'Không tìm thấy tài khoản.');
    if (userRoles(u.id).isPrimaryAdmin && u.id !== ctx.user.id) fail('FORBIDDEN', 'Không được đặt lại mật khẩu quản trị viên chính.');
    var temp = randomPassword();
    setUserPassword(u.id, temp, ctx.user.id, true);
    revokeSessions(u.id, null);
    audit(ctx.user.id, 'user.reset_password', 'Users', u.id);
    return { tempPassword: temp };
  });
}

function api_users_revokeAll(ctx, p) {
  requireAdminPerm(ctx, 'users');
  return withLock(function () {
    revokeSessions(p.id, null);
    audit(ctx.user.id, 'user.revoke_all_sessions', 'Users', p.id);
    return true;
  });
}

/**
 * Nhập danh sách từ Excel/CSV. Giao diện gửi lên tệp (base64); máy chủ chuyển thành Google Sheet tạm
 * qua Drive rồi đọc. Cột theo mẫu: Mã NV | Họ và tên | Tên đăng nhập | Email | Số điện thoại | Số Zalo |
 * Chức vụ | Tổ chuyên môn | Điểm trường (ngăn bởi ;) | Vai trò (ngăn bởi ;).
 * dryRun=true chỉ kiểm tra và trả về kết quả từng dòng.
 */
function api_users_import(ctx, p) {
  requireAdminPerm(ctx, 'users');
  var rows = readSpreadsheetUpload(p.fileBase64, p.fileName);
  if (rows.length < 2) fail('INVALID', 'Tệp không có dữ liệu.');
  var roleByName = {};
  Object.keys(ROLE_NAMES).forEach(function (k) { roleByName[normalizeVi(ROLE_NAMES[k])] = k; roleByName[k.toLowerCase()] = k; });
  roleByName[normalizeVi('PHT')] = 'VICE'; roleByName[normalizeVi('HT')] = 'PRINCIPAL';
  roleByName[normalizeVi('Tổ trưởng')] = 'LEADER'; roleByName[normalizeVi('GV')] = 'TEACHER'; roleByName[normalizeVi('NV')] = 'STAFF';
  var campusByName = {};
  db_all('Campuses').forEach(function (c) { campusByName[normalizeVi(c.name)] = c.id; if (c.shortName) campusByName[normalizeVi(c.shortName)] = c.id; });
  var depByName = {};
  db_all('Departments').forEach(function (d) { depByName[normalizeVi(d.name)] = d.id; });

  var results = [];
  var run = function () {
    for (var i = 1; i < rows.length; i++) {
      var r = rows[i].map(function (x) { return String(x == null ? '' : x).trim(); });
      if (!r.join('')) continue;
      var item = {
        staffCode: r[0], fullName: r[1], username: r[2], email: r[3], phone: r[4], zaloPhone: r[5], positionTitle: r[6],
        departmentId: r[7] ? depByName[normalizeVi(r[7])] || '' : '',
        campusIds: splitList(r[8]).map(function (n) { return campusByName[normalizeVi(n)]; }).filter(String),
        roles: splitList(r[9] || 'Giáo viên').map(function (n) { return roleByName[normalizeVi(n)]; }).filter(String)
      };
      var res = { line: i + 1, fullName: item.fullName, username: item.username };
      try {
        if (r[7] && !item.departmentId) fail('INVALID', 'Không có tổ "' + r[7] + '".');
        if (item.roles.indexOf(ROLE.PRINCIPAL) >= 0 || item.roles.indexOf(ROLE.ADMIN) >= 0) fail('INVALID', 'Không nhập Hiệu trưởng/Quản trị viên bằng tệp; hãy tạo riêng.');
        validateUserInput(item, null);
        if (!p.dryRun) {
          var created = createUserCore(ctx, item);
          res.tempPassword = created.tempPassword;
        }
        res.ok = true;
      } catch (e) {
        res.ok = false;
        res.error = e.message;
      }
      results.push(res);
    }
  };
  if (p.dryRun) run(); else withLock(run);
  if (!p.dryRun) audit(ctx.user.id, 'user.import', 'Users', '', null, { count: results.filter(function (x) { return x.ok; }).length });
  return results;
}

function normalizeVi(s) {
  return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/g, 'd').replace(/\s+/g, ' ').trim();
}

/** Đọc tệp .xlsx/.xls/.csv thành mảng 2 chiều. */
function readSpreadsheetUpload(b64, fileName) {
  var bytes = Utilities.base64Decode(String(b64 || ''));
  if (bytes.length > 5 * 1024 * 1024) fail('INVALID', 'Tệp quá lớn (tối đa 5 MB).');
  var name = String(fileName || 'import').toLowerCase();
  if (/\.csv$/.test(name)) {
    var text = Utilities.newBlob(bytes).getDataAsString('UTF-8').replace(/^﻿/, '');
    return Utilities.parseCsv(text);
  }
  if (!/\.(xlsx|xls)$/.test(name)) fail('INVALID', 'Chỉ nhận tệp .xlsx, .xls hoặc .csv.');
  var tmp = folderPath('TamThoi');
  var created = Drive.Files.create(
    { name: 'import_' + Date.now(), mimeType: 'application/vnd.google-apps.spreadsheet', parents: [tmp.getId()] },
    Utilities.newBlob(bytes, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', name)
  );
  try {
    var sh = SpreadsheetApp.openById(created.id).getSheets()[0];
    return sh.getDataRange().getDisplayValues();
  } finally {
    DriveApp.getFileById(created.id).setTrashed(true);
  }
}

/* ---------------- Điểm trường, tổ chuyên môn ---------------- */

function api_org_campuses_update(ctx, p) {
  requireAdminPerm(ctx, 'org');
  return withLock(function () {
    var c = db_get('Campuses', p.id);
    if (!c) fail('NOT_FOUND', 'Không tìm thấy điểm trường.');
    var patch = pick(p, ['name', 'shortName', 'address', 'order']);
    assert(String(patch.name || c.name).trim(), 'INVALID', 'Tên điểm trường không được để trống.');
    db_update('Campuses', c.id, patch, ctx.user.id);
    audit(ctx.user.id, 'org.campus_update', 'Campuses', c.id, c, patch);
    return true;
  });
}

function api_org_departments_list(ctx) {
  var names = userNameMap();
  return db_all('Departments').filter(function (d) { return d.status !== 'DISABLED'; }).map(function (d) {
    return {
      id: d.id, name: d.name, leaderUserId: d.leaderUserId, leaderName: names[d.leaderUserId] || '',
      memberCount: db_filter('Users', function (u) { return u.departmentId === d.id && u.status !== 'DISABLED'; }).length
    };
  });
}

function api_org_departments_save(ctx, p) {
  requireAdminPerm(ctx, 'org');
  return withLock(function () {
    var name = String(p.name || '').trim();
    assert(name, 'INVALID', 'Thiếu tên tổ.');
    var dup = db_find('Departments', function (d) { return normalizeVi(d.name) === normalizeVi(name) && d.id !== p.id && d.status !== 'DISABLED'; });
    if (dup) fail('INVALID', 'Đã có tổ cùng tên.');
    if (p.leaderUserId) assert(db_get('Users', p.leaderUserId), 'INVALID', 'Tổ trưởng không tồn tại.');
    var row;
    if (p.id) {
      var before = db_get('Departments', p.id);
      row = db_update('Departments', p.id, { name: name, leaderUserId: p.leaderUserId || '' }, ctx.user.id);
      audit(ctx.user.id, 'org.department_update', 'Departments', row.id, before, row);
    } else {
      row = db_insert('Departments', { name: name, leaderUserId: p.leaderUserId || '', status: 'ACTIVE' }, ctx.user.id);
      audit(ctx.user.id, 'org.department_create', 'Departments', row.id, null, row);
    }
    // Tổ trưởng phải có vai trò LEADER
    if (p.leaderUserId && !db_find('UserRoles', function (r) { return r.userId === p.leaderUserId && r.roleCode === ROLE.LEADER; })) {
      db_insert('UserRoles', { userId: p.leaderUserId, roleCode: ROLE.LEADER, extraPermissions: '', isPrimaryAdmin: 'FALSE' }, ctx.user.id);
    }
    return true;
  });
}

function api_org_departments_delete(ctx, p) {
  requireAdminPerm(ctx, 'org');
  return withLock(function () {
    var members = db_filter('Users', function (u) { return u.departmentId === p.id && u.status !== 'DISABLED'; });
    if (members.length) fail('INVALID', 'Tổ còn ' + members.length + ' thành viên. Hãy chuyển họ sang tổ khác trước.');
    var hist = db_find('UserDepartmentHistory', function (h) { return h.departmentId === p.id; });
    if (hist) {
      db_update('Departments', p.id, { status: 'DISABLED' }, ctx.user.id);  // giữ lại cho dữ liệu lịch sử
    } else {
      db_delete('Departments', p.id);
    }
    audit(ctx.user.id, 'org.department_delete', 'Departments', p.id);
    return true;
  });
}

/** Danh sách tên gọn cho các ô chọn (ví dụ chọn PHT để ủy quyền). */
function api_users_options(ctx, p) {
  if (!isPrincipal(ctx) && !isAdmin(ctx)) fail('FORBIDDEN', 'Không có quyền.');
  var role = p.role;
  return db_all('Users').filter(function (u) {
    if (u.status !== 'ACTIVE') return false;
    return !role || !!userRoles(u.id).codes[role];
  }).map(function (u) { return { id: u.id, fullName: u.fullName, positionTitle: u.positionTitle }; });
}

/** Ảnh con dấu cho người duyệt khi chèn chữ ký vào đơn tải lên (chỉ HT hoặc PHT đang được ủy quyền). */
function api_me_stamp_get(ctx) {
  if (!canDecide(ctx)) fail('FORBIDDEN', 'Không có quyền.');
  var id = setting('STAMP_FILE_ID');
  if (!id) return { pngBase64: '' };
  return { pngBase64: Utilities.base64Encode(DriveApp.getFileById(id).getBlob().getBytes()) };
}

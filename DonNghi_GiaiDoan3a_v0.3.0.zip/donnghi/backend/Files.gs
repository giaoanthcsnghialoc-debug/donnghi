/**
 * Files.gs – tải tệp lên theo từng phần, kiểm tra loại tệp, tải tệp về theo từng phần.
 * Không tạo liên kết Drive công khai. Người dùng chỉ nhận tệp qua API sau khi kiểm tra quyền.
 */

var CHUNK_RAW_BYTES = 4 * 1024 * 1024;      // mỗi phần tải về ~4 MB
var MAX_FILE_BYTES = 30 * 1024 * 1024;      // đặc tả IX.4
var MAX_LEAVE_TOTAL_BYTES = 50 * 1024 * 1024;

var ALLOWED_EXT = {
  jpg: ['image/jpeg'], jpeg: ['image/jpeg'], png: ['image/png'], webp: ['image/webp'],
  pdf: ['application/pdf'], doc: ['application/msword'],
  docx: ['application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
  txt: ['text/plain'], xls: ['application/vnd.ms-excel'],
  xlsx: ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'], csv: ['text/csv', 'text/plain', 'application/vnd.ms-excel'],
  ppt: ['application/vnd.ms-powerpoint'],
  pptx: ['application/vnd.openxmlformats-officedocument.presentationml.presentation']
};

/** Kiểm tra byte đầu tệp khớp với đuôi tệp. */
function checkMagic(ext, bytes) {
  var b = function (i) { return bytes[i] & 0xff; };
  var startsWith = function (arr) { for (var i = 0; i < arr.length; i++) if (b(i) !== arr[i]) return false; return true; };
  var zip = startsWith([0x50, 0x4b, 0x03, 0x04]);
  var ole = startsWith([0xd0, 0xcf, 0x11, 0xe0]);
  switch (ext) {
    case 'jpg': case 'jpeg': return startsWith([0xff, 0xd8, 0xff]);
    case 'png': return startsWith([0x89, 0x50, 0x4e, 0x47]);
    case 'webp': return startsWith([0x52, 0x49, 0x46, 0x46]) && b(8) === 0x57 && b(9) === 0x45;
    case 'pdf': return startsWith([0x25, 0x50, 0x44, 0x46]);
    case 'docx': case 'xlsx': case 'pptx': return zip && !zipHasMacro(bytes);
    case 'doc': case 'xls': case 'ppt': return ole;
    case 'txt': case 'csv': return !zip && !ole && !startsWith([0x4d, 0x5a]);
  }
  return false;
}

/** Tệp Office có macro chứa "vbaProject.bin" trong danh mục zip. */
function zipHasMacro(bytes) {
  var s = Utilities.newBlob(bytes.slice(0, Math.min(bytes.length, 2 * 1024 * 1024))).getDataAsString('ISO-8859-1');
  var tail = bytes.length > 2 * 1024 * 1024 ? Utilities.newBlob(bytes.slice(bytes.length - 512 * 1024)).getDataAsString('ISO-8859-1') : '';
  return s.indexOf('vbaProject.bin') >= 0 || tail.indexOf('vbaProject.bin') >= 0;
}

function assertPdf(bytes) {
  if (!checkMagic('pdf', bytes)) fail('INVALID_FILE', 'Tệp không phải PDF hợp lệ.');
}

/**
 * Tải lên từng phần. Phần đầu tạo phiên tải (uploadId), các phần sau gửi kèm uploadId.
 * purpose: 'attachment' | 'leave-source' | 'signed-pdf'
 */
function api_files_uploadChunk(ctx, p) {
  var index = parseInt(p.index, 10), total = parseInt(p.total, 10);
  if (!(index >= 0 && total >= 1 && index < total && total <= 20)) fail('INVALID', 'Thông tin tải lên không hợp lệ.');
  var name = String(p.fileName || 'tep').replace(/[\\\/:*?"<>|]/g, '_').slice(0, 120);
  var ext = (name.split('.').pop() || '').toLowerCase();
  if (!ALLOWED_EXT[ext]) fail('INVALID_FILE', 'Định dạng tệp không được phép. Chỉ nhận ảnh, PDF, Word, Excel, PowerPoint, TXT, CSV.');
  var purpose = ['attachment', 'leave-source', 'signed-pdf'].indexOf(p.purpose) >= 0 ? p.purpose : 'attachment';
  if (purpose !== 'attachment' && ['pdf', 'jpg', 'jpeg', 'png', 'webp', 'doc', 'docx'].indexOf(ext) < 0) fail('INVALID_FILE', 'Đơn tải lên phải là PDF, Word hoặc ảnh.');
  var uploadId = p.uploadId || newId('upl');
  if (!/^upl_[a-f0-9]{16}$/.test(uploadId)) fail('INVALID', 'Mã tải lên không hợp lệ.');
  var cache = CacheService.getScriptCache();
  var metaKey = 'u:' + uploadId;
  var meta = parseJson(cache.get(metaKey), null);
  if (index === 0) {
    meta = { owner: ctx.user.id, name: name, ext: ext, total: total, purpose: purpose, parts: [] };
  } else if (!meta || meta.owner !== ctx.user.id) {
    fail('INVALID', 'Phiên tải lên đã hết hạn. Vui lòng tải lại.');
  }
  var bytes = Utilities.base64Decode(String(p.dataBase64 || ''));
  if (bytes.length > CHUNK_RAW_BYTES + 1024) fail('INVALID', 'Phần tải lên quá lớn.');
  var partFile = folderPath('TamThoi').createFile(Utilities.newBlob(bytes, 'application/octet-stream', uploadId + '_' + index));
  meta.parts[index] = partFile.getId();
  cache.put(metaKey, JSON.stringify(meta), 21600);
  if (index < total - 1) return { uploadId: uploadId, done: false };
  return finishUpload(ctx, uploadId, meta, p.mimeType);
}

function finishUpload(ctx, uploadId, meta, clientMime) {
  var all = [];
  for (var i = 0; i < meta.total; i++) {
    if (!meta.parts[i]) fail('INVALID', 'Thiếu một phần tệp. Vui lòng tải lại.');
    var f = DriveApp.getFileById(meta.parts[i]);
    all = all.concat(f.getBlob().getBytes());
    f.setTrashed(true);
  }
  if (all.length > MAX_FILE_BYTES) fail('INVALID_FILE', 'Tệp vượt quá 30 MB.');
  if (!checkMagic(meta.ext, all)) fail('INVALID_FILE', 'Nội dung tệp không khớp với định dạng ' + meta.ext.toUpperCase() + ' hoặc có macro.');
  var mime = ALLOWED_EXT[meta.ext][0];
  var folder = folderPath('TamThoi');
  var file;
  var desc = JSON.stringify({ owner: ctx.user.id, purpose: meta.purpose, at: nowIso() });
  if (meta.purpose !== 'attachment' && (meta.ext === 'doc' || meta.ext === 'docx')) {
    // Word → PDF qua Google Drive
    var gdoc = Drive.Files.create({ name: meta.name, mimeType: 'application/vnd.google-apps.document', parents: [folder.getId()] },
      Utilities.newBlob(all, mime, meta.name));
    var pdfBlob = DriveApp.getFileById(gdoc.id).getAs('application/pdf');
    DriveApp.getFileById(gdoc.id).setTrashed(true);
    file = folder.createFile(pdfBlob.setName(meta.name.replace(/\.(docx?)$/i, '') + '.pdf'));
    mime = 'application/pdf';
  } else {
    file = folder.createFile(Utilities.newBlob(all, mime, meta.name));
  }
  file.setDescription(desc);
  CacheService.getScriptCache().remove('u:' + uploadId);
  return { uploadId: uploadId, done: true, fileId: file.getId(), fileName: file.getName(), mimeType: mime, size: file.getSize() };
}

/** Tệp tải lên phải do chính người này tải. purpose=null chấp nhận mọi mục đích. */
function checkUploadOwner(fileId, userId, purpose) {
  var f;
  try { f = DriveApp.getFileById(fileId); } catch (e) { fail('INVALID_FILE', 'Không tìm thấy tệp đã tải lên.'); }
  var d = parseJson(f.getDescription(), {});
  if (d.owner !== userId) fail('FORBIDDEN', 'Tệp không thuộc về bạn.');
  if (purpose && d.purpose !== purpose && !(purpose === 'leave-source' && d.purpose === 'leave-source')) {
    fail('INVALID_FILE', 'Tệp không đúng mục đích sử dụng.');
  }
  return f;
}

/** Thông tin tệp tải lên của chính mình (dùng khi mở lại bản nháp). */
function api_files_info(ctx, p) {
  var f = checkUploadOwner(p.fileId, ctx.user.id, null);
  return { fileId: f.getId(), fileName: f.getName(), size: f.getSize(), mimeType: f.getMimeType() };
}

/** Tải tệp tạm của chính mình (ví dụ PDF vừa chuyển từ Word) để xem và chèn chữ ký. */
function api_files_downloadOwn(ctx, p) {
  checkUploadOwner(p.fileId, ctx.user.id, null);
  return downloadChunk(p.fileId, p.offset, '');
}

/** Trả một phần tệp dạng base64. Giao diện gọi lặp đến khi done=true. */
function downloadChunk(fileId, offset, fileName) {
  var f = DriveApp.getFileById(fileId);
  var bytes = f.getBlob().getBytes();
  var start = parseInt(offset, 10) || 0;
  var end = Math.min(bytes.length, start + CHUNK_RAW_BYTES);
  return {
    fileName: fileName || f.getName(), mimeType: f.getMimeType(), size: bytes.length, offset: start, next: end,
    done: end >= bytes.length, dataBase64: Utilities.base64Encode(bytes.slice(start, end))
  };
}

/** Tệp gắn vào bản nháp được chuyển khỏi thư mục tạm để không bị dọn. */
function keepDraftFiles(ids) {
  if (!ids.length) return;
  var tmpId = folderPath('TamThoi').getId();
  var keep = folderPath('Nhap');
  ids.forEach(function (id) {
    var f = DriveApp.getFileById(id);
    var parents = f.getParents();
    if (parents.hasNext() && parents.next().getId() === tmpId) f.moveTo(keep);
  });
}

/** Dọn tệp tạm quá 24 giờ (chạy theo giờ). */
function cleanupTemp() {
  var it = folderPath('TamThoi').getFiles();
  var limit = Date.now() - 24 * 3600000;
  while (it.hasNext()) {
    var f = it.next();
    if (f.getDateCreated().getTime() < limit) f.setTrashed(true);
  }
}

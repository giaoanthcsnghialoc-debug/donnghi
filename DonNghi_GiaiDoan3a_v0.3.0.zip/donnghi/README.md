# Hệ thống quản lý và duyệt đơn xin nghỉ trực tuyến – THCS (3 điểm trường)

Phiên bản 0.3.0 – Giai đoạn 3a: hệ thống lõi.

- Cài bản DEMO: xem `docs/HUONG_DAN_CAI_DAT_DEMO.md`.
- Phân tích khả thi (Giai đoạn 1): https://claude.ai/artifact/9wAEGDHAqh8TiDh5KSv4Lu
- Thiết kế (Giai đoạn 2): https://claude.ai/artifact/Y1dVZisH3gwQMNuebSSWkm

## Kiến trúc

- **Máy chủ:** Google Apps Script (`backend/`), dữ liệu trong Google Sheets, tệp trên Google Drive của Gmail chính của trường.
- **Giao diện:** PWA chạy trên GitHub Pages (`frontend/`). Viết bằng JavaScript thuần, không cần biên dịch.
- **Giao tiếp:** POST `text/plain` chứa JSON `{action, token, payload, requestId}` tới URL `/exec`.

## Thư mục

```text
backend/            mã Apps Script theo module (Main, Db, Auth, Permissions, Leave, ...)
frontend/           giao diện PWA (index.html, css/, js/, vendor/, fonts/, icons/)
dist/               bản đóng gói để cài: 1_AppsScript/Code.gs (gộp) + 2_GitHubPages/demo/
docs/               hướng dẫn cài đặt
test/               giả lập Google (gas_mock.js), kiểm thử nghiệp vụ (e2e_test.js), máy chủ thử, kiểm thử giao diện
build.py            gộp backend → dist/1_AppsScript/Code.gs, chép giao diện → dist/2_GitHubPages/demo/
```

## Kiểm thử

```bash
node test/e2e_test.js            # 142 bài kiểm tra nghiệp vụ trên Google giả lập
python3 build.py                 # đóng gói
GAS_DIR=dist/1_AppsScript node test/e2e_test.js   # kiểm thử lại trên tệp đã gộp
```

## Thư viện mã nguồn mở

- pdf-lib 1.17.1 (MIT): chèn chữ ký, ghép ảnh thành PDF trên điện thoại.
- PDF.js 3.11 (Apache-2.0): hiển thị trang đơn để chọn vị trí chữ ký.
- Be Vietnam Pro (SIL OFL 1.1): phông chữ giao diện.

Giấy phép của từng thư viện nằm trong `frontend/vendor/` và `frontend/fonts/`.

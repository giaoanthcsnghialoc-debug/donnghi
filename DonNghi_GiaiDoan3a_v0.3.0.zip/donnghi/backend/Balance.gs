/**
 * Balance.gs – năm học và quỹ phép năm.
 * Chỉ trừ phép khi loại nghỉ là Nghỉ phép năm và đơn đã duyệt/ký. Mọi thay đổi là một giao dịch.
 */

function currentYear() {
  var t = todayStr();
  var y = db_find('AcademicYears', function (r) { return r.status === 'OPEN' && r.startDate <= t && t <= r.endDate; });
  if (y) return y;
  var open = db_filter('AcademicYears', function (r) { return r.status === 'OPEN'; });
  open.sort(function (a, b) { return a.startDate < b.startDate ? 1 : -1; });
  return open[0] || null;
}

/** Năm học chứa một ngày (theo ngày bắt đầu nghỉ). */
function yearForDate(date) {
  var y = db_find('AcademicYears', function (r) { return r.startDate <= date && date <= r.endDate; });
  return y || currentYear();
}

function getOrCreateBalance(userId, yearId, actorId) {
  var b = db_find('LeaveBalances', function (r) { return r.userId === userId && r.academicYearId === yearId; });
  if (b) return b;
  return db_insert('LeaveBalances', { userId: userId, academicYearId: yearId, granted: '0', used: '0', remaining: '0' }, actorId);
}

function recomputeBalance(balanceId, actorId) {
  var b = db_get('LeaveBalances', balanceId);
  var used = 0, granted = 0;
  db_filter('LeaveBalanceTransactions', function (t) { return t.balanceId === balanceId; }).forEach(function (t) {
    var d = Number(t.days) || 0;
    if (t.type === 'GRANT' || t.type === 'ADJUST_GRANT') granted += d;
    if (t.type === 'DEDUCT') used += d;
    if (t.type === 'REVERSE') used -= d;
  });
  return db_update('LeaveBalances', b.id, { granted: String(granted), used: String(used), remaining: String(granted - used) }, actorId);
}

function balanceSummary(userId, yearId) {
  var b = db_find('LeaveBalances', function (r) { return r.userId === userId && r.academicYearId === yearId; });
  if (!b) return { granted: 0, used: 0, remaining: 0, set: false };
  return { granted: Number(b.granted) || 0, used: Number(b.used) || 0, remaining: Number(b.remaining) || 0, set: true };
}

/** Trừ phép khi đơn được duyệt; gọi lại nhiều lần cũng chỉ trừ một lần cho mỗi phiên bản. */
function deductForLeave(leave, actorId) {
  var type = db_get('LeaveTypes', leave.leaveTypeId);
  if (!type || !toBool(type.deductsAnnual)) return null;
  var b = getOrCreateBalance(leave.userId, leave.academicYearId, actorId);
  var exists = db_find('LeaveBalanceTransactions', function (t) {
    return t.leaveRequestId === leave.id && t.version === String(leave.currentVersion) && t.type === 'DEDUCT';
  });
  if (exists) return b;
  db_insert('LeaveBalanceTransactions', {
    balanceId: b.id, userId: leave.userId, academicYearId: leave.academicYearId, type: 'DEDUCT', days: leave.days,
    leaveRequestId: leave.id, version: String(leave.currentVersion), note: 'Duyệt đơn ' + leave.code, actorId: actorId
  }, actorId);
  return recomputeBalance(b.id, actorId);
}

/** Hoàn phép khi hủy đơn đã duyệt. */
function reverseForLeave(leave, actorId, note) {
  var deducted = db_filter('LeaveBalanceTransactions', function (t) { return t.leaveRequestId === leave.id && t.type === 'DEDUCT'; });
  var reversed = db_filter('LeaveBalanceTransactions', function (t) { return t.leaveRequestId === leave.id && t.type === 'REVERSE'; });
  var net = 0;
  deducted.forEach(function (t) { net += Number(t.days) || 0; });
  reversed.forEach(function (t) { net -= Number(t.days) || 0; });
  if (net <= 0) return;
  var b = getOrCreateBalance(leave.userId, leave.academicYearId, actorId);
  db_insert('LeaveBalanceTransactions', {
    balanceId: b.id, userId: leave.userId, academicYearId: leave.academicYearId, type: 'REVERSE', days: String(net),
    leaveRequestId: leave.id, version: String(leave.currentVersion), note: note || ('Hủy đơn ' + leave.code), actorId: actorId
  }, actorId);
  recomputeBalance(b.id, actorId);
}

function requireBalanceManager(ctx) {
  if (!isPrincipal(ctx) && !adminCan(ctx, 'balance')) fail('FORBIDDEN', 'Bạn không có quyền quản lý quỹ phép.');
}

/** Danh sách quỹ phép mọi người trong một năm học. */
function api_balance_list(ctx, p) {
  requireBalanceManager(ctx);
  var y = p.yearId ? db_get('AcademicYears', p.yearId) : currentYear();
  if (!y) fail('NO_YEAR', 'Chưa có năm học.');
  return db_all('Users').filter(function (u) { return u.status !== 'DISABLED'; }).map(function (u) {
    var s = balanceSummary(u.id, y.id);
    return { userId: u.id, fullName: u.fullName, staffCode: u.staffCode, granted: s.granted, used: s.used, remaining: s.remaining, set: s.set };
  }).sort(function (a, b) { return a.fullName.localeCompare(b.fullName, 'vi'); });
}

/** Đặt số ngày phép được cấp (quản trị viên nhập theo quy định). */
function api_balance_set(ctx, p) {
  requireBalanceManager(ctx);
  var granted = Number(p.granted);
  if (!(granted >= 0 && granted <= 60) || (granted * 2) % 1 !== 0) fail('INVALID', 'Số ngày phép phải từ 0 đến 60, bội số của 0,5.');
  return withLock(function () {
    var y = p.yearId ? db_get('AcademicYears', p.yearId) : currentYear();
    if (!y || y.status !== 'OPEN') fail('NO_YEAR', 'Năm học đã khóa hoặc chưa có.');
    assert(db_get('Users', p.userId), 'NOT_FOUND', 'Không tìm thấy người dùng.');
    var b = getOrCreateBalance(p.userId, y.id, ctx.user.id);
    var before = balanceSummary(p.userId, y.id);
    var diff = granted - before.granted;
    if (diff !== 0) {
      db_insert('LeaveBalanceTransactions', {
        balanceId: b.id, userId: p.userId, academicYearId: y.id, type: 'GRANT', days: String(diff),
        note: p.note || 'Cập nhật số ngày phép được cấp', actorId: ctx.user.id
      }, ctx.user.id);
      recomputeBalance(b.id, ctx.user.id);
      audit(ctx.user.id, 'balance.set', 'LeaveBalances', b.id, before, { granted: granted, note: p.note || '' });
    }
    return balanceSummary(p.userId, y.id);
  });
}

function api_balance_history(ctx, p) {
  var userId = p.userId || ctx.user.id;
  if (userId !== ctx.user.id) requireBalanceManager(ctx);
  var y = p.yearId ? db_get('AcademicYears', p.yearId) : currentYear();
  if (!y) return [];
  var names = userNameMap();
  return db_filter('LeaveBalanceTransactions', function (t) { return t.userId === userId && t.academicYearId === y.id; })
    .map(function (t) { return { at: t.createdAt, type: t.type, days: Number(t.days), note: t.note, actor: names[t.actorId] || '' }; });
}

/**
 * Auth.gs – đăng nhập bằng tên đăng nhập/mật khẩu riêng, phiên nhiều thiết bị, khôi phục qua email.
 */

/** PBKDF2-HMAC-SHA256, lấy 32 byte (một khối). Apps Script không có sẵn nên tự viết từ HMAC. */
function pbkdf2Hex(password, saltHex, iterations) {
  var key = Utilities.newBlob(String(password)).getBytes();
  var salt = hexToBytes(saltHex);
  var block = salt.concat([0, 0, 0, 1]);
  var u = Utilities.computeHmacSha256Signature(block, key);
  var t = u.slice();
  for (var i = 1; i < iterations; i++) {
    u = Utilities.computeHmacSha256Signature(u, key);
    for (var j = 0; j < t.length; j++) t[j] = t[j] ^ u[j];
  }
  return bytesToHex(t);
}

function newSaltHex() {
  return Utilities.getUuid().replace(/-/g, '');
}

function setUserPassword(userId, password, actorId, mustChange) {
  validatePasswordStrength(password);
  var salt = newSaltHex();
  var iter = settingInt('PBKDF2_ITER');
  db_update('Users', userId, {
    passwordSalt: salt,
    passwordIter: String(iter),
    passwordHash: pbkdf2Hex(password, salt, iter),
    mustChangePassword: mustChange ? 'TRUE' : 'FALSE',
    failedLogins: '0',
    lockedUntil: ''
  }, actorId);
}

function verifyUserPassword(user, password) {
  if (!user.passwordHash) return false;
  var iter = parseInt(user.passwordIter, 10) || settingInt('PBKDF2_ITER');
  var h = pbkdf2Hex(password, user.passwordSalt, iter);
  // so sánh thời gian không đổi
  if (h.length !== user.passwordHash.length) return false;
  var diff = 0;
  for (var i = 0; i < h.length; i++) diff |= h.charCodeAt(i) ^ user.passwordHash.charCodeAt(i);
  return diff === 0;
}

function validatePasswordStrength(pw) {
  pw = String(pw || '');
  if (pw.length < 8 || !/[A-Za-z]/.test(pw) || !/[0-9]/.test(pw)) {
    fail('WEAK_PASSWORD', 'Mật khẩu cần tối thiểu 8 ký tự, có cả chữ và số.');
  }
}

function findUserByUsername(username) {
  var u = String(username || '').trim().toLowerCase();
  if (!u) return null;
  return db_find('Users', function (r) { return r.username.toLowerCase() === u; });
}

function api_auth_login(ctx, p) {
  return withLock(function () {
    var user = findUserByUsername(p.username);
    var ua = String(p.userAgent || '').slice(0, 200);
    var generic = 'Tên đăng nhập hoặc mật khẩu không đúng.';
    db_insert('LoginAttempts', { username: String(p.username || '').slice(0, 60), success: 'FALSE', at: nowIso(), userAgent: ua });
    var attempt = db_all('LoginAttempts')[db_all('LoginAttempts').length - 1];
    if (!user) fail('LOGIN_FAILED', generic);
    if (user.status === 'DISABLED') fail('LOGIN_FAILED', 'Tài khoản đã ngừng sử dụng. Liên hệ quản trị viên.');
    if (user.status === 'LOCKED') fail('LOCKED', 'Tài khoản đang bị khóa. Liên hệ quản trị viên.');
    if (user.lockedUntil && new Date(user.lockedUntil) > new Date()) {
      fail('LOCKED', 'Đăng nhập sai nhiều lần. Vui lòng thử lại sau ' + viDateTime(user.lockedUntil) + '.');
    }
    if (!verifyUserPassword(user, p.password)) {
      var n = (parseInt(user.failedLogins, 10) || 0) + 1;
      var patch = { failedLogins: String(n) };
      if (n >= settingInt('LOGIN_MAX_FAIL')) {
        patch.lockedUntil = new Date(Date.now() + settingInt('LOGIN_LOCK_MINUTES') * 60000).toISOString();
        patch.failedLogins = '0';
        audit(user.id, 'auth.lock_temp', 'Users', user.id, null, { lockedUntil: patch.lockedUntil });
      }
      db_update('Users', user.id, patch);
      fail('LOGIN_FAILED', generic);
    }
    db_sheet('LoginAttempts').getRange(attempt._row, db_cols('LoginAttempts').indexOf('success') + 1).setValue('TRUE');
    db_update('Users', user.id, { failedLogins: '0', lockedUntil: '' });
    var token = randomToken();
    var idleDays = settingInt('SESSION_IDLE_DAYS');
    db_insert('Sessions', {
      userId: user.id,
      tokenHash: sha256Hex(token),
      deviceLabel: String(p.deviceLabel || '').slice(0, 80),
      userAgent: ua,
      lastSeenAt: nowIso(),
      expiresAt: new Date(Date.now() + idleDays * 86400000).toISOString()
    }, user.id);
    audit(user.id, 'auth.login', 'Users', user.id);
    return { token: token, mustChangePassword: toBool(user.mustChangePassword) };
  });
}

/** Kiểm tra phiên cho mọi yêu cầu cần đăng nhập. */
function loadSession(token) {
  if (!token) fail('AUTH', 'Vui lòng đăng nhập.');
  var th = sha256Hex(String(token));
  var s = db_find('Sessions', function (r) { return r.tokenHash === th; });
  if (!s || s.revokedAt) fail('AUTH', 'Phiên đăng nhập đã hết. Vui lòng đăng nhập lại.');
  var idleMs = settingInt('SESSION_IDLE_DAYS') * 86400000;
  var last = new Date(s.lastSeenAt).getTime();
  if (Date.now() - last > idleMs) fail('AUTH', 'Phiên đăng nhập đã hết hạn do lâu không sử dụng. Vui lòng đăng nhập lại.');
  var user = db_get('Users', s.userId);
  if (!user || user.status !== 'ACTIVE') fail('AUTH', 'Tài khoản không còn hoạt động.');
  // Chỉ ghi lại thời điểm hoạt động mỗi 10 phút để đỡ ghi Sheet.
  if (Date.now() - last > 10 * 60000) {
    var row = s;
    var sh = db_sheet('Sessions');
    var cols = db_cols('Sessions');
    sh.getRange(row._row, cols.indexOf('lastSeenAt') + 1).setValue(nowIso());
    sh.getRange(row._row, cols.indexOf('expiresAt') + 1).setValue(new Date(Date.now() + idleMs).toISOString());
  }
  return { user: user, session: s, roles: userRoles(user.id) };
}

function api_auth_logout(ctx) {
  return withLock(function () {
    db_update('Sessions', ctx.session.id, { revokedAt: nowIso() }, ctx.user.id);
    audit(ctx.user.id, 'auth.logout', 'Users', ctx.user.id);
    return true;
  });
}

function api_auth_changePassword(ctx, p) {
  return withLock(function () {
    var user = db_get('Users', ctx.user.id);
    if (!verifyUserPassword(user, p.oldPassword)) fail('BAD_PASSWORD', 'Mật khẩu hiện tại không đúng.');
    if (p.oldPassword === p.newPassword) fail('WEAK_PASSWORD', 'Mật khẩu mới phải khác mật khẩu cũ.');
    setUserPassword(user.id, p.newPassword, user.id, false);
    revokeSessions(user.id, ctx.session.id);
    audit(user.id, 'auth.change_password', 'Users', user.id);
    return true;
  });
}

function revokeSessions(userId, exceptSessionId) {
  db_filter('Sessions', function (r) { return r.userId === userId && !r.revokedAt && r.id !== exceptSessionId; })
    .forEach(function (s) { db_update('Sessions', s.id, { revokedAt: nowIso() }); });
}

function api_auth_sessions(ctx) {
  var idleMs = settingInt('SESSION_IDLE_DAYS') * 86400000;
  return db_filter('Sessions', function (r) {
    return r.userId === ctx.user.id && !r.revokedAt && Date.now() - new Date(r.lastSeenAt).getTime() <= idleMs;
  }).map(function (s) {
    return { id: s.id, deviceLabel: s.deviceLabel, userAgent: s.userAgent, createdAt: s.createdAt,
      lastSeenAt: s.lastSeenAt, current: s.id === ctx.session.id };
  });
}

function api_auth_revokeSession(ctx, p) {
  return withLock(function () {
    var s = db_get('Sessions', p.sessionId);
    if (!s || s.userId !== ctx.user.id) fail('NOT_FOUND', 'Không tìm thấy thiết bị.');
    db_update('Sessions', s.id, { revokedAt: nowIso() }, ctx.user.id);
    audit(ctx.user.id, 'auth.revoke_session', 'Sessions', s.id);
    return true;
  });
}

var RESET_MESSAGE = 'Nếu tài khoản có email đã đăng ký, hệ thống đã gửi liên kết đặt lại mật khẩu. Vui lòng kiểm tra hộp thư (cả mục Thư rác).';

function api_auth_requestReset(ctx, p) {
  return withLock(function () {
    var user = findUserByUsername(p.username);
    if (!user || user.status !== 'ACTIVE' || !user.email) return { message: RESET_MESSAGE };
    var hourAgo = Date.now() - 3600000;
    var recent = db_filter('PasswordResets', function (r) {
      return r.userId === user.id && new Date(r.createdAt).getTime() > hourAgo;
    });
    if (recent.length >= 3) return { message: RESET_MESSAGE };
    var token = randomToken();
    db_insert('PasswordResets', {
      userId: user.id, tokenHash: sha256Hex(token),
      expiresAt: new Date(Date.now() + 30 * 60000).toISOString()
    }, user.id);
    var link = frontendUrl() + '#/reset?t=' + token;
    var body = 'Chào ' + user.fullName + ',\n\n' +
      'Có yêu cầu đặt lại mật khẩu cho tài khoản "' + user.username + '" trên hệ thống quản lý đơn xin nghỉ.\n' +
      'Mở liên kết sau để tạo mật khẩu mới (dùng một lần, hết hạn sau 30 phút):\n\n' + link + '\n\n' +
      'Nếu không phải bạn yêu cầu, hãy bỏ qua email này.';
    var sent = sendEmailSafe(user.email, 'Đặt lại mật khẩu – Hệ thống đơn xin nghỉ', body, true);
    audit(user.id, 'auth.request_reset', 'Users', user.id, null, { emailSent: sent });
    return { message: RESET_MESSAGE };
  });
}

function api_auth_confirmReset(ctx, p) {
  return withLock(function () {
    var th = sha256Hex(String(p.token || ''));
    var r = db_find('PasswordResets', function (x) { return x.tokenHash === th; });
    if (!r || r.usedAt || new Date(r.expiresAt) < new Date()) {
      fail('RESET_INVALID', 'Liên kết đã hết hạn hoặc đã được dùng. Hãy yêu cầu lại.');
    }
    setUserPassword(r.userId, p.newPassword, r.userId, false);
    db_update('PasswordResets', r.id, { usedAt: nowIso() });
    revokeSessions(r.userId, null);
    audit(r.userId, 'auth.reset_password', 'Users', r.userId);
    return { message: 'Đã đặt mật khẩu mới. Vui lòng đăng nhập.' };
  });
}

function frontendUrl() {
  var u = setting('FRONTEND_URL') || '';
  if (u && u.slice(-1) !== '/') u += '/';
  return u;
}

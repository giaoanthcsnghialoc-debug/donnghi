/**
 * Delegation.gs – Hiệu trưởng ủy quyền tạm thời cho một PHT duyệt đơn.
 * Mỗi thời điểm chỉ một ủy quyền; phạm vi: duyệt, từ chối, yêu cầu bổ sung, ký duyệt (không gồm hủy đơn).
 */

function api_delegation_list(ctx) {
  if (!isPrincipal(ctx) && !isVice(ctx)) fail('FORBIDDEN', 'Không có quyền.');
  var names = userNameMap();
  return db_all('Delegations').slice().reverse().map(function (d) {
    var now = Date.now();
    var effective = d.status === 'ACTIVE' && new Date(d.startAt).getTime() <= now && now < new Date(d.endAt).getTime();
    var upcoming = d.status === 'ACTIVE' && new Date(d.startAt).getTime() > now;
    return { id: d.id, viceId: d.viceId, viceName: names[d.viceId], startAt: d.startAt, endAt: d.endAt, status: d.status,
      effective: effective, upcoming: upcoming, endedBy: names[d.endedBy] || '', endedAt: d.endedAt };
  }).filter(function (d) { return isPrincipal(ctx) || d.viceId === ctx.user.id; });
}

function api_delegation_create(ctx, p) {
  requirePrincipal(ctx);
  return withLock(function () {
    var vice = db_get('Users', p.viceId);
    if (!vice || vice.status !== 'ACTIVE' || !userRoles(vice.id).codes[ROLE.VICE]) fail('INVALID', 'Chọn một Phó Hiệu trưởng đang hoạt động.');
    var start = new Date(p.startAt), end = new Date(p.endAt);
    if (isNaN(start) || isNaN(end) || end <= start) fail('INVALID', 'Thời gian ủy quyền không hợp lệ.');
    if (end.getTime() < Date.now()) fail('INVALID', 'Thời điểm kết thúc đã qua.');
    if ((end - start) > 92 * 86400000) fail('INVALID', 'Mỗi lần ủy quyền tối đa 3 tháng.');
    var clash = db_find('Delegations', function (d) {
      return d.status === 'ACTIVE' && new Date(d.startAt) < end && start < new Date(d.endAt) && new Date(d.endAt).getTime() > Date.now();
    });
    if (clash) fail('INVALID', 'Thời gian này đã có ủy quyền khác. Hãy kết thúc ủy quyền cũ trước.');
    var d = db_insert('Delegations', {
      principalId: ctx.user.id, viceId: vice.id, startAt: start.toISOString(), endAt: end.toISOString(),
      scope: 'APPROVE,REJECT,REQUEST_CHANGES', status: 'ACTIVE'
    }, ctx.user.id);
    audit(ctx.user.id, 'delegation.create', 'Delegations', d.id, null, d);
    notifyUsers([vice.id], {
      type: 'DELEGATION', title: 'Bạn được ủy quyền duyệt đơn',
      body: 'Hiệu trưởng ủy quyền cho bạn duyệt đơn xin nghỉ từ ' + viDateTime(d.startAt) + ' đến ' + viDateTime(d.endAt) + '.',
      link: '#/approvals'
    }, true, ctx.user.id);
    return true;
  });
}

function api_delegation_end(ctx, p) {
  requirePrincipal(ctx);
  return withLock(function () {
    var d = db_get('Delegations', p.id);
    if (!d || d.status !== 'ACTIVE') fail('NOT_FOUND', 'Không tìm thấy ủy quyền đang hiệu lực.');
    db_update('Delegations', d.id, { status: 'ENDED', endedBy: ctx.user.id, endedAt: nowIso() }, ctx.user.id);
    audit(ctx.user.id, 'delegation.end', 'Delegations', d.id, { status: 'ACTIVE' }, { status: 'ENDED' });
    notifyUsers([d.viceId], {
      type: 'DELEGATION', title: 'Ủy quyền duyệt đơn đã kết thúc',
      body: 'Hiệu trưởng đã kết thúc ủy quyền duyệt đơn của bạn.', link: '#/'
    }, true, ctx.user.id);
    return true;
  });
}

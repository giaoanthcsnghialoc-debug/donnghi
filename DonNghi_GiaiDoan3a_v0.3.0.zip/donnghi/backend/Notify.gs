/**
 * Notify.gs – thông báo trong ứng dụng và email. Zalo, thông báo đẩy: tắt, lưu trạng thái để bật sau.
 */

function decisionMakerIds() {
  var ids = db_filter('UserRoles', function (r) { return r.roleCode === ROLE.PRINCIPAL; }).map(function (r) { return r.userId; });
  var d = activeDelegation();
  if (d) ids.push(d.viceId);
  return uniq(ids).filter(activeUserId);
}

/** 3 PHT và các tổ trưởng – nhận thông báo đơn đã duyệt (quyết định 21/11/2026). */
function managerIds() {
  return uniq(db_filter('UserRoles', function (r) { return r.roleCode === ROLE.VICE || r.roleCode === ROLE.LEADER; })
    .map(function (r) { return r.userId; })).filter(activeUserId);
}

function activeUserId(id) {
  var u = db_get('Users', id);
  return u && u.status === 'ACTIVE';
}

function uniq(arr) {
  var seen = {};
  return arr.filter(function (x) { if (!x || seen[x]) return false; seen[x] = true; return true; });
}

function notifyDeciders(leave, title) {
  notifyUsers(decisionMakerIds().filter(function (id) { return id !== leave.userId; }), {
    type: 'LEAVE_PENDING', title: title,
    body: ownerName(leave) + ' – ' + typeName(leave) + ', ' + describePeriod(leave) + ' (' + formatDays(leave.days) + '). Mã đơn ' + leave.code + '.',
    link: '#/leave/' + leave.id
  }, true, leave.userId);
}

/**
 * email: true = gửi email; false = chỉ trong ứng dụng; 'optin' = gửi email cho người đã bật nhận.
 * Nội dung không chứa lý do nghỉ (chỉ họ tên, loại nghỉ, thời gian).
 */
function notifyUsers(userIds, n, email, senderId) {
  userIds = uniq(userIds);
  if (!userIds.length) return null;
  var note = db_insert('Notifications', {
    type: n.type, title: n.title, body: n.body, link: n.link || '', senderId: senderId || '',
    scope: userIds.length > 1 ? 'MULTI' : 'USER', isUrgent: n.urgent ? 'TRUE' : 'FALSE'
  }, senderId);
  userIds.forEach(function (uid) {
    var u = db_get('Users', uid);
    var wantEmail = email === true || (email === 'optin' && u && toBool(u.emailOnApproved));
    var emailStatus = 'SKIPPED';
    if (wantEmail && u && u.email) {
      emailStatus = sendEmailSafe(u.email, n.title, n.body + '\n\nMở ứng dụng: ' + frontendUrl() + (n.link || ''), false) ? 'SENT' : 'PENDING';
    } else if (wantEmail) {
      emailStatus = 'NO_EMAIL';
    }
    db_insert('NotificationRecipients', {
      notificationId: note.id, userId: uid, readAt: '', emailStatus: emailStatus,
      zaloStatus: 'DISABLED', pushStatus: 'DISABLED'
    }, senderId);
  });
  return note;
}

/**
 * Gửi email nếu còn hạn mức. Giữ lại EMAIL_RESERVE người nhận cho email khôi phục mật khẩu.
 * Ở DEMO chỉ gửi tới danh sách thử (EMAIL_TEST_WHITELIST).
 */
function sendEmailSafe(to, subject, body, isReset) {
  try {
    if (isDemo()) {
      var wl = splitList(setting('EMAIL_TEST_WHITELIST')).map(function (x) { return x.toLowerCase(); });
      if (wl.indexOf(String(to).toLowerCase()) < 0) return false;
    }
    var remaining = MailApp.getRemainingDailyQuota();
    var reserve = isReset ? 0 : settingInt('EMAIL_RESERVE');
    if (remaining <= reserve) return false;
    MailApp.sendEmail({ to: to, subject: (isDemo() ? '[DEMO] ' : '') + subject, body: body, name: 'Hệ thống đơn xin nghỉ' });
    return true;
  } catch (e) {
    console.error('Email lỗi: ' + e);
    return false;
  }
}

function unreadCount(userId) {
  return db_filter('NotificationRecipients', function (r) { return r.userId === userId && !r.readAt; }).length;
}

function api_notify_list(ctx, p) {
  var mine = db_filter('NotificationRecipients', function (r) { return r.userId === ctx.user.id; });
  if (p.unreadOnly) mine = mine.filter(function (r) { return !r.readAt; });
  mine.sort(function (a, b) { return b.createdAt.localeCompare(a.createdAt); });
  var limit = Math.min(parseInt(p.limit, 10) || 50, 200);
  var names = userNameMap();
  return mine.slice(0, limit).map(function (r) {
    var n = db_get('Notifications', r.notificationId) || {};
    return { id: r.id, title: n.title, body: n.body, link: n.link, type: n.type, urgent: toBool(n.isUrgent),
      sender: names[n.senderId] || '', at: r.createdAt, read: !!r.readAt };
  });
}

function api_notify_markRead(ctx, p) {
  return withLock(function () {
    var ids = p.all ? null : (p.ids || []);
    var now = nowIso();
    var sh = db_sheet('NotificationRecipients');
    var col = db_cols('NotificationRecipients').indexOf('readAt') + 1;
    db_filter('NotificationRecipients', function (r) {
      return r.userId === ctx.user.id && !r.readAt && (!ids || ids.indexOf(r.id) >= 0);
    }).forEach(function (r) { sh.getRange(r._row, col).setValue(now); });
    return { unread: 0 };
  });
}

/** Gửi lại email còn chờ do hết hạn mức (chạy theo giờ). */
function retryPendingEmails() {
  var pending = db_filter('NotificationRecipients', function (r) { return r.emailStatus === 'PENDING'; }).slice(0, 30);
  pending.forEach(function (r) {
    var u = db_get('Users', r.userId), n = db_get('Notifications', r.notificationId);
    if (!u || !n || !u.email) return;
    if (sendEmailSafe(u.email, n.title, n.body + '\n\nMở ứng dụng: ' + frontendUrl() + (n.link || ''), false)) {
      db_update('NotificationRecipients', r.id, { emailStatus: 'SENT' });
    }
  });
}

/** Nhắc HT/PHT ủy quyền xử lý đơn chờ quá các mốc giờ cấu hình (mỗi mốc nhắc một lần). */
function remindPendingLeaves() {
  var marks = splitList(setting('REMIND_HOURS')).map(Number).filter(function (x) { return x > 0; }).sort(function (a, b) { return a - b; });
  db_filter('LeaveRequests', function (l) { return l.status === 'PENDING'; }).forEach(function (l) {
    var since = db_filter('LeaveStatusHistory', function (h) { return h.leaveRequestId === l.id && h.toStatus === 'PENDING'; }).pop();
    if (!since) return;
    var hours = (Date.now() - new Date(since.at).getTime()) / 3600000;
    var done = splitList(l.remindedMarks).map(Number);
    var due = marks.filter(function (m) { return hours >= m && done.indexOf(m) < 0; });
    if (!due.length) return;
    var m = due[due.length - 1];
    notifyUsers(decisionMakerIds(), {
      type: 'LEAVE_REMIND', title: 'Đơn chờ duyệt quá ' + m + ' giờ',
      body: 'Đơn ' + l.code + ' của ' + ownerName(l) + ' (' + describePeriod(l) + ') đang chờ xử lý.', link: '#/leave/' + l.id
    }, m >= 24, '');
    db_update('LeaveRequests', l.id, { remindedMarks: done.concat(due).join(',') });
  });
}

// Xuất HTML mẫu đơn (đã duyệt, có chữ ký) ra file để xem bằng trình duyệt.
const vm = require('vm'), fs = require('fs'), path = require('path');
const { install } = require('./gas_mock');
const ctx = vm.createContext({}); install(ctx); ctx.globalThis = ctx;
const dir = path.join(__dirname, '..', 'backend');
fs.readdirSync(dir).filter(f => f.endsWith('.gs')).sort().forEach(f => vm.runInContext(fs.readFileSync(path.join(dir, f), 'utf8'), ctx));
ctx.setupDemo();
const call = (t, a, p) => ctx.handleRequest({ action: a, token: t, payload: p || {} });
const login = u => call(null, 'auth.login', { username: u, password: 'Demo@2026' }).data.token;
// chữ ký mẫu: PNG thật vẽ bằng python trước đó
const sig = fs.readFileSync(process.argv[2]).toString('base64');
const gv = login('gv2'), ht = login('hieutruong');
call(gv, 'me.signature.upload', { pngBase64: sig }); call(ht, 'me.signature.upload', { pngBase64: sig });
const b = call(gv, 'me.bootstrap').data;
let L = call(gv, 'leave.save', { leaveTypeId: b.leaveTypes[3].id, startDate: '2026-12-03', startSession: 'PM', endDate: '2026-12-04', endSession: 'PM', reason: 'Đưa con đi khám bệnh tại bệnh viện huyện', campusIds: b.user.campusIds }).data;
call(gv, 'leave.submit', { id: L.id }); call(gv, 'leave.sign', { id: L.id });
call(ht, 'leave.approve', { id: L.id });
fs.writeFileSync('/home/claude/donnghi/test/preview.html', globalThis.__lastHtml);
console.log('ok');

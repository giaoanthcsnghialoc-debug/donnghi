/**
 * Setup.gs – thiết lập lần đầu. Chạy trong trình soạn thảo Apps Script:
 *   - Dự án DEMO:  chạy hàm setupDemo()
 *   - Dự án PROD:  chạy hàm setupProd()
 * Chạy lại an toàn: chỉ tạo phần còn thiếu, không xóa dữ liệu.
 */

var DEMO_PASSWORD = 'Demo@2026';

function setupDemo() {
  var info = setupCore('DEMO');
  seedDemoData();
  setSetting('SIGN_MODE', 'IMAGE', 'setup');
  logSetup(info, true);
}

function setupProd() {
  var info = setupCore('PROD');
  var admin = ensurePrimaryAdmin();
  logSetup(info, false, admin);
}

function setupCore(env) {
  var props = PropertiesService.getScriptProperties();
  var existingEnv = props.getProperty('ENV');
  if (existingEnv && existingEnv !== env) throw new Error('Dự án này đã thiết lập cho ' + existingEnv + '. Mỗi môi trường dùng một dự án Apps Script riêng.');
  props.setProperty('ENV', env);
  // Thư mục gốc và file dữ liệu
  var rootId = props.getProperty('ROOT_FOLDER_ID');
  var root;
  if (rootId) {
    root = DriveApp.getFolderById(rootId);
  } else {
    root = DriveApp.createFolder('HeThongDonNghi_' + env);
    props.setProperty('ROOT_FOLDER_ID', root.getId());
  }
  var ssId = props.getProperty('SPREADSHEET_ID');
  var ss;
  if (ssId) {
    ss = SpreadsheetApp.openById(ssId);
  } else {
    ss = SpreadsheetApp.create('HeThongDonNghi_' + env + '_DuLieu');
    DriveApp.getFileById(ss.getId()).moveTo(root);
    props.setProperty('SPREADSHEET_ID', ss.getId());
  }
  _ss = ss;
  ss.setSpreadsheetTimeZone('Asia/Ho_Chi_Minh');
  // Tạo các Sheet theo SCHEMA
  Object.keys(SCHEMA).forEach(function (name) {
    var sh = ss.getSheetByName(name) || ss.insertSheet(name);
    var cols = db_cols(name);
    var header = sh.getRange(1, 1, 1, Math.max(sh.getLastColumn(), 1)).getValues()[0];
    if (header.join('') === '') {
      sh.getRange(1, 1, 1, cols.length).setValues([cols]).setFontWeight('bold');
      sh.setFrozenRows(1);
    } else {
      // bổ sung cột mới ở cuối nếu phiên bản mới có thêm (không xóa cột cũ)
      cols.forEach(function (c, i) { if (header[i] !== c) sh.getRange(1, i + 1).setValue(c).setFontWeight('bold'); });
    }
    sh.getRange(1, 1, sh.getMaxRows(), cols.length).setNumberFormat('@');
  });
  var def = ss.getSheetByName('Sheet1') || ss.getSheetByName('Trang tính1');
  if (def && ss.getSheets().length > 1) ss.deleteSheet(def);
  ['PDF', 'DinhKem', 'ChuKy', 'NhanDien', 'MauDon', 'SaoLuu', 'TamThoi', 'Nhap'].forEach(function (f) { folderPath(f); });
  db_resetCache();
  seedBase();
  ensureTriggers();
  return { env: env, folderUrl: root.getUrl(), spreadsheetUrl: ss.getUrl() };
}

function seedBase() {
  if (!db_all('Roles').length) {
    Object.keys(ROLE_NAMES).forEach(function (k) { db_insert('Roles', { code: k, name: ROLE_NAMES[k] }, 'setup'); });
  }
  if (!db_all('Permissions').length) {
    Object.keys(ADMIN_PERMS).forEach(function (k) { db_insert('Permissions', { code: 'admin.' + k, description: ADMIN_PERMS[k] }, 'setup'); });
    ['leave.create', 'leave.approve', 'leave.cancel', 'delegation.manage', 'report.view'].forEach(function (k) {
      db_insert('Permissions', { code: k, description: k }, 'setup');
    });
  }
  if (!db_all('Schools').length) db_insert('Schools', { name: DEFAULT_SETTINGS.SCHOOL_NAME }, 'setup');
  if (!db_all('Campuses').length) {
    [['Điểm chính', 'ĐC'], ['Phân hiệu 1', 'PH1'], ['Phân hiệu 2', 'PH2']].forEach(function (c, i) {
      db_insert('Campuses', { name: c[0], shortName: c[1], order: String(i + 1), status: 'ACTIVE' }, 'setup');
    });
  }
  if (!db_all('LeaveTypes').length) {
    [['Nghỉ ốm', 'SICK', false, false], ['Nghỉ việc riêng', 'PERSONAL', false, false], ['Nghỉ việc gia đình', 'FAMILY', false, false],
     ['Nghỉ phép năm', 'ANNUAL', true, false], ['Nghỉ đột xuất', 'URGENT', false, false], ['Nghỉ khác', 'OTHER', false, true]]
      .forEach(function (t, i) {
        db_insert('LeaveTypes', { name: t[0], code: t[1], deductsAnnual: t[2] ? 'TRUE' : 'FALSE', requiresNote: t[3] ? 'TRUE' : 'FALSE', order: String(i + 1), status: 'ACTIVE' }, 'setup');
      });
  }
  if (!db_all('AcademicYears').length) {
    var now = new Date();
    var y = now.getMonth() >= 7 ? now.getFullYear() : now.getFullYear() - 1;   // từ tháng 8 tính năm học mới
    db_insert('AcademicYears', { name: y + '-' + (y + 1), startDate: y + '-08-01', endDate: (y + 1) + '-07-31', autoRolloverAt: '', status: 'OPEN' }, 'setup');
  }
  if (!db_all('DocumentTemplates').length) {
    db_insert('DocumentTemplates', { name: 'Mẫu đơn xin nghỉ', version: '1', html: DEFAULT_TEMPLATE_HTML, layoutJson: JSON.stringify(DEFAULT_TEMPLATE_LAYOUT), status: 'ACTIVE' }, 'setup');
  }
  if (!db_find('AppVersions', function (v) { return v.version === APP_VERSION; })) {
    db_insert('AppVersions', { version: APP_VERSION, changes: 'Hệ thống lõi (Giai đoạn 3a)', deployedAt: nowIso(), deployedBy: Session.getEffectiveUser().getEmail(), schemaVersion: '1' }, 'setup');
  }
}

function ensureTriggers() {
  var has = ScriptApp.getProjectTriggers().some(function (t) { return t.getHandlerFunction() === 'cronHourly'; });
  if (!has) ScriptApp.newTrigger('cronHourly').timeBased().everyHours(1).create();
}

/** Tạo quản trị viên chính (chỉ khi chưa có). Mật khẩu tạm in ra nhật ký thực thi. */
function ensurePrimaryAdmin() {
  var existing = db_find('UserRoles', function (r) { return r.roleCode === ROLE.ADMIN && toBool(r.isPrimaryAdmin); });
  if (existing) return null;
  var temp = randomPassword();
  var u = db_insert('Users', {
    staffCode: 'QTV', fullName: 'Quản trị viên chính', username: 'quantri', status: 'ACTIVE', failedLogins: '0',
    themePref: 'auto', mustChangePassword: 'TRUE', email: Session.getEffectiveUser().getEmail()
  }, 'setup');
  setUserPassword(u.id, temp, 'setup', true);
  db_insert('UserRoles', { userId: u.id, roleCode: ROLE.ADMIN, extraPermissions: '', isPrimaryAdmin: 'TRUE' }, 'setup');
  audit('setup', 'user.create_primary_admin', 'Users', u.id);
  return { username: 'quantri', tempPassword: temp };
}

function seedDemoData() {
  ensurePrimaryAdminDemo();
  if (db_find('Users', function (u) { return u.username === 'hieutruong'; })) return;
  var ctx = { user: { id: 'setup' }, roles: { codes: { ADMIN: true }, adminPerms: {}, isPrimaryAdmin: true } };
  var deps = ['Tổ Khoa học tự nhiên', 'Tổ Khoa học xã hội', 'Tổ Văn phòng'].map(function (n) {
    return db_insert('Departments', { name: n, status: 'ACTIVE' }, 'setup').id;
  });
  var c = db_all('Campuses').map(function (x) { return x.id; });
  var people = [
    ['HT01', 'Trần Văn Hiệu', 'hieutruong', ['PRINCIPAL'], [c[0], c[1], c[2]], '', 'Hiệu trưởng'],
    ['PHT01', 'Lê Thị Phó Một', 'pht1', ['VICE'], [c[0]], '', 'Phó Hiệu trưởng'],
    ['PHT02', 'Nguyễn Văn Phó Hai', 'pht2', ['VICE'], [c[1]], '', 'Phó Hiệu trưởng'],
    ['PHT03', 'Phạm Thị Phó Ba', 'pht3', ['VICE'], [c[2]], '', 'Phó Hiệu trưởng'],
    ['TT01', 'Hoàng Văn Tổ Một', 'tt1', ['LEADER', 'TEACHER'], [c[0]], deps[0], 'Tổ trưởng'],
    ['TT02', 'Đỗ Thị Tổ Hai', 'tt2', ['LEADER', 'TEACHER'], [c[1]], deps[1], 'Tổ trưởng'],
    ['TT03', 'Vũ Văn Tổ Ba', 'tt3', ['LEADER', 'STAFF'], [c[0]], deps[2], 'Tổ trưởng'],
    ['GV01', 'Bùi Thị Giáo Một', 'gv1', ['TEACHER'], [c[0]], deps[0], 'Giáo viên'],
    ['GV02', 'Đặng Văn Giáo Hai', 'gv2', ['TEACHER'], [c[1], c[2]], deps[0], 'Giáo viên'],
    ['GV03', 'Ngô Thị Giáo Ba', 'gv3', ['TEACHER'], [c[2]], deps[1], 'Giáo viên'],
    ['GV04', 'Lý Văn Giáo Bốn', 'gv4', ['TEACHER'], [c[0], c[1]], deps[1], 'Giáo viên'],
    ['NV01', 'Mai Thị Nhân Viên', 'nv1', ['STAFF'], [c[0]], deps[2], 'Kế toán']
  ];
  var year = currentYear();
  people.forEach(function (p) {
    var res = createUserCore(ctx, { staffCode: p[0], fullName: p[1], username: p[2], roles: p[3], campusIds: p[4], departmentId: p[5], positionTitle: p[6], password: DEMO_PASSWORD });
    db_update('Users', res.user.id, { mustChangePassword: 'FALSE', phone: '09000000' + p[0].slice(-2) }, 'setup');
    if (p[3].indexOf('PRINCIPAL') < 0) {
      var b = getOrCreateBalance(res.user.id, year.id, 'setup');
      db_insert('LeaveBalanceTransactions', { balanceId: b.id, userId: res.user.id, academicYearId: year.id, type: 'GRANT', days: '12', note: 'Dữ liệu mẫu', actorId: 'setup' }, 'setup');
      recomputeBalance(b.id, 'setup');
    }
  });
  db_resetCache();
  // gán tổ trưởng
  db_update('Departments', deps[0], { leaderUserId: findUserByUsername('tt1').id }, 'setup');
  db_update('Departments', deps[1], { leaderUserId: findUserByUsername('tt2').id }, 'setup');
  db_update('Departments', deps[2], { leaderUserId: findUserByUsername('tt3').id }, 'setup');
  setSetting('SCHOOL_NAME', 'Trường THCS Mẫu (DEMO)', 'setup');
  setSetting('SCHOOL_PARENT', 'UBND xã Mẫu', 'setup');
  setSetting('SCHOOL_PLACE', 'Xã Mẫu', 'setup');
}

function ensurePrimaryAdminDemo() {
  var existing = db_find('UserRoles', function (r) { return r.roleCode === ROLE.ADMIN && toBool(r.isPrimaryAdmin); });
  if (existing) return;
  var u = db_insert('Users', { staffCode: 'QTV', fullName: 'Quản trị viên (DEMO)', username: 'quantri', status: 'ACTIVE', failedLogins: '0', themePref: 'auto', mustChangePassword: 'FALSE' }, 'setup');
  setUserPassword(u.id, DEMO_PASSWORD, 'setup', false);
  db_insert('UserRoles', { userId: u.id, roleCode: ROLE.ADMIN, extraPermissions: '', isPrimaryAdmin: 'TRUE' }, 'setup');
}

function logSetup(info, demo, admin) {
  console.log('Đã thiết lập môi trường ' + info.env);
  console.log('Thư mục dữ liệu: ' + info.folderUrl);
  console.log('File Sheets: ' + info.spreadsheetUrl);
  if (demo) console.log('Tài khoản mẫu: quantri, hieutruong, pht1..pht3, tt1..tt3, gv1..gv4, nv1 – mật khẩu chung: ' + DEMO_PASSWORD);
  if (admin) console.log('Quản trị viên chính: ' + admin.username + ' – mật khẩu tạm (đổi ngay khi đăng nhập): ' + admin.tempPassword);
  console.log('Bước tiếp theo: Triển khai → Triển khai mới → Ứng dụng web (Thực thi với tư cách: Tôi; Ai có quyền truy cập: Bất kỳ ai).');
}

/** Đo thời gian băm mật khẩu để chọn số vòng lặp phù hợp (chạy thử trong trình soạn thảo). */
function benchmarkHash() {
  [1000, 3000, 6000].forEach(function (n) {
    var t = Date.now();
    pbkdf2Hex('ThuMatKhau123', newSaltHex(), n);
    console.log(n + ' vòng: ' + (Date.now() - t) + ' ms');
  });
}

/**
 * Quên mật khẩu quản trị viên chính: chạy hàm này trong trình soạn thảo Apps Script.
 * Chỉ người sở hữu dự án (Gmail chính của trường) chạy được. Mật khẩu tạm in ra nhật ký thực thi.
 */
function resetPrimaryAdminPassword() {
  db_resetCache();
  var r = db_find('UserRoles', function (x) { return x.roleCode === ROLE.ADMIN && toBool(x.isPrimaryAdmin); });
  if (!r) throw new Error('Chưa có quản trị viên chính. Hãy chạy hàm thiết lập.');
  var temp = randomPassword();
  setUserPassword(r.userId, temp, 'owner', true);
  db_update('Users', r.userId, { status: 'ACTIVE', lockedUntil: '', failedLogins: '0' }, 'owner');
  revokeSessions(r.userId, null);
  audit('owner', 'user.reset_primary_admin', 'Users', r.userId);
  console.log('Tên đăng nhập: ' + db_get('Users', r.userId).username + ' – mật khẩu tạm: ' + temp + ' (đổi ngay khi đăng nhập)');
}

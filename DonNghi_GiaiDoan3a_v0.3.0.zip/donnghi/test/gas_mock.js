// Giả lập tối thiểu các dịch vụ Google Apps Script để chạy thử backend bằng Node.
const crypto = require('crypto');

function toSigned(buf) { return Array.from(buf, b => (b > 127 ? b - 256 : b)); }
function toBuf(arr) { return Buffer.from(arr.map(b => b & 0xff)); }

class Blob {
  constructor(bytes, type, name) { this.bytes = bytes || []; this.type = type || 'application/octet-stream'; this.name = name || ''; }
  getBytes() { return this.bytes.slice(); }
  getContentType() { return this.type; }
  getDataAsString() { return toBuf(this.bytes).toString('utf8'); }
  setName(n) { this.name = n; return this; }
  getName() { return this.name; }
  getAs(mime) {
    // "PDF" giả: %PDF + nội dung HTML để kiểm tra được
    const html = toBuf(this.bytes).toString('utf8');
    globalThis.__lastHtml = html;
    return new Blob(toSigned(Buffer.from('%PDF-1.4\n' + html)), mime, this.name);
  }
}

let fileSeq = 0;
const files = {}, folders = {};
class File {
  constructor(blob, parent) { this.id = 'f' + (++fileSeq); this.blob = blob; this.parent = parent; this.desc = ''; this.created = new Date(); this.trashed = false; files[this.id] = this; }
  getId() { return this.id; }
  getBlob() { return this.blob; }
  getName() { return this.blob.name; }
  setName(n) { this.blob.name = n; return this; }
  getSize() { return this.blob.bytes.length; }
  getMimeType() { return this.blob.type; }
  setDescription(d) { this.desc = d; return this; }
  getDescription() { return this.desc; }
  moveTo(f) { this.parent = f; return this; }
  getParents() { const p = this.parent; let done = false; return { hasNext: () => !done && !!p, next: () => { done = true; return p; } }; }
  setTrashed(t) { this.trashed = t; return this; }
  getDateCreated() { return this.created; }
  getAs(mime) { return this.blob.getAs(mime); }
  getUrl() { return 'https://drive/' + this.id; }
}
class Folder {
  constructor(name, parent) { this.id = 'd' + (++fileSeq); this.name = name; this.parent = parent; folders[this.id] = this; }
  getId() { return this.id; }
  getName() { return this.name; }
  getUrl() { return 'https://drive/folder/' + this.id; }
  getFoldersByName(n) { const list = Object.values(folders).filter(f => f.parent === this && f.name === n); let i = 0; return { hasNext: () => i < list.length, next: () => list[i++] }; }
  createFolder(n) { return new Folder(n, this); }
  createFile(blob) { return new File(blob, this); }
  getFiles() { const list = Object.values(files).filter(f => f.parent === this && !f.trashed); let i = 0; return { hasNext: () => i < list.length, next: () => list[i++] }; }
}

class Range {
  constructor(sh, r, c, nr, nc) { Object.assign(this, { sh, r, c, nr, nc }); }
  getValues() { const out = []; for (let i = 0; i < this.nr; i++) { const row = []; for (let j = 0; j < this.nc; j++) { const v = (this.sh.data[this.r - 1 + i] || [])[this.c - 1 + j]; row.push(v === undefined ? '' : v); } out.push(row); } return out; }
  getDisplayValues() { return this.getValues().map(r => r.map(String)); }
  getValue() { return this.getValues()[0][0]; }
  setValues(vals) { vals.forEach((row, i) => row.forEach((v, j) => this.sh.set(this.r + i, this.c + j, v))); return this; }
  setValue(v) { this.sh.set(this.r, this.c, v); return this; }
  setFontWeight() { return this; }
  setNumberFormat() { return this; }
}
class Sheet {
  constructor(name) { this.name = name; this.data = []; }
  set(r, c, v) { while (this.data.length < r) this.data.push([]); const row = this.data[r - 1]; while (row.length < c) row.push(''); row[c - 1] = (typeof v === 'string' || v === '') ? v : String(v); }
  getLastRow() { let n = this.data.length; while (n > 0 && this.data[n - 1].every(x => x === '' || x === undefined)) n--; return n; }
  getLastColumn() { return Math.max(0, ...this.data.map(r => r.length)); }
  getMaxRows() { return Math.max(1000, this.data.length); }
  getRange(r, c, nr, nc) { return new Range(this, r, c, nr || 1, nc || 1); }
  getDataRange() { return new Range(this, 1, 1, this.getLastRow(), this.getLastColumn()); }
  appendRow(vals) { const r = this.getLastRow() + 1; vals.forEach((v, j) => this.set(r, j + 1, v)); }
  deleteRow(r) { this.data.splice(r - 1, 1); }
  setFrozenRows() {}
  getName() { return this.name; }
}
class Spreadsheet {
  constructor(name) { this.id = 's' + (++fileSeq); this.name = name; this.sheets = [new Sheet('Sheet1')]; files[this.id] = new File(new Blob([], 'application/vnd.google-apps.spreadsheet', name), null); files[this.id].id = this.id; files[this.id].ss = this; }
  getId() { return this.id; }
  getUrl() { return 'https://sheets/' + this.id; }
  getSheetByName(n) { return this.sheets.find(s => s.name === n) || null; }
  insertSheet(n) { const s = new Sheet(n); this.sheets.push(s); return s; }
  deleteSheet(s) { this.sheets = this.sheets.filter(x => x !== s); }
  getSheets() { return this.sheets; }
  setSpreadsheetTimeZone() {}
}
const spreadsheets = {};
const props = {};
const cache = {};
const sentMail = [];
const myRoot = new Folder('My Drive', null);

function install(g) {
  g.SpreadsheetApp = {
    create: n => { const s = new Spreadsheet(n); spreadsheets[s.id] = s; return s; },
    openById: id => spreadsheets[id],
    flush: () => {}
  };
  g.DriveApp = {
    createFolder: n => new Folder(n, myRoot),
    getFolderById: id => folders[id],
    getFileById: id => { if (!files[id]) throw new Error('no file ' + id); return files[id]; }
  };
  g.Drive = { Files: { create: (meta, blob) => { const parent = folders[meta.parents[0]]; const f = new File(new Blob(blob.bytes, meta.mimeType, meta.name), parent); return { id: f.id }; } } };
  g.Utilities = {
    DigestAlgorithm: { SHA_256: 'sha256' }, Charset: { UTF_8: 'utf8' },
    computeDigest: (alg, input) => toSigned(crypto.createHash('sha256').update(typeof input === 'string' ? Buffer.from(input, 'utf8') : toBuf(input)).digest()),
    computeHmacSha256Signature: (value, key) => toSigned(crypto.createHmac('sha256', toBuf(key)).update(toBuf(value)).digest()),
    getUuid: () => crypto.randomUUID(),
    formatDate: (d, tz, fmt) => {
      const vn = new Date(d.getTime() + 7 * 3600000);
      const p = n => String(n).padStart(2, '0');
      const Y = vn.getUTCFullYear(), M = p(vn.getUTCMonth() + 1), D = p(vn.getUTCDate()), h = p(vn.getUTCHours()), m = p(vn.getUTCMinutes()), s = p(vn.getUTCSeconds());
      return fmt.replace('yyyy', Y).replace('MM', M).replace('dd', D).replace('HH', h).replace('mm', m).replace("'T'", 'T').replace('ss', s).replace('XXX', '+07:00');
    },
    newBlob: (data, type, name) => new Blob(typeof data === 'string' ? toSigned(Buffer.from(data, 'utf8')) : data, type, name),
    base64Encode: bytes => toBuf(bytes).toString('base64'),
    base64Decode: s => toSigned(Buffer.from(s, 'base64')),
    parseCsv: t => t.trim().split(/\r?\n/).map(l => l.split(','))
  };
  g.PropertiesService = { getScriptProperties: () => ({ getProperty: k => (k in props ? props[k] : null), setProperty: (k, v) => { props[k] = v; } }) };
  g.LockService = { getScriptLock: () => ({ tryLock: () => true, releaseLock: () => {} }) };
  g.CacheService = { getScriptCache: () => ({ get: k => cache[k] || null, put: (k, v) => { cache[k] = v; }, remove: k => { delete cache[k]; } }) };
  g.MailApp = { getRemainingDailyQuota: () => 100, sendEmail: m => sentMail.push(m) };
  g.ContentService = { MimeType: { JSON: 'json' }, createTextOutput: t => ({ setMimeType: () => ({ text: t }) }) };
  g.Session = { getEffectiveUser: () => ({ getEmail: () => 'truong@gmail.com' }) };
  g.ScriptApp = { getProjectTriggers: () => [], newTrigger: () => ({ timeBased: () => ({ everyHours: () => ({ create: () => {} }) }) }) };
  g.console = console;
  g.__sentMail = sentMail;
  g.__files = files;
}
module.exports = { install, Blob };

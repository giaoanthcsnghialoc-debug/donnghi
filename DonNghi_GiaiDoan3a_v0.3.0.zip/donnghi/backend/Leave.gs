/**
 * Leave.gs – đơn xin nghỉ: bản nháp, gửi, ký, duyệt, từ chối, yêu cầu bổ sung, thu hồi, hủy.
 * Máy trạng thái chỉ cho phép các luồng của đặc tả mục VI.2 (cộng trạng thái Đã hủy đã chốt).
 */

var ST = {
  DRAFT: 'DRAFT', WAIT_SIGN: 'WAIT_SIGN', PENDING: 'PENDING', NEED_CHANGES: 'NEED_CHANGES',
  APPROVED: 'APPROVED', REJECTED: 'REJECTED', WITHDRAWN: 'WITHDRAWN', CANCELLED: 'CANCELLED'
};
var ST_LABEL = {
  DRAFT: 'Bản nháp', WAIT_SIGN: 'Chờ ký người gửi', PENDING: 'Chờ duyệt', NEED_CHANGES: 'Yêu cầu bổ sung',
  APPROVED: 'Đã duyệt/Đã ký', REJECTED: 'Từ chối', WITHDRAWN: 'Đã thu hồi', CANCELLED: 'Đã hủy'
};
var TRANSITIONS = {
  DRAFT: ['WAIT_SIGN', 'CANCELLED'],   // CANCELLED chỉ dùng khi hệ thống chuyển năm học
  WAIT_SIGN: ['PENDING', 'CANCELLED'],
  PENDING: ['NEED_CHANGES', 'APPROVED', 'REJECTED', 'WITHDRAWN', 'CANCELLED'],
  NEED_CHANGES: ['WAIT_SIGN', 'CANCELLED'],
  APPROVED: ['CANCELLED'],
  REJECTED: [], WITHDRAWN: [], CANCELLED: []
};
/** Trạng thái được coi là "đang có hiệu lực" khi kiểm tra trùng thời gian. */
var ACTIVE_FOR_OVERLAP = ['WAIT_SIGN', 'PENDING', 'NEED_CHANGES', 'APPROVED'];

function canTransition(from, to) {
  return (TRANSITIONS[from] || []).indexOf(to) >= 0;
}

/** Chuyển trạng thái, ghi lịch sử và nhật ký. Phải gọi trong withLock. */
function transition(leave, to, actorId, note, delegationId, extraPatch) {
  if (!canTransition(leave.status, to)) {
    fail('BAD_STATE', 'Đơn đang ở trạng thái "' + ST_LABEL[leave.status] + '", không thể chuyển sang "' + ST_LABEL[to] + '".');
  }
  var from = leave.status;
  var patch = extraPatch || {};
  patch.status = to;
  var updated = db_update('LeaveRequests', leave.id, patch, actorId);
  db_insert('LeaveStatusHistory', {
    leaveRequestId: leave.id, fromStatus: from, toStatus: to, actorId: actorId, delegationId: delegationId || '',
    note: note || '', at: nowIso()
  }, actorId);
  audit(actorId, 'leave.' + from.toLowerCase() + '_to_' + to.toLowerCase(), 'LeaveRequests', leave.id,
    { status: from }, { status: to, note: note || '', delegationId: delegationId || '', version: updated.currentVersion });
  return updated;
}

function getLeaveOrFail(id) {
  var l = db_get('LeaveRequests', id);
  if (!l) fail('NOT_FOUND', 'Không tìm thấy đơn.');
  return l;
}

function requireOwner(ctx, leave) {
  if (leave.userId !== ctx.user.id) fail('FORBIDDEN', 'Bạn chỉ thao tác được trên đơn của mình.');
}

/** Chuẩn hóa và kiểm tra dữ liệu đơn. complete=true khi gửi đơn. */
function normalizeLeaveInput(ctx, p, complete) {
  var out = {};
  out.sourceType = p.sourceType === 'UPLOAD' ? 'UPLOAD' : 'TEMPLATE';
  out.leaveTypeId = p.leaveTypeId || '';
  out.otherNote = String(p.otherNote || '').trim().slice(0, 300);
  out.startDate = p.startDate || '';
  out.startSession = p.startSession || 'AM';
  out.endDate = p.endDate || p.startDate || '';
  out.endSession = p.endSession || 'PM';
  out.reason = String(p.reason || '').trim().slice(0, 2000);
  out.contactPhone = String(p.contactPhone || ctx.user.phone || '').trim().slice(0, 20);
  out.uploadedFileId = out.sourceType === 'UPLOAD' ? (p.uploadedFileId || '') : '';
  var allowedCampuses = userCampusIds(ctx.user.id);
  out.campusIds = (p.campusIds || []).filter(function (c) { return allowedCampuses.indexOf(c) >= 0; });
  if (!out.campusIds.length && allowedCampuses.length === 1) out.campusIds = allowedCampuses.slice();
  out.attachmentIds = (p.attachmentIds || []).slice(0, 20);
  out.sessions = '';
  out.days = '';
  if (out.startDate && out.endDate) {
    var c = calcLeave(out.startDate, out.startSession, out.endDate, out.endSession);
    out.sessions = String(c.sessions);
    out.days = String(c.days);
  }
  if (complete) {
    var type = db_get('LeaveTypes', out.leaveTypeId);
    assert(type && type.status !== 'DISABLED', 'INVALID', 'Chọn loại nghỉ.');
    if (toBool(type.requiresNote)) assert(out.otherNote, 'INVALID', 'Loại "' + type.name + '" cần ghi rõ nội dung.');
    assert(out.startDate && out.endDate, 'INVALID', 'Chọn thời gian nghỉ.');
    assert(out.reason, 'INVALID', 'Nhập lý do nghỉ.');
    assert(out.campusIds.length > 0, 'INVALID', 'Chọn điểm trường liên quan.');
    if (out.sourceType === 'UPLOAD') {
      assert(out.uploadedFileId, 'INVALID', 'Chưa tải lên đơn của bạn.');
      checkUploadOwner(out.uploadedFileId, ctx.user.id, 'leave-source');
    }
  }
  if (out.uploadedFileId) checkUploadOwner(out.uploadedFileId, ctx.user.id, 'leave-source');
  out.attachmentIds.forEach(function (fid) { checkUploadOwner(fid, ctx.user.id, null); });
  return out;
}

function api_leave_calc(ctx, p) {
  var c = calcLeave(p.startDate, p.startSession, p.endDate, p.endSession);
  return { sessions: c.sessions, days: c.days };
}

/** Lưu bản nháp (tạo mới hoặc sửa). Cũng dùng khi sửa đơn ở trạng thái Yêu cầu bổ sung. */
function api_leave_save(ctx, p) {
  if (!canSubmitLeave(ctx)) fail('FORBIDDEN', 'Tài khoản của bạn không tạo đơn trong hệ thống.');
  return withLock(function () {
    var data = normalizeLeaveInput(ctx, p, false);
    var rec = {
      sourceType: data.sourceType, leaveTypeId: data.leaveTypeId, otherNote: data.otherNote,
      startDate: data.startDate, startSession: data.startSession, endDate: data.endDate, endSession: data.endSession,
      sessions: data.sessions, days: data.days, reason: data.reason, contactPhone: data.contactPhone,
      uploadedFileId: data.uploadedFileId, campusIds: JSON.stringify(data.campusIds),
      attachmentIds: JSON.stringify(data.attachmentIds)
    };
    var leave;
    if (p.id) {
      leave = getLeaveOrFail(p.id);
      requireOwner(ctx, leave);
      if ([ST.DRAFT, ST.NEED_CHANGES].indexOf(leave.status) < 0) fail('BAD_STATE', 'Chỉ sửa được bản nháp hoặc đơn được yêu cầu bổ sung.');
      leave = db_update('LeaveRequests', leave.id, rec, ctx.user.id, p.rowVersion);
    } else {
      rec.userId = ctx.user.id;
      rec.status = ST.DRAFT;
      rec.currentVersion = '0';
      leave = db_insert('LeaveRequests', rec, ctx.user.id);
    }
    keepDraftFiles(data.attachmentIds.concat(data.uploadedFileId ? [data.uploadedFileId] : []));
    return leaveDetail(ctx, leave);
  });
}

function api_leave_deleteDraft(ctx, p) {
  return withLock(function () {
    var leave = getLeaveOrFail(p.id);
    requireOwner(ctx, leave);
    if (leave.status !== ST.DRAFT || leave.currentVersion !== '0') fail('BAD_STATE', 'Chỉ xóa được bản nháp chưa gửi lần nào.');
    db_delete('LeaveRequests', leave.id);
    return true;
  });
}

function buildSnapshot(ctx, campusIds) {
  var deps = departmentMap(), cmap = campusMap();
  var assigned = userCampusIds(ctx.user.id);
  return {
    fullName: ctx.user.fullName, staffCode: ctx.user.staffCode, positionTitle: ctx.user.positionTitle,
    departmentId: ctx.user.departmentId, departmentName: deps[ctx.user.departmentId] ? deps[ctx.user.departmentId].name : '',
    assignedCampusIds: assigned, assignedCampusNames: assigned.map(function (c) { return cmap[c] ? cmap[c].name : ''; }),
    selectedCampusIds: campusIds, selectedCampusNames: campusIds.map(function (c) { return cmap[c] ? cmap[c].name : ''; }),
    at: nowIso()
  };
}

function findOverlaps(leave, excludeUserCheck) {
  return db_filter('LeaveRequests', function (o) {
    if (o.id === leave.id) return false;
    if (!excludeUserCheck && o.userId !== leave.userId) return false;
    if (ACTIVE_FOR_OVERLAP.indexOf(o.status) < 0) return false;
    return leavesOverlap(o, leave);
  });
}

/** Gửi ký: khóa nội dung thành một phiên bản mới, chuyển sang Chờ ký người gửi. */
function api_leave_submit(ctx, p) {
  if (!canSubmitLeave(ctx)) fail('FORBIDDEN', 'Tài khoản của bạn không tạo đơn trong hệ thống.');
  return withLock(function () {
    var leave = getLeaveOrFail(p.id);
    requireOwner(ctx, leave);
    if ([ST.DRAFT, ST.NEED_CHANGES].indexOf(leave.status) < 0) fail('BAD_STATE', 'Đơn không ở trạng thái có thể gửi.');
    var data = normalizeLeaveInput(ctx, {
      sourceType: leave.sourceType, leaveTypeId: leave.leaveTypeId, otherNote: leave.otherNote,
      startDate: leave.startDate, startSession: leave.startSession, endDate: leave.endDate, endSession: leave.endSession,
      reason: leave.reason, contactPhone: leave.contactPhone, uploadedFileId: leave.uploadedFileId,
      campusIds: parseJson(leave.campusIds, []), attachmentIds: parseJson(leave.attachmentIds, [])
    }, true);
    var probe = { id: leave.id, userId: leave.userId, startDate: data.startDate, startSession: data.startSession, endDate: data.endDate, endSession: data.endSession };
    var dup = findOverlaps(probe, false);
    if (dup.length) {
      var d0 = dup[0];
      fail('OVERLAP', 'Bạn đã có đơn ' + (d0.code || '(chưa có mã)') + ' (' + ST_LABEL[d0.status] + ') trùng thời gian: ' + describePeriod(d0) + '. Không gửi được đơn trùng.');
    }
    var year = yearForDate(data.startDate);
    if (!year || year.status !== 'OPEN') fail('NO_YEAR', 'Ngày nghỉ không thuộc năm học đang mở.');
    var patch = {};
    var firstTime = !leave.code;
    if (firstTime) {
      var n = nextCounter('LEAVE_' + year.id);
      patch.code = 'DXN-' + year.name.slice(0, 4) + '-' + ('000' + n).slice(-4);
      patch.academicYearId = year.id;
      patch.snapshotJson = JSON.stringify(buildSnapshot(ctx, data.campusIds));
      patch.isRetroactive = data.startDate < todayStr() ? 'TRUE' : 'FALSE';
      db_filter('LeaveRequestCampuses', function (x) { return x.leaveRequestId === leave.id; }).forEach(function (x) { db_delete('LeaveRequestCampuses', x.id); });
      data.campusIds.forEach(function (c) { db_insert('LeaveRequestCampuses', { leaveRequestId: leave.id, campusId: c }, ctx.user.id); });
    }
    var version = (parseInt(leave.currentVersion, 10) || 0) + 1;
    var code = patch.code || leave.code;
    var content = {
      leaveTypeId: data.leaveTypeId, leaveTypeName: db_get('LeaveTypes', data.leaveTypeId).name, otherNote: data.otherNote,
      startDate: data.startDate, startSession: data.startSession, endDate: data.endDate, endSession: data.endSession,
      sessions: data.sessions, days: data.days, reason: data.reason, contactPhone: data.contactPhone,
      campusIds: data.campusIds, sourceType: data.sourceType, uploadedFileId: data.uploadedFileId
    };
    // Tệp đính kèm: chuyển về thư mục của đơn và ghi lại.
    var yearName = year.name.replace(/\s/g, '');
    var attFolder = data.attachmentIds.length ? folderPath('DinhKem/' + yearName + '/' + code) : null;
    data.attachmentIds.forEach(function (fid) {
      var already = db_find('LeaveRequestAttachments', function (a) { return a.fileId === fid && a.leaveRequestId === leave.id; });
      if (already) return;
      var f = DriveApp.getFileById(fid);
      f.moveTo(attFolder);
      var blob = f.getBlob();
      db_insert('LeaveRequestAttachments', {
        leaveRequestId: leave.id, version: String(version), fileId: fid, fileName: f.getName(), mimeType: blob.getContentType(),
        size: String(f.getSize()), sha256: sha256Hex(blob.getBytes())
      }, ctx.user.id);
    });
    if (data.sourceType === 'UPLOAD') {
      var src = DriveApp.getFileById(data.uploadedFileId);
      src.moveTo(folderPath('PDF/' + yearName + '/' + code));
      src.setName('nguon_v' + version + '.pdf');
    }
    var tpl = activeTemplate();
    db_insert('LeaveRequestVersions', {
      leaveRequestId: leave.id, version: String(version), contentJson: JSON.stringify(content),
      contentHash: sha256Hex(JSON.stringify(content)), templateVersionId: tpl ? tpl.id : '',
      reason: leave.status === ST.NEED_CHANGES ? 'Bổ sung theo yêu cầu' : 'Gửi lần đầu'
    }, ctx.user.id);
    patch.currentVersion = String(version);
    patch.sessions = data.sessions;
    patch.days = data.days;
    var updated = transition(leave, ST.WAIT_SIGN, ctx.user.id, '', '', patch);
    return leaveDetail(ctx, updated);
  });
}

function currentVersionRow(leave) {
  return db_find('LeaveRequestVersions', function (v) { return v.leaveRequestId === leave.id && v.version === String(leave.currentVersion); });
}

function signMode() {
  var m = setting('SIGN_MODE');
  if (m === 'SMARTCA') fail('SIGN_NOT_CONFIGURED', 'SmartCA chưa được cấu hình (chưa có tài khoản tích hợp từ VNPT). Quản trị viên cần bật chế độ ảnh chữ ký hoặc cấu hình SmartCA.');
  if (m !== 'IMAGE') fail('SIGN_NOT_CONFIGURED', 'Chế độ ký chưa được bật. Quản trị viên chính cần chọn chế độ ký trong Cấu hình.');
  return m;
}

function requireSignature(user) {
  if (!user.signatureFileId) fail('NO_SIGNATURE', 'Bạn chưa có ảnh chữ ký. Vào Cá nhân → Ảnh chữ ký để tải lên trước.');
}

/** Người gửi chèn chữ ký: Chờ ký người gửi → Chờ duyệt. */
function api_leave_sign(ctx, p) {
  return withLock(function () {
    var leave = getLeaveOrFail(p.id);
    requireOwner(ctx, leave);
    if (leave.status !== ST.WAIT_SIGN) fail('BAD_STATE', 'Đơn không ở trạng thái chờ ký.');
    var mode = signMode();
    requireSignature(ctx.user);
    var ver = currentVersionRow(leave);
    var yearName = db_get('AcademicYears', leave.academicYearId).name.replace(/\s/g, '');
    var folder = folderPath('PDF/' + yearName + '/' + leave.code);
    var pdfFile, placement = {};
    if (leave.sourceType === 'TEMPLATE') {
      var blob = renderLeavePdf(leave, ver, { sender: { userId: ctx.user.id, fileId: ctx.user.signatureFileId, at: nowIso() } });
      pdfFile = folder.createFile(blob.setName('v' + ver.version + '.pdf'));
    } else {
      assert(p.signedFileId, 'INVALID', 'Thiếu tệp đơn đã chèn chữ ký.');
      checkUploadOwner(p.signedFileId, ctx.user.id, 'signed-pdf');
      pdfFile = DriveApp.getFileById(p.signedFileId);
      assertPdf(pdfFile.getBlob().getBytes());
      pdfFile.moveTo(folder);
      pdfFile.setName('v' + ver.version + '.pdf');
      placement = p.placement || {};
    }
    var pdfHash = sha256Hex(pdfFile.getBlob().getBytes());
    placement.sigFileId = ctx.user.signatureFileId;
    db_update('LeaveRequestVersions', ver.id, { pdfFileId: pdfFile.getId(), pdfHash: pdfHash }, ctx.user.id);
    db_insert('LeaveRequestSignatures', {
      leaveRequestId: leave.id, version: ver.version, signerId: ctx.user.id, role: 'SENDER', mode: mode,
      placementJson: JSON.stringify(placement), status: 'DONE', signedPdfFileId: pdfFile.getId(), contentHash: pdfHash, at: nowIso()
    }, ctx.user.id);
    var patch = { signMode: mode, remindedMarks: '' };
    if (!leave.submittedAt) patch.submittedAt = nowIso();
    var updated = transition(leave, ST.PENDING, ctx.user.id, 'Người gửi đã ký (phiên bản ' + ver.version + ')', '', patch);
    notifyDeciders(updated, ver.version > 1 ? 'Đơn đã bổ sung chờ duyệt' : 'Đơn mới chờ duyệt');
    return leaveDetail(ctx, updated);
  });
}

function api_leave_withdraw(ctx, p) {
  return withLock(function () {
    var leave = getLeaveOrFail(p.id);
    requireOwner(ctx, leave);
    if (leave.status !== ST.PENDING) fail('BAD_STATE', 'Chỉ thu hồi được đơn đang chờ duyệt.');
    var updated = transition(leave, ST.WITHDRAWN, ctx.user.id, String(p.note || '').slice(0, 500), '', {});
    notifyUsers(decisionMakerIds(), {
      type: 'LEAVE_WITHDRAWN', title: 'Đơn đã được thu hồi',
      body: ownerName(updated) + ' đã thu hồi đơn ' + updated.code + ' (' + describePeriod(updated) + ').',
      link: '#/leave/' + updated.id
    }, false, ctx.user.id);
    return leaveDetail(ctx, updated);
  });
}

function requireDecision(ctx, leave) {
  var r = decisionRight(ctx, leave);
  if (!r.ok) fail('FORBIDDEN', 'Bạn không có quyền xử lý đơn này (chỉ Hiệu trưởng hoặc PHT đang được ủy quyền hợp lệ).');
  return r;
}

/** Duyệt và ký: Chờ duyệt → Đã duyệt/Đã ký. */
function api_leave_approve(ctx, p) {
  return withLock(function () {
    var leave = getLeaveOrFail(p.id);
    if (leave.status !== ST.PENDING) fail('BAD_STATE', 'Đơn đã được xử lý hoặc không còn chờ duyệt.');
    if (p.rowVersion && String(p.rowVersion) !== leave.rowVersion) fail('CONFLICT', 'Đơn vừa thay đổi. Vui lòng tải lại trước khi duyệt.');
    var right = requireDecision(ctx, leave);
    var mode = signMode();
    requireSignature(ctx.user);
    var ver = currentVersionRow(leave);
    var yearName = db_get('AcademicYears', leave.academicYearId).name.replace(/\s/g, '');
    var folder = folderPath('PDF/' + yearName + '/' + leave.code);
    var finalFile, placement = {};
    if (leave.sourceType === 'TEMPLATE') {
      var senderSig = db_find('LeaveRequestSignatures', function (s) { return s.leaveRequestId === leave.id && s.version === ver.version && s.role === 'SENDER'; });
      var sp = parseJson(senderSig && senderSig.placementJson, {});
      var blob = renderLeavePdf(leave, ver, {
        sender: { userId: leave.userId, fileId: sp.sigFileId, at: senderSig ? senderSig.at : '' },
        approver: { userId: ctx.user.id, fileId: ctx.user.signatureFileId, at: nowIso(), delegated: !!right.delegation },
        stamp: true
      });
      finalFile = folder.createFile(blob.setName('final.pdf'));
    } else {
      assert(p.signedFileId, 'INVALID', 'Thiếu tệp đơn đã chèn chữ ký duyệt.');
      checkUploadOwner(p.signedFileId, ctx.user.id, 'signed-pdf');
      finalFile = DriveApp.getFileById(p.signedFileId);
      assertPdf(finalFile.getBlob().getBytes());
      finalFile.moveTo(folder);
      finalFile.setName('final.pdf');
      placement = p.placement || {};
    }
    var hash = sha256Hex(finalFile.getBlob().getBytes());
    placement.sigFileId = ctx.user.signatureFileId;
    db_insert('LeaveRequestSignatures', {
      leaveRequestId: leave.id, version: ver.version, signerId: ctx.user.id, role: 'APPROVER', mode: mode,
      placementJson: JSON.stringify(placement), status: 'DONE', signedPdfFileId: finalFile.getId(), contentHash: hash, at: nowIso()
    }, ctx.user.id);
    db_insert('LeaveRequestApprovals', {
      leaveRequestId: leave.id, version: ver.version, decision: 'APPROVE', deciderId: ctx.user.id,
      delegationId: right.delegation ? right.delegation.id : '', note: String(p.note || '').slice(0, 1000), at: nowIso()
    }, ctx.user.id);
    var updated = transition(leave, ST.APPROVED, ctx.user.id, p.note || '', right.delegation ? right.delegation.id : '',
      { finalPdfFileId: finalFile.getId(), decidedAt: nowIso() });
    deductForLeave(updated, ctx.user.id);
    var period = describePeriod(updated);
    notifyUsers([updated.userId], {
      type: 'LEAVE_APPROVED', title: 'Đơn của bạn đã được duyệt',
      body: 'Đơn ' + updated.code + ' (' + typeName(updated) + ', ' + period + ') đã được duyệt và ký.', link: '#/leave/' + updated.id
    }, true, ctx.user.id);
    notifyUsers(managerIds().filter(function (id) { return id !== updated.userId; }), {
      type: 'LEAVE_APPROVED_INFO', title: 'Đơn nghỉ đã duyệt',
      body: ownerName(updated) + ' nghỉ ' + period + ' (' + typeName(updated) + '). Mã đơn ' + updated.code + '.', link: '#/leave/' + updated.id
    }, 'optin', ctx.user.id);
    return leaveDetail(ctx, updated);
  });
}

function decide(ctx, p, to, decision, title) {
  return withLock(function () {
    var leave = getLeaveOrFail(p.id);
    if (leave.status !== ST.PENDING) fail('BAD_STATE', 'Đơn đã được xử lý hoặc không còn chờ duyệt.');
    var right = requireDecision(ctx, leave);
    var note = String(p.note || '').trim().slice(0, 1000);
    assert(note, 'INVALID', to === ST.REJECTED ? 'Bắt buộc ghi lý do từ chối.' : 'Ghi rõ nội dung cần bổ sung.');
    db_insert('LeaveRequestApprovals', {
      leaveRequestId: leave.id, version: leave.currentVersion, decision: decision, deciderId: ctx.user.id,
      delegationId: right.delegation ? right.delegation.id : '', note: note, at: nowIso()
    }, ctx.user.id);
    var updated = transition(leave, to, ctx.user.id, note, right.delegation ? right.delegation.id : '',
      to === ST.REJECTED ? { decidedAt: nowIso() } : {});
    notifyUsers([updated.userId], {
      type: 'LEAVE_' + decision, title: title,
      body: 'Đơn ' + updated.code + ' (' + describePeriod(updated) + '): ' + note, link: '#/leave/' + updated.id
    }, true, ctx.user.id);
    return leaveDetail(ctx, updated);
  });
}

function api_leave_reject(ctx, p) { return decide(ctx, p, ST.REJECTED, 'REJECT', 'Đơn của bạn bị từ chối'); }
function api_leave_requestChanges(ctx, p) { return decide(ctx, p, ST.NEED_CHANGES, 'REQUEST_CHANGES', 'Đơn của bạn cần bổ sung'); }

/** Chỉ Hiệu trưởng hủy đơn đã duyệt. Hoàn phép, giữ nguyên PDF cũ. */
function api_leave_cancel(ctx, p) {
  requirePrincipal(ctx);
  return withLock(function () {
    var leave = getLeaveOrFail(p.id);
    if (leave.status !== ST.APPROVED) fail('BAD_STATE', 'Chỉ hủy được đơn đã duyệt.');
    var note = String(p.note || '').trim().slice(0, 1000);
    assert(note, 'INVALID', 'Bắt buộc ghi lý do hủy.');
    db_insert('LeaveRequestApprovals', {
      leaveRequestId: leave.id, version: leave.currentVersion, decision: 'CANCEL', deciderId: ctx.user.id, note: note, at: nowIso()
    }, ctx.user.id);
    var updated = transition(leave, ST.CANCELLED, ctx.user.id, note, '', {});
    reverseForLeave(updated, ctx.user.id, 'Hủy đơn ' + updated.code + ': ' + note);
    notifyUsers([updated.userId], {
      type: 'LEAVE_CANCELLED', title: 'Đơn đã duyệt bị hủy',
      body: 'Hiệu trưởng đã hủy đơn ' + updated.code + ' (' + describePeriod(updated) + '). Lý do: ' + note, link: '#/leave/' + updated.id
    }, true, ctx.user.id);
    notifyUsers(managerIds().filter(function (id) { return id !== updated.userId; }), {
      type: 'LEAVE_CANCELLED_INFO', title: 'Đơn nghỉ đã bị hủy',
      body: 'Đơn ' + updated.code + ' của ' + ownerName(updated) + ' (' + describePeriod(updated) + ') đã bị hủy.', link: '#/leave/' + updated.id
    }, false, ctx.user.id);
    return leaveDetail(ctx, updated);
  });
}

/* ---------------- Đọc dữ liệu ---------------- */

function typeName(leave) {
  var t = db_get('LeaveTypes', leave.leaveTypeId);
  return t ? (toBool(t.requiresNote) && leave.otherNote ? t.name + ': ' + leave.otherNote : t.name) : '';
}

function ownerName(leave) {
  var snap = parseJson(leave.snapshotJson, null);
  if (snap && snap.fullName) return snap.fullName;
  var u = db_get('Users', leave.userId);
  return u ? u.fullName : '';
}

function leaveSummary(leave) {
  var snap = parseJson(leave.snapshotJson, {});
  var cmap = campusMap();
  var campusIds = parseJson(leave.campusIds, []);
  return {
    id: leave.id, code: leave.code, status: leave.status, statusLabel: ST_LABEL[leave.status],
    userId: leave.userId, fullName: ownerName(leave), departmentName: snap.departmentName || '',
    leaveTypeId: leave.leaveTypeId, typeName: typeName(leave), period: leave.startDate ? describePeriod(leave) : '',
    startDate: leave.startDate, startSession: leave.startSession, endDate: leave.endDate, endSession: leave.endSession,
    days: Number(leave.days) || 0, sessions: Number(leave.sessions) || 0, submittedAt: leave.submittedAt,
    decidedAt: leave.decidedAt, updatedAt: leave.updatedAt, isRetroactive: toBool(leave.isRetroactive),
    sourceType: leave.sourceType, campusNames: campusIds.map(function (c) { return cmap[c] ? cmap[c].name : ''; }).filter(String)
  };
}

function leaveDetail(ctx, leave) {
  db_resetCache();
  leave = db_get('LeaveRequests', leave.id);
  var names = userNameMap();
  var s = leaveSummary(leave);
  s.rowVersion = leave.rowVersion;
  s.otherNote = leave.otherNote;
  s.reason = leave.reason;
  s.contactPhone = leave.contactPhone;
  s.campusIds = parseJson(leave.campusIds, []);
  s.attachmentIds = parseJson(leave.attachmentIds, []);
  s.uploadedFileId = leave.uploadedFileId;
  s.currentVersion = Number(leave.currentVersion) || 0;
  s.signMode = leave.signMode;
  s.hasFinalPdf = !!leave.finalPdfFileId;
  s.snapshot = parseJson(leave.snapshotJson, null);
  s.history = db_filter('LeaveStatusHistory', function (h) { return h.leaveRequestId === leave.id; }).map(function (h) {
    return { at: h.at, from: h.fromStatus, to: h.toStatus, toLabel: ST_LABEL[h.toStatus], actor: names[h.actorId] || '', note: h.note, delegated: !!h.delegationId };
  });
  s.versions = db_filter('LeaveRequestVersions', function (v) { return v.leaveRequestId === leave.id; }).map(function (v) {
    return { version: Number(v.version), reason: v.reason, createdAt: v.createdAt, hasPdf: !!v.pdfFileId, content: parseJson(v.contentJson, {}) };
  });
  s.attachments = db_filter('LeaveRequestAttachments', function (a) { return a.leaveRequestId === leave.id; }).map(function (a) {
    return { id: a.id, fileName: a.fileName, mimeType: a.mimeType, size: Number(a.size), version: Number(a.version) };
  });
  s.decisions = db_filter('LeaveRequestApprovals', function (a) { return a.leaveRequestId === leave.id; }).map(function (a) {
    return { decision: a.decision, by: names[a.deciderId] || '', delegated: !!a.delegationId, note: a.note, at: a.at, version: Number(a.version) };
  });
  // Quyền thao tác để giao diện hiện nút (máy chủ vẫn kiểm tra lại khi thao tác).
  var own = leave.userId === ctx.user.id;
  var right = decisionRight(ctx, leave);
  s.can = {
    edit: own && [ST.DRAFT, ST.NEED_CHANGES].indexOf(leave.status) >= 0,
    deleteDraft: own && leave.status === ST.DRAFT && leave.currentVersion === '0',
    submit: own && [ST.DRAFT, ST.NEED_CHANGES].indexOf(leave.status) >= 0,
    sign: own && leave.status === ST.WAIT_SIGN,
    withdraw: own && leave.status === ST.PENDING,
    decide: right.ok && leave.status === ST.PENDING,
    cancel: isPrincipal(ctx) && leave.status === ST.APPROVED
  };
  if (s.can.decide || isPrincipal(ctx)) {
    s.overlaps = findOverlaps(leave, true).filter(function (o) { return o.userId !== leave.userId && ['PENDING', 'APPROVED'].indexOf(o.status) >= 0; })
      .map(function (o) {
        var sum = leaveSummary(o);
        sum.sharedSlots = overlapSlots(o, leave).length;
        return sum;
      });
    var type = db_get('LeaveTypes', leave.leaveTypeId);
    if (type && toBool(type.deductsAnnual) && leave.academicYearId) {
      var bal = balanceSummary(leave.userId, leave.academicYearId);
      s.balance = bal;
      s.balanceWarning = leave.status === ST.PENDING && (Number(leave.days) || 0) > bal.remaining
        ? 'Số phép năm còn lại (' + formatDays(bal.remaining) + ') không đủ cho đơn này (' + formatDays(leave.days) + ').' : '';
    }
  }
  return s;
}

function api_leave_get(ctx, p) {
  var leave = getLeaveOrFail(p.id);
  if (!canViewLeave(ctx, leave)) fail('FORBIDDEN', 'Bạn không có quyền xem đơn này.');
  return leaveDetail(ctx, leave);
}

function api_leave_listMine(ctx, p) {
  var rows = db_filter('LeaveRequests', function (l) { return l.userId === ctx.user.id; });
  if (p.status) rows = rows.filter(function (l) { return l.status === p.status; });
  if (p.yearId) rows = rows.filter(function (l) { return l.academicYearId === p.yearId || !l.academicYearId; });
  rows.sort(function (a, b) { return (b.updatedAt || '').localeCompare(a.updatedAt || ''); });
  return rows.map(leaveSummary);
}

/** Danh sách cho Ban Giám hiệu, tổ trưởng – đã lọc theo quyền xem. */
function api_leave_listAll(ctx, p) {
  if (!isManager(ctx)) fail('FORBIDDEN', 'Bạn không có quyền xem danh sách này.');
  var q = normalizeVi(p.q || '');
  var rows = db_filter('LeaveRequests', function (l) {
    if (l.status === ST.DRAFT) return false;
    if (!canViewLeave(ctx, l)) return false;
    if (p.status && l.status !== p.status) return false;
    if (p.yearId && l.academicYearId !== p.yearId) return false;
    if (p.leaveTypeId && l.leaveTypeId !== p.leaveTypeId) return false;
    if (p.from && l.endDate < p.from) return false;
    if (p.to && l.startDate > p.to) return false;
    if (p.campusId && parseJson(l.campusIds, []).indexOf(p.campusId) < 0) return false;
    if (p.departmentId && parseJson(l.snapshotJson, {}).departmentId !== p.departmentId) return false;
    if (q) {
      var snap = parseJson(l.snapshotJson, {});
      var hay = normalizeVi([l.code, snap.fullName, snap.staffCode].join(' '));
      if (hay.indexOf(q) < 0) return false;
    }
    return true;
  });
  rows.sort(function (a, b) { return (b.startDate || '').localeCompare(a.startDate || ''); });
  return rows.slice(0, Math.min(parseInt(p.limit, 10) || 300, 1000)).map(leaveSummary);
}

/** Hàng chờ duyệt cho HT / PHT đang được ủy quyền. */
function api_leave_pending(ctx) {
  if (!canDecide(ctx)) return [];
  return db_filter('LeaveRequests', function (l) {
    return l.status === ST.PENDING && decisionRight(ctx, l).ok;
  }).sort(function (a, b) { return (a.submittedAt || '').localeCompare(b.submittedAt || ''); })
    .map(function (l) {
      var s = leaveSummary(l);
      var since = db_filter('LeaveStatusHistory', function (h) { return h.leaveRequestId === l.id && h.toStatus === ST.PENDING; }).pop();
      s.waitingHours = since ? Math.floor((Date.now() - new Date(since.at).getTime()) / 3600000) : 0;
      return s;
    });
}

/** Lấy PDF của đơn (phiên bản hoặc bản hoàn chỉnh) theo từng phần. */
function api_leave_pdf(ctx, p) {
  var leave = getLeaveOrFail(p.id);
  if (!canViewLeave(ctx, leave)) fail('FORBIDDEN', 'Bạn không có quyền xem đơn này.');
  var fileId;
  if (p.which === 'source') {
    // Đơn tải lên chưa ký: chỉ người gửi (khi ký) và người duyệt.
    var ver = currentVersionRow(leave);
    var c = ver ? parseJson(ver.contentJson, {}) : {};
    fileId = (leave.status === ST.WAIT_SIGN || leave.status === ST.DRAFT || leave.status === ST.NEED_CHANGES) ? (c.uploadedFileId || leave.uploadedFileId) : '';
    if (!fileId) fail('NOT_FOUND', 'Không có tệp nguồn.');
  } else if (p.which === 'final' || (!p.version && leave.finalPdfFileId)) {
    fileId = leave.finalPdfFileId;
  } else {
    var vnum = String(p.version || leave.currentVersion);
    var v = db_find('LeaveRequestVersions', function (x) { return x.leaveRequestId === leave.id && x.version === vnum; });
    fileId = v ? v.pdfFileId : '';
  }
  if (!fileId) fail('NOT_FOUND', 'Đơn chưa có tệp PDF.');
  return downloadChunk(fileId, p.offset, (leave.code || 'don') + (p.which === 'final' ? '' : '_v' + (p.version || leave.currentVersion)) + '.pdf');
}

function api_leave_attachment(ctx, p) {
  var a = db_get('LeaveRequestAttachments', p.attachmentId);
  if (!a) fail('NOT_FOUND', 'Không tìm thấy tệp.');
  var leave = getLeaveOrFail(a.leaveRequestId);
  if (!canViewAttachments(ctx, leave)) fail('FORBIDDEN', 'Bạn không có quyền xem tệp này.');
  return downloadChunk(a.fileId, p.offset, a.fileName);
}

/**
 * Audit.gs – nhật ký hệ thống chỉ ghi thêm, mỗi dòng nối mã băm với dòng trước.
 * Ai mở Sheet sửa hoặc xóa một dòng, hàm auditVerify() sẽ chỉ ra chỗ chuỗi bị đứt.
 */

var SECRET_FIELDS = ['passwordHash', 'passwordSalt', 'tokenHash', 'token', 'password', 'newPassword', 'oldPassword'];

function auditScrub(obj) {
  if (!obj || typeof obj !== 'object') return obj;
  var out = {};
  for (var k in obj) {
    if (k === '_row') continue;
    out[k] = SECRET_FIELDS.indexOf(k) >= 0 ? '***' : obj[k];
  }
  return out;
}

function audit(actorId, action, entity, entityId, before, after) {
  var sh = db_sheet('AuditLogs');
  var last = sh.getLastRow();
  var prevHash = '';
  if (last >= 2) {
    var hashCol = db_cols('AuditLogs').indexOf('hash') + 1;
    prevHash = String(sh.getRange(last, hashCol).getValue() || '');
  }
  var row = {
    id: newId('aud'),
    at: nowIso(),
    actorId: actorId || 'system',
    action: action,
    entity: entity || '',
    entityId: entityId || '',
    beforeJson: before ? JSON.stringify(auditScrub(before)) : '',
    afterJson: after ? JSON.stringify(auditScrub(after)) : ''
  };
  row.prevHash = prevHash;
  row.hash = auditHashOf(row);
  sh.appendRow(db_rowValues('AuditLogs', row));
  if (_cache.AuditLogs) delete _cache.AuditLogs;
}

function auditHashOf(row) {
  return sha256Hex([row.prevHash, row.id, row.at, row.actorId, row.action, row.entity, row.entityId,
    row.beforeJson, row.afterJson].join('|'));
}

/** Kiểm tra toàn bộ chuỗi nhật ký. Trả về danh sách dòng bất thường. */
function auditVerify() {
  db_resetCache();
  var rows = db_all('AuditLogs');
  var problems = [];
  var prev = '';
  rows.forEach(function (r) {
    if (r.prevHash !== prev) problems.push({ row: r._row, id: r.id, issue: 'Mất liên kết với dòng trước (có thể bị xóa hoặc chèn).' });
    if (auditHashOf(r) !== r.hash) problems.push({ row: r._row, id: r.id, issue: 'Nội dung dòng đã bị sửa.' });
    prev = r.hash;
  });
  return { total: rows.length, problems: problems };
}

function api_audit_verify(ctx) {
  requirePrimaryAdmin(ctx);
  return auditVerify();
}

function api_audit_list(ctx, p) {
  requirePrimaryAdmin(ctx);
  var rows = db_all('AuditLogs').slice();
  if (p.entityId) rows = rows.filter(function (r) { return r.entityId === p.entityId; });
  if (p.action) rows = rows.filter(function (r) { return r.action.indexOf(p.action) === 0; });
  rows.reverse();
  var users = userNameMap();
  return rows.slice(0, Math.min(parseInt(p.limit, 10) || 200, 1000)).map(function (r) {
    return { at: r.at, actor: users[r.actorId] || r.actorId, action: r.action, entity: r.entity, entityId: r.entityId,
      before: r.beforeJson, after: r.afterJson };
  });
}

/**
 * Main.gs – cửa vào duy nhất của API.
 * ROUTES lưu tên hàm (chuỗi) vì Apps Script nạp từng file theo thứ tự trong dự án.
 * Giao diện (GitHub Pages) gửi POST text/plain chứa JSON: {action, token, payload, requestId}.
 */

var ROUTES = {
  // không cần đăng nhập
  'app.bootstrap': { fn: 'api_app_bootstrap', auth: false },
  'auth.login': { fn: 'api_auth_login', auth: false },
  'auth.requestReset': { fn: 'api_auth_requestReset', auth: false },
  'auth.confirmReset': { fn: 'api_auth_confirmReset', auth: false },
  // tài khoản của tôi
  'auth.logout': { fn: 'api_auth_logout' },
  'auth.changePassword': { fn: 'api_auth_changePassword' },
  'auth.sessions': { fn: 'api_auth_sessions' },
  'auth.revokeSession': { fn: 'api_auth_revokeSession' },
  'me.bootstrap': { fn: 'api_me_bootstrap' },
  'me.update': { fn: 'api_me_update' },
  'me.signature.upload': { fn: 'api_me_signature_upload' },
  'me.signature.get': { fn: 'api_me_signature_get' },
  'me.stamp.get': { fn: 'api_me_stamp_get' },
  // đơn
  'leave.calc': { fn: 'api_leave_calc' },
  'leave.save': { fn: 'api_leave_save', write: true },
  'leave.deleteDraft': { fn: 'api_leave_deleteDraft', write: true },
  'leave.submit': { fn: 'api_leave_submit', write: true },
  'leave.sign': { fn: 'api_leave_sign', write: true },
  'leave.withdraw': { fn: 'api_leave_withdraw', write: true },
  'leave.approve': { fn: 'api_leave_approve', write: true },
  'leave.reject': { fn: 'api_leave_reject', write: true },
  'leave.requestChanges': { fn: 'api_leave_requestChanges', write: true },
  'leave.cancel': { fn: 'api_leave_cancel', write: true },
  'leave.get': { fn: 'api_leave_get' },
  'leave.listMine': { fn: 'api_leave_listMine' },
  'leave.listAll': { fn: 'api_leave_listAll' },
  'leave.pending': { fn: 'api_leave_pending' },
  'leave.pdf': { fn: 'api_leave_pdf' },
  'leave.attachment': { fn: 'api_leave_attachment' },
  // tệp
  'files.uploadChunk': { fn: 'api_files_uploadChunk' },
  'files.info': { fn: 'api_files_info' },
  'files.downloadOwn': { fn: 'api_files_downloadOwn' },
  // ủy quyền, phép năm
  'delegation.list': { fn: 'api_delegation_list' },
  'delegation.create': { fn: 'api_delegation_create', write: true },
  'delegation.end': { fn: 'api_delegation_end', write: true },
  'balance.list': { fn: 'api_balance_list' },
  'balance.set': { fn: 'api_balance_set', write: true },
  'balance.history': { fn: 'api_balance_history' },
  // thông báo, trang chủ
  'notify.list': { fn: 'api_notify_list' },
  'notify.markRead': { fn: 'api_notify_markRead' },
  'dash.home': { fn: 'api_dash_home' },
  // quản trị
  'users.list': { fn: 'api_users_list' },
  'users.options': { fn: 'api_users_options' },
  'users.create': { fn: 'api_users_create', write: true },
  'users.update': { fn: 'api_users_update', write: true },
  'users.setStatus': { fn: 'api_users_setStatus', write: true },
  'users.resetPassword': { fn: 'api_users_resetPassword', write: true },
  'users.revokeAll': { fn: 'api_users_revokeAll' },
  'users.import': { fn: 'api_users_import' },
  'org.campuses.update': { fn: 'api_org_campuses_update' },
  'org.departments.list': { fn: 'api_org_departments_list' },
  'org.departments.save': { fn: 'api_org_departments_save' },
  'org.departments.delete': { fn: 'api_org_departments_delete' },
  'settings.get': { fn: 'api_settings_get' },
  'settings.update': { fn: 'api_settings_update' },
  'settings.uploadImage': { fn: 'api_settings_uploadImage' },
  'templates.preview': { fn: 'api_templates_preview' },
  'audit.list': { fn: 'api_audit_list' },
  'audit.verify': { fn: 'api_audit_verify' }
};

/** Các thao tác vẫn cho phép khi tài khoản bắt buộc đổi mật khẩu. */
var ALLOWED_WHEN_MUST_CHANGE = ['auth.changePassword', 'auth.logout', 'me.bootstrap'];

function doGet() {
  return jsonOut({ ok: true, data: { app: 'He thong don xin nghi', env: envName(), version: APP_VERSION } });
}

function doPost(e) {
  var req;
  try {
    req = JSON.parse(e && e.postData ? e.postData.contents : '{}');
  } catch (err) {
    return jsonOut({ ok: false, error: { code: 'BAD_REQUEST', message: 'Yêu cầu không hợp lệ.' } });
  }
  return jsonOut(handleRequest(req));
}

/** Tách riêng để kiểm thử không cần web app. */
function handleRequest(req) {
  db_resetCache();
  try {
    var route = ROUTES[req.action];
    if (!route) fail('UNKNOWN_ACTION', 'Thao tác không tồn tại.');
    var ctx = { user: null, roles: { codes: {}, adminPerms: {} } };
    if (route.auth !== false) {
      var s = loadSession(req.token);
      ctx.user = s.user;
      ctx.session = s.session;
      ctx.roles = s.roles;
      if (toBool(ctx.user.mustChangePassword) && ALLOWED_WHEN_MUST_CHANGE.indexOf(req.action) < 0) {
        fail('MUST_CHANGE_PASSWORD', 'Bạn cần đổi mật khẩu trước khi sử dụng.');
      }
    }
    var payload = req.payload || {};
    if (route.write && req.requestId) {
      var prev = db_find('RequestKeys', function (r) { return r.requestId === String(req.requestId); });
      if (prev) return { ok: true, duplicate: true, data: parseJson(prev.resultJson, null) };
    }
    // Tra hàm theo tên lúc chạy: Apps Script nạp các file theo thứ tự nên không tham chiếu hàm khi khai báo ROUTES.
    var fn = globalThis[route.fn];
    if (typeof fn !== 'function') fail('SERVER', 'Thiếu hàm xử lý ' + route.fn);
    var data = fn(ctx, payload);
    if (route.write && req.requestId) {
      var json = JSON.stringify(data);
      withLock(function () {
        db_insert('RequestKeys', { requestId: String(req.requestId).slice(0, 64), action: req.action, resultJson: json.length < 40000 ? json : '', at: nowIso() });
      });
    }
    return { ok: true, data: data };
  } catch (err) {
    if (err instanceof AppError) return { ok: false, error: { code: err.code, message: err.message, data: err.data } };
    console.error(err && err.stack ? err.stack : err);
    return { ok: false, error: { code: 'SERVER', message: 'Lỗi máy chủ: ' + (err && err.message ? err.message : err) } };
  }
}

function jsonOut(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

/** Chạy mỗi giờ: nhắc duyệt, gửi lại email, dọn tệp tạm, xóa khóa chống gửi lặp cũ. */
function cronHourly() {
  var jobs = [remindPendingLeaves, retryPendingEmails, cleanupTemp, cleanupRequestKeys];
  jobs.forEach(function (job) {
    try {
      db_resetCache();
      withLock(job);
    } catch (e) {
      console.error('cronHourly ' + job.name + ': ' + e);
    }
  });
}

function cleanupRequestKeys() {
  var limit = Date.now() - 7 * 86400000;
  var old = db_filter('RequestKeys', function (r) { return new Date(r.at).getTime() < limit; });
  // xóa từ dưới lên để số dòng không bị lệch
  old.sort(function (a, b) { return b._row - a._row; }).forEach(function (r) { db_sheet('RequestKeys').deleteRow(r._row); });
  db_resetCache();
}

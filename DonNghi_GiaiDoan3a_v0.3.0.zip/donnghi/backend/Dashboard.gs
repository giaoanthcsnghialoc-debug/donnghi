/**
 * Dashboard.gs – số liệu trang chủ theo vai trò và cấu hình ứng dụng.
 * Báo cáo đầy đủ, xuất Excel/PDF thuộc Giai đoạn 3b.
 */

function leaveCoversToday(l, today) {
  return l.startDate <= today && today <= l.endDate;
}

function todaySessions(l, today) {
  var c = calcLeaveSafe(l);
  if (!c) return [];
  return c.slots.filter(function (s) { return s.indexOf(today) === 0; }).map(function (s) { return s.slice(-2); });
}

function api_dash_home(ctx) {
  var today = todayStr();
  var out = { today: today, unread: unreadCount(ctx.user.id) };
  var mine = db_filter('LeaveRequests', function (l) { return l.userId === ctx.user.id; });
  var count = function (arr, st) { return arr.filter(function (l) { return l.status === st; }).length; };
  out.mine = {
    total: mine.filter(function (l) { return l.status !== 'DRAFT'; }).length,
    draft: count(mine, 'DRAFT'), waitSign: count(mine, 'WAIT_SIGN'), pending: count(mine, 'PENDING'),
    needChanges: count(mine, 'NEED_CHANGES'), approved: count(mine, 'APPROVED'), rejected: count(mine, 'REJECTED'),
    upcoming: mine.filter(function (l) { return l.status === 'APPROVED' && l.endDate >= today; })
      .sort(function (a, b) { return a.startDate.localeCompare(b.startDate); }).slice(0, 5).map(leaveSummary)
  };
  if (isManager(ctx)) {
    var approved = db_filter('LeaveRequests', function (l) { return l.status === 'APPROVED'; });
    var absent = approved.filter(function (l) { return leaveCoversToday(l, today); }).map(function (l) {
      var s = leaveSummary(l);
      s.todaySessions = todaySessions(l, today);
      return s;
    }).filter(function (s) { return s.todaySessions.length; });
    var in7 = ymd(new Date(parseYmd(today).getTime() + 7 * 86400000));
    out.manager = {
      absentToday: absent,
      upcoming: approved.filter(function (l) { return l.startDate > today && l.startDate <= in7; })
        .sort(function (a, b) { return a.startDate.localeCompare(b.startDate); }).map(leaveSummary),
      byCampusToday: groupCount(absent, 'campusNames')
    };
  }
  if (canDecide(ctx)) {
    var pend = api_leave_pending(ctx);
    out.decider = {
      pendingCount: pend.length,
      pending: pend.slice(0, 10),
      overdue: pend.filter(function (p) { return p.waitingHours >= 24; }).length
    };
  }
  return out;
}

function groupCount(items, key) {
  var m = {};
  items.forEach(function (it) { (it[key] || []).forEach(function (k) { m[k] = (m[k] || 0) + 1; }); });
  return Object.keys(m).map(function (k) { return { name: k, count: m[k] }; });
}

/* ---------------- Cấu hình ---------------- */

function publicSettings() {
  var out = {};
  PUBLIC_SETTING_KEYS.forEach(function (k) { out[k] = setting(k); });
  return out;
}

/** Không cần đăng nhập: tên trường, logo nhỏ, môi trường – cho màn hình đăng nhập. */
function api_app_bootstrap() {
  var school = db_all('Schools')[0] || {};
  return { env: envName(), version: APP_VERSION, schoolName: setting('SCHOOL_NAME'), logo: school.logoFileId ? imageDataUri(school.logoFileId) : '' };
}

function api_settings_get(ctx) {
  requireAdminPerm(ctx, 'settings');
  var out = {};
  EDITABLE_SETTING_KEYS.forEach(function (k) { out[k] = setting(k); });
  var school = db_all('Schools')[0] || {};
  out.hasLogo = !!school.logoFileId;
  out.hasStamp = !!setting('STAMP_FILE_ID');
  out.env = envName();
  return out;
}

function api_settings_update(ctx, p) {
  requireAdminPerm(ctx, 'settings');
  return withLock(function () {
    var changed = {};
    EDITABLE_SETTING_KEYS.forEach(function (k) {
      if (p[k] === undefined) return;
      var v = String(p[k]).trim();
      if (k === 'SIGN_MODE') {
        if (['NONE', 'IMAGE', 'SMARTCA'].indexOf(v) < 0) fail('INVALID', 'Chế độ ký không hợp lệ.');
        if (!isPrimaryAdmin(ctx)) fail('FORBIDDEN', 'Chỉ quản trị viên chính đổi chế độ ký.');
      }
      if (['SESSION_IDLE_DAYS', 'LOGIN_MAX_FAIL', 'LOGIN_LOCK_MINUTES', 'EMAIL_RESERVE'].indexOf(k) >= 0 && !(parseInt(v, 10) > 0)) {
        fail('INVALID', 'Giá trị ' + k + ' phải là số dương.');
      }
      if (setting(k) !== v) { changed[k] = { from: setting(k), to: v }; setSetting(k, v, ctx.user.id); }
    });
    if (Object.keys(changed).length) audit(ctx.user.id, 'settings.update', 'AppSettings', '', null, changed);
    return api_settings_get(ctx);
  });
}

/** Logo trường hoặc ảnh con dấu (PNG nền trong suốt). */
function api_settings_uploadImage(ctx, p) {
  requireAdminPerm(ctx, 'settings');
  var bytes = Utilities.base64Decode(String(p.dataBase64 || ''));
  if (bytes.length > 2 * 1024 * 1024) fail('INVALID', 'Ảnh quá lớn (tối đa 2 MB).');
  var isPng = checkMagic('png', bytes), isJpg = checkMagic('jpg', bytes);
  if (!isPng && !isJpg) fail('INVALID', 'Chỉ nhận ảnh PNG hoặc JPG.');
  if (p.kind === 'stamp' && !isPng) fail('INVALID', 'Ảnh con dấu cần là PNG nền trong suốt.');
  return withLock(function () {
    var f = folderPath('NhanDien').createFile(Utilities.newBlob(bytes, isPng ? 'image/png' : 'image/jpeg', p.kind + '_' + Date.now() + (isPng ? '.png' : '.jpg')));
    if (p.kind === 'stamp') {
      setSetting('STAMP_FILE_ID', f.getId(), ctx.user.id);
    } else {
      var school = db_all('Schools')[0];
      if (school) db_update('Schools', school.id, { logoFileId: f.getId() }, ctx.user.id);
      else db_insert('Schools', { name: setting('SCHOOL_NAME'), logoFileId: f.getId() }, ctx.user.id);
    }
    audit(ctx.user.id, 'settings.upload_' + p.kind, 'AppSettings', f.getId());
    return true;
  });
}

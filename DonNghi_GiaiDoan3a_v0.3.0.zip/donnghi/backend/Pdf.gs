/**
 * Pdf.gs – mẫu đơn có phiên bản và tạo PDF A4 từ HTML.
 * Mẫu là HTML có trường thay thế {{...}}; mỗi lần sửa mẫu tạo phiên bản mới, đơn cũ giữ phiên bản lúc tạo.
 */

var DEFAULT_TEMPLATE_HTML = [
  '<html><head><meta charset="utf-8"><style>',
  '@page { size: A4; margin: 18mm 18mm 16mm 25mm; }',
  'body { font-family: "Times New Roman", Times, serif; font-size: 13pt; line-height: 1.45; color: #000; }',
  'table.hd { width: 100%; border-collapse: collapse; } table.hd td { vertical-align: top; text-align: center; padding: 0; }',
  '.b { font-weight: bold; } .u { text-decoration: underline; } .c { text-align: center; } .r { text-align: right; } .i { font-style: italic; }',
  'h1 { font-size: 15pt; text-align: center; margin: 14pt 0 6pt; }',
  '.row { margin: 3pt 0; } .lbl { display: inline; }',
  'table.sg { width: 100%; border-collapse: collapse; margin-top: 14pt; } table.sg td { width: 50%; vertical-align: top; text-align: center; padding: 0; }',
  '.sigbox { position: relative; height: 30mm; } .sigimg { height: 26mm; } .stamp { position: absolute; left: 6mm; top: -2mm; opacity: 0.9; }',
  '.foot { margin-top: 16pt; border-top: 1px solid #999; padding-top: 4pt; font-size: 9.5pt; color: #333; }',
  '</style></head><body>',
  '<table class="hd"><tr>',
  '<td style="width:42%">{{LOGO}}<div>{{SCHOOL_PARENT}}</div><div class="b">{{SCHOOL_NAME}}</div></td>',
  '<td><div class="b">CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM</div><div class="b u">Độc lập – Tự do – Hạnh phúc</div></td>',
  '</tr></table>',
  '<div class="r i" style="margin-top:8pt">{{PLACE_DATE}}</div>',
  '<h1>ĐƠN XIN NGHỈ</h1>',
  '<div class="c" style="margin-bottom:10pt">Kính gửi: Hiệu trưởng {{SCHOOL_NAME_TITLE}}</div>',
  '<div class="row">Tôi tên là: <b>{{FULL_NAME}}</b>{{STAFF_CODE}}</div>',
  '<div class="row">Chức vụ: {{POSITION}}</div>',
  '<div class="row">Tổ chuyên môn: {{DEPARTMENT}}</div>',
  '<div class="row">Điểm trường công tác: {{CAMPUSES}}</div>',
  '<div class="row">Loại nghỉ: {{LEAVE_TYPE}}</div>',
  '<div class="row">Thời gian nghỉ: {{PERIOD}} ({{DAYS}})</div>',
  '<div class="row">Điểm trường liên quan: {{SELECTED_CAMPUSES}}</div>',
  '<div class="row">Lý do: {{REASON}}</div>',
  '<div class="row">Số điện thoại liên hệ: {{PHONE}}</div>',
  '<div class="row">Kính mong Hiệu trưởng xem xét, giải quyết.</div>',
  '<table class="sg"><tr>',
  '<td><div class="b">{{APPROVER_TITLE}}</div><div class="i">{{APPROVER_NOTE}}</div><div class="sigbox">{{STAMP}}{{APPROVER_SIG}}</div><div class="b">{{APPROVER_NAME}}</div></td>',
  '<td><div class="b">NGƯỜI LÀM ĐƠN</div><div class="i">&nbsp;</div><div class="sigbox">{{SENDER_SIG}}</div><div class="b">{{FULL_NAME}}</div></td>',
  '</tr></table>',
  '<div class="foot">{{FOOTER}}</div>',
  '</body></html>'
].join('\n');

var DEFAULT_TEMPLATE_LAYOUT = { logoWidthMm: 20, signatureHeightMm: 26, stampWidthMm: 34 };

function activeTemplate() {
  var rows = db_filter('DocumentTemplates', function (t) { return t.status === 'ACTIVE'; });
  rows.sort(function (a, b) { return (parseInt(b.version, 10) || 0) - (parseInt(a.version, 10) || 0); });
  return rows[0] || null;
}

function imageDataUri(fileId) {
  if (!fileId) return '';
  try {
    var blob = DriveApp.getFileById(fileId).getBlob();
    return 'data:' + blob.getContentType() + ';base64,' + Utilities.base64Encode(blob.getBytes());
  } catch (e) {
    return '';
  }
}

function viLongDate(iso) {
  var d = iso ? new Date(iso) : new Date();
  var dd = Utilities.formatDate(d, 'Asia/Ho_Chi_Minh', 'dd');
  var mm = Utilities.formatDate(d, 'Asia/Ho_Chi_Minh', 'MM');
  var yy = Utilities.formatDate(d, 'Asia/Ho_Chi_Minh', 'yyyy');
  return 'ngày ' + dd + ' tháng ' + mm + ' năm ' + yy;
}

/**
 * Tạo PDF cho một phiên bản đơn.
 * sigs.sender / sigs.approver: {userId, fileId (ảnh chữ ký dùng khi ký), at, delegated}
 */
function renderLeavePdf(leave, ver, sigs) {
  var tplRow = (ver.templateVersionId && db_get('DocumentTemplates', ver.templateVersionId)) || activeTemplate();
  var html = tplRow ? tplRow.html : DEFAULT_TEMPLATE_HTML;
  var layout = tplRow ? parseJson(tplRow.layoutJson, DEFAULT_TEMPLATE_LAYOUT) : DEFAULT_TEMPLATE_LAYOUT;
  var content = parseJson(ver.contentJson, {});
  var snap = parseJson(leave.snapshotJson, {});
  var school = db_all('Schools')[0] || {};
  var type = db_get('LeaveTypes', content.leaveTypeId);
  var cmap = campusMap();
  var period = describePeriod(content);
  var sender = sigs.sender || null, approver = sigs.approver || null;
  var approverUser = approver ? db_get('Users', approver.userId) : null;

  var img = function (fileId, style, cls) {
    var uri = imageDataUri(fileId);
    return uri ? '<img class="' + (cls || '') + '" style="' + style + '" src="' + uri + '">' : '';
  };
  var signedAt = function (s) { return s && s.at ? viDateTime(s.at) : ''; };
  var footer = 'Mã đơn: <b>' + escapeHtml(leave.code) + '</b> · Phiên bản ' + escapeHtml(ver.version) +
    ' · Ngày tạo: ' + escapeHtml(viDate(String(leave.createdAt).slice(0, 10))) +
    ' · Mã đối chiếu nội dung: ' + escapeHtml(String(ver.contentHash || '').slice(0, 8)) + '<br>' +
    (sender ? 'Người làm đơn ký lúc ' + escapeHtml(signedAt(sender)) : 'Chưa ký') +
    (approver ? ' · Duyệt lúc ' + escapeHtml(signedAt(approver)) : '') + '<br>' +
    '<b>Xác nhận nội bộ bằng ảnh chữ ký – không phải chữ ký số.</b> Ảnh con dấu chỉ là hình ảnh hiển thị.' +
    (toBool(leave.isRetroactive) ? '<br>Đơn nộp sau ngày bắt đầu nghỉ.' : '');

  var values = {
    LOGO: img(school.logoFileId, 'width:' + (layout.logoWidthMm || 20) + 'mm', ''),
    SCHOOL_PARENT: escapeHtml(setting('SCHOOL_PARENT')).toUpperCase(),
    SCHOOL_NAME: escapeHtml(setting('SCHOOL_NAME')).toUpperCase(),
    SCHOOL_NAME_TITLE: escapeHtml(setting('SCHOOL_NAME')),
    PLACE_DATE: escapeHtml(setting('SCHOOL_PLACE')) + ', ' + viLongDate(ver.createdAt),
    FULL_NAME: escapeHtml(snap.fullName),
    STAFF_CODE: snap.staffCode ? ' &nbsp;–&nbsp; Mã nhân viên: ' + escapeHtml(snap.staffCode) : '',
    POSITION: escapeHtml(snap.positionTitle || ''),
    DEPARTMENT: escapeHtml(snap.departmentName || ''),
    CAMPUSES: escapeHtml((snap.assignedCampusNames || []).join(', ')),
    SELECTED_CAMPUSES: escapeHtml((content.campusIds || []).map(function (c) { return cmap[c] ? cmap[c].name : ''; }).join(', ')),
    LEAVE_TYPE: escapeHtml(type ? type.name : content.leaveTypeName) + (content.otherNote ? ' – ' + escapeHtml(content.otherNote) : ''),
    PERIOD: escapeHtml(period),
    DAYS: escapeHtml(formatDays(content.days)),
    REASON: escapeHtml(content.reason),
    PHONE: escapeHtml(content.contactPhone || ''),
    APPROVER_TITLE: approver && approver.delegated ? 'KT. HIỆU TRƯỞNG<br>PHÓ HIỆU TRƯỞNG' : 'HIỆU TRƯỞNG',
    APPROVER_NOTE: approver ? 'Đồng ý cho nghỉ' : '&nbsp;',
    APPROVER_SIG: approver ? img(approver.fileId, 'height:' + (layout.signatureHeightMm || 26) + 'mm', 'sigimg') : '',
    STAMP: approver && sigs.stamp ? img(setting('STAMP_FILE_ID'), 'width:' + (layout.stampWidthMm || 34) + 'mm', 'stamp') : '',
    APPROVER_NAME: approverUser ? escapeHtml(approverUser.fullName) : '',
    SENDER_SIG: sender ? img(sender.fileId, 'height:' + (layout.signatureHeightMm || 26) + 'mm', 'sigimg') : '',
    FOOTER: footer
  };
  var out = html.replace(/\{\{([A-Z_]+)\}\}/g, function (m, k) { return values[k] !== undefined ? values[k] : ''; });
  var name = (leave.code || 'don') + '_v' + ver.version + '.pdf';
  return Utilities.newBlob(out, 'text/html', 'don.html').getAs('application/pdf').setName(name);
}

/** Xem trước mẫu đơn với dữ liệu giả (quản trị viên). */
function api_templates_preview(ctx) {
  requireAdminPerm(ctx, 'settings');
  var fake = {
    id: 'preview', code: 'DXN-MAU-0001', createdAt: nowIso(), isRetroactive: 'FALSE',
    snapshotJson: JSON.stringify({ fullName: 'Nguyễn Văn A', staffCode: 'GV001', positionTitle: 'Giáo viên', departmentName: 'Tổ Khoa học tự nhiên', assignedCampusNames: ['Điểm chính'] })
  };
  var t = activeTemplate();
  var ver = {
    version: '1', createdAt: nowIso(), contentHash: 'abcdef123456', templateVersionId: t ? t.id : '',
    contentJson: JSON.stringify({ leaveTypeId: '', leaveTypeName: 'Nghỉ việc riêng', startDate: todayStr(), startSession: 'AM', endDate: todayStr(), endSession: 'PM', days: '1', reason: 'Việc gia đình', contactPhone: '0900000000', campusIds: [] })
  };
  var blob = renderLeavePdf(fake, ver, { sender: { userId: ctx.user.id, fileId: ctx.user.signatureFileId, at: nowIso() }, approver: { userId: ctx.user.id, fileId: ctx.user.signatureFileId, at: nowIso() }, stamp: true });
  return { fileName: 'mau_don.pdf', mimeType: 'application/pdf', done: true, dataBase64: Utilities.base64Encode(blob.getBytes()) };
}

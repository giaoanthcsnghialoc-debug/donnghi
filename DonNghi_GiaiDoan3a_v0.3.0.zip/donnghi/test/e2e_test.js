// Chạy thử toàn bộ luồng nghiệp vụ backend trên môi trường giả lập.
const vm = require('vm'), fs = require('fs'), path = require('path');
const { install } = require('./gas_mock');
const ctx = vm.createContext({});
install(ctx);
ctx.globalThis = ctx;
const dir = process.env.GAS_DIR || path.join(__dirname, '..', 'backend');
// Nạp theo thứ tự chữ cái như khi đẩy bằng clasp, từng file riêng (giống Apps Script).
fs.readdirSync(dir).filter(f => f.endsWith('.gs')).sort().forEach(f => vm.runInContext(fs.readFileSync(path.join(dir, f), 'utf8'), ctx, { filename: f }));

let pass = 0, failN = 0;
function ok(cond, msg) { if (cond) { pass++; } else { failN++; console.log('  ✗ ' + msg); } }
function call(token, action, payload, requestId) {
  return ctx.handleRequest({ action, token, payload: payload || {}, requestId });
}
function must(r, msg) { if (!r.ok) { console.log('  ✗ ' + msg + ': ' + JSON.stringify(r.error)); failN++; throw new Error('stop'); } pass++; return r.data; }
function login(u, p) { return must(call(null, 'auth.login', { username: u, password: p || 'Demo@2026', deviceLabel: 'test' }), 'login ' + u).token; }
const PNG = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(200, 1)]).toString('base64');
const PDF = Buffer.concat([Buffer.from('%PDF-1.4\n'), Buffer.alloc(500, 32)]).toString('base64');
function nextWeekday(offset) { const d = new Date(); d.setDate(d.getDate() + offset); while ([0, 6].includes(d.getDay())) d.setDate(d.getDate() + 1); return d.toISOString().slice(0, 10); }

console.log('1. Tính ngày nghỉ');
const c1 = ctx.calcLeave('2026-11-27', 'PM', '2026-11-30', 'AM'); // T6 chiều -> T2 sáng
ok(c1.sessions === 2 && c1.days === 1, 'chiều T6 đến sáng T2 = 1 ngày, nhận ' + c1.days);
ok(ctx.calcLeave('2026-11-23', 'AM', '2026-11-23', 'PM').days === 1, 'cả ngày = 1');
ok(ctx.calcLeave('2026-11-23', 'AM', '2026-11-23', 'AM').days === 0.5, 'một buổi = 0,5');
ok(ctx.calcLeave('2026-11-23', 'AM', '2026-11-29', 'PM').days === 5, 'một tuần = 5 ngày (bỏ T7, CN)');
let threw = false; try { ctx.calcLeave('2026-11-28', 'AM', '2026-11-29', 'PM'); } catch (e) { threw = true; } ok(threw, 'chỉ T7–CN phải báo lỗi');
threw = false; try { ctx.calcLeave('2026-11-23', 'PM', '2026-11-23', 'AM'); } catch (e) { threw = true; } ok(threw, 'cùng ngày chiều→sáng phải báo lỗi');
ok(ctx.describePeriod({ startDate: '2026-11-23', startSession: 'AM', endDate: '2026-11-23', endSession: 'PM' }) === 'Cả ngày 23/11/2026', 'mô tả thời gian');

console.log('2. Băm mật khẩu PBKDF2 (vector chuẩn RFC 7914)');
const saltHex = Buffer.from('salt').toString('hex');
ok(ctx.pbkdf2Hex('passwd', saltHex, 1) === '55ac046e56e3089fec1691c22544b605f94185216dde0465e68b9d57c20dacbc', 'PBKDF2 c=1');

console.log('3. Thiết lập DEMO');
ctx.setupDemo();
ctx.db_resetCache();
ok(ctx.db_all('Users').length === 13, 'có 13 tài khoản mẫu, nhận ' + ctx.db_all('Users').length);
ok(ctx.db_all('LeaveTypes').length === 6, '6 loại nghỉ');

console.log('4. Đăng nhập, khóa tạm khi sai 5 lần');
for (let i = 0; i < 5; i++) call(null, 'auth.login', { username: 'nv1', password: 'sai' });
const locked = call(null, 'auth.login', { username: 'nv1', password: 'Demo@2026' });
ok(!locked.ok && locked.error.code === 'LOCKED', 'sai 5 lần thì khóa: ' + JSON.stringify(locked.error));
const gv1 = login('gv1'), ht = login('hieutruong'), pht1 = login('pht1'), gv2 = login('gv2'), tt1 = login('tt1');
const boot = must(call(gv1, 'me.bootstrap'), 'bootstrap');
ok(boot.canSubmit && !boot.canDecide && boot.balance.granted === 12, 'GV tạo đơn được, không duyệt được, phép 12 ngày');
ok(!must(call(ht, 'me.bootstrap'), 'bootstrap ht').canSubmit, 'HT không tạo đơn');

console.log('5. Chưa có ảnh chữ ký thì không ký được');
const annual = boot.leaveTypes.find(t => t.code === 'ANNUAL').id, personal = boot.leaveTypes.find(t => t.code === 'PERSONAL').id;
const d1 = nextWeekday(7); const d2 = (() => { const d = new Date(d1 + 'T00:00:00Z'); do { d.setUTCDate(d.getUTCDate() + 1); } while ([0, 6].includes(d.getUTCDay())); return d.toISOString().slice(0, 10); })();
let L = must(call(gv1, 'leave.save', { leaveTypeId: annual, startDate: d1, startSession: 'AM', endDate: d1, endSession: 'PM', reason: 'Việc gia đình riêng tư', campusIds: boot.user.campusIds }), 'lưu nháp');
ok(L.status === 'DRAFT' && L.days === 1, 'bản nháp 1 ngày');
L = must(call(gv1, 'leave.submit', { id: L.id }), 'gửi');
ok(L.status === 'WAIT_SIGN' && /^DXN-\d{4}-0001$/.test(L.code), 'Chờ ký, mã ' + L.code);
let r = call(gv1, 'leave.sign', { id: L.id });
ok(!r.ok && r.error.code === 'NO_SIGNATURE', 'thiếu chữ ký: ' + JSON.stringify(r.error));
['gv1', 'gv2', 'hieutruong', 'pht1', 'tt1'].forEach(u => must(call({ gv1, gv2, hieutruong: ht, pht1, tt1 }[u], 'me.signature.upload', { pngBase64: PNG }), 'tải chữ ký ' + u));

console.log('6. Ký → Chờ duyệt → HT duyệt');
L = must(call(gv1, 'leave.sign', { id: L.id }), 'ký');
ok(L.status === 'PENDING', 'Chờ duyệt');
ok(must(call(ht, 'notify.list', {}), 'tb').some(n => n.title === 'Đơn mới chờ duyệt'), 'HT có thông báo đơn mới');
ok(must(call(ht, 'leave.pending'), 'pending').length === 1, 'HT thấy 1 đơn chờ');
r = call(pht1, 'leave.approve', { id: L.id });
ok(!r.ok && r.error.code === 'FORBIDDEN', 'PHT chưa ủy quyền không duyệt được');
r = call(pht1, 'leave.get', { id: L.id });
ok(!r.ok, 'PHT chưa xem được đơn đang chờ');
const det = must(call(ht, 'leave.get', { id: L.id }), 'ht xem');
ok(det.can.decide && det.balance && det.balance.remaining === 12, 'HT có nút duyệt, thấy phép còn 12');
L = must(call(ht, 'leave.approve', { id: L.id, rowVersion: det.rowVersion }), 'duyệt');
ok(L.status === 'APPROVED', 'Đã duyệt');
ok(globalThis.__lastHtml.includes('HIỆU TRƯỞNG') && globalThis.__lastHtml.includes('Bùi Thị Giáo Một') && globalThis.__lastHtml.includes('không phải chữ ký số'), 'PDF có tên, chức danh, dòng xác nhận nội bộ');
ok(!globalThis.__lastHtml.includes('Việc gia đình riêng tư') === false, 'PDF có lý do');
ok(must(call(gv1, 'me.bootstrap'), 'b').balance.remaining === 11, 'phép còn 11 sau khi duyệt');
r = call(ht, 'leave.approve', { id: L.id });
ok(!r.ok && r.error.code === 'BAD_STATE', 'duyệt lần 2 bị chặn');
ok(must(call(gv1, 'me.bootstrap'), 'b').balance.remaining === 11, 'không trừ phép hai lần');
ok(must(call(pht1, 'notify.list', {}), 'tb').some(n => n.title === 'Đơn nghỉ đã duyệt'), 'PHT nhận thông báo đơn đã duyệt');
ok(must(call(tt1, 'notify.list', {}), 'tb').some(n => n.title === 'Đơn nghỉ đã duyệt'), 'tổ trưởng nhận thông báo');
ok(must(call(pht1, 'leave.get', { id: L.id }), 'pht xem').status === 'APPROVED', 'PHT xem được đơn đã duyệt');
ok(!call(gv2, 'leave.get', { id: L.id }).ok, 'GV khác không xem được đơn');
const pdf = must(call(tt1, 'leave.pdf', { id: L.id, which: 'final' }), 'tải pdf');
ok(pdf.done && Buffer.from(pdf.dataBase64, 'base64').toString().startsWith('%PDF'), 'tổ trưởng tải được PDF');

console.log('7. Chặn đơn trùng thời gian');
let L2 = must(call(gv1, 'leave.save', { leaveTypeId: personal, startDate: d1, startSession: 'PM', endDate: d2, endSession: 'PM', reason: 'x', campusIds: boot.user.campusIds }), 'nháp 2');
r = call(gv1, 'leave.submit', { id: L2.id });
ok(!r.ok && r.error.code === 'OVERLAP', 'trùng buổi bị chặn: ' + (r.error && r.error.message));
must(call(gv1, 'leave.save', { id: L2.id, leaveTypeId: personal, startDate: d2, startSession: 'AM', endDate: d2, endSession: 'PM', reason: 'Đi khám', campusIds: boot.user.campusIds }), 'sửa nháp');
L2 = must(call(gv1, 'leave.submit', { id: L2.id }), 'gửi 2');
L2 = must(call(gv1, 'leave.sign', { id: L2.id }), 'ký 2');

console.log('8. Yêu cầu bổ sung → sửa → ký lại (phiên bản 2) → từ chối');
r = call(ht, 'leave.requestChanges', { id: L2.id, note: '' });
ok(!r.ok, 'yêu cầu bổ sung phải ghi nội dung');
L2 = must(call(ht, 'leave.requestChanges', { id: L2.id, note: 'Bổ sung giấy hẹn khám' }), 'yêu cầu bổ sung');
ok(L2.status === 'NEED_CHANGES', 'Yêu cầu bổ sung');
must(call(gv1, 'leave.save', { id: L2.id, leaveTypeId: personal, startDate: d2, startSession: 'AM', endDate: d2, endSession: 'PM', reason: 'Đi khám, có giấy hẹn', campusIds: boot.user.campusIds }), 'sửa');
L2 = must(call(gv1, 'leave.submit', { id: L2.id }), 'gửi lại');
L2 = must(call(gv1, 'leave.sign', { id: L2.id }), 'ký lại');
ok(L2.currentVersion === 2 && L2.versions.length === 2, 'có 2 phiên bản');
r = call(ht, 'leave.reject', { id: L2.id });
ok(!r.ok, 'từ chối phải có lý do');
L2 = must(call(ht, 'leave.reject', { id: L2.id, note: 'Trùng lịch thi' }), 'từ chối');
ok(L2.status === 'REJECTED', 'Từ chối');
ok(must(call(gv1, 'notify.list', {}), 'tb').some(n => n.body.includes('Trùng lịch thi')), 'GV nhận lý do từ chối');

console.log('9. Thu hồi');
let L3 = must(call(gv1, 'leave.save', { leaveTypeId: personal, startDate: nextWeekday(14), startSession: 'AM', endDate: nextWeekday(14), endSession: 'AM', reason: 'x', campusIds: boot.user.campusIds }), 'nháp 3');
L3 = must(call(gv1, 'leave.submit', { id: L3.id }), 'g'); L3 = must(call(gv1, 'leave.sign', { id: L3.id }), 'k');
L3 = must(call(gv1, 'leave.withdraw', { id: L3.id }), 'thu hồi');
ok(L3.status === 'WITHDRAWN', 'Đã thu hồi');
ok(!call(gv1, 'leave.withdraw', { id: L.id }).ok, 'không thu hồi đơn đã duyệt');

console.log('10. Hủy đơn đã duyệt (chỉ HT), hoàn phép');
ok(!call(pht1, 'leave.cancel', { id: L.id, note: 'x' }).ok, 'PHT không hủy được');
L = must(call(ht, 'leave.cancel', { id: L.id, note: 'Đổi lịch công tác' }), 'hủy');
ok(L.status === 'CANCELLED' && must(call(gv1, 'me.bootstrap'), 'b').balance.remaining === 12, 'Đã hủy, phép hoàn về 12');

console.log('11. Ủy quyền PHT');
const pht1Id = ctx.findUserByUsername('pht1').id;
const now = Date.now();
must(call(ht, 'delegation.create', { viceId: pht1Id, startAt: new Date(now - 60000).toISOString(), endAt: new Date(now + 86400000).toISOString() }), 'tạo ủy quyền');
ok(!call(ht, 'delegation.create', { viceId: pht1Id, startAt: new Date(now).toISOString(), endAt: new Date(now + 3600000).toISOString() }).ok, 'không chồng ủy quyền');
const b2 = must(call(gv2, 'me.bootstrap'), 'b2');
let L4 = must(call(gv2, 'leave.save', { leaveTypeId: personal, startDate: nextWeekday(9), startSession: 'AM', endDate: nextWeekday(9), endSession: 'PM', reason: 'Họp phụ huynh', campusIds: [b2.user.campusIds[0]] }), 'nháp gv2');
L4 = must(call(gv2, 'leave.submit', { id: L4.id }), 'g'); L4 = must(call(gv2, 'leave.sign', { id: L4.id }), 'k');
ok(must(call(pht1, 'me.bootstrap'), 'b').canDecide, 'PHT được ủy quyền có quyền duyệt');
L4 = must(call(pht1, 'leave.approve', { id: L4.id }), 'PHT duyệt');
ok(L4.status === 'APPROVED' && globalThis.__lastHtml.includes('KT. HIỆU TRƯỞNG'), 'PDF ghi KT. HIỆU TRƯỞNG');
ok(L4.history.some(h => h.delegated), 'lịch sử ghi duyệt theo ủy quyền');
// PHT không duyệt đơn của chính mình
let L5 = must(call(pht1, 'leave.save', { leaveTypeId: personal, startDate: nextWeekday(10), startSession: 'AM', endDate: nextWeekday(10), endSession: 'AM', reason: 'x', campusIds: must(call(pht1, 'me.bootstrap'), 'b').user.campusIds }), 'nháp pht');
L5 = must(call(pht1, 'leave.submit', { id: L5.id }), 'g'); L5 = must(call(pht1, 'leave.sign', { id: L5.id }), 'k');
ok(!call(pht1, 'leave.approve', { id: L5.id }).ok, 'PHT không tự duyệt đơn mình');
const dl = must(call(ht, 'delegation.list'), 'list');
must(call(ht, 'delegation.end', { id: dl[0].id }), 'kết thúc ủy quyền');
ok(!must(call(pht1, 'me.bootstrap'), 'b').canDecide, 'hết ủy quyền thì mất quyền duyệt');
must(call(ht, 'leave.approve', { id: L5.id }), 'HT duyệt đơn PHT');

console.log('12. Đơn tải lên (PDF), chèn chữ ký phía điện thoại');
const up = must(call(gv2, 'files.uploadChunk', { index: 0, total: 1, fileName: 'don.pdf', purpose: 'leave-source', dataBase64: PDF }), 'tải đơn');
ok(up.done && up.fileId, 'tải lên xong');
ok(!call(gv2, 'files.uploadChunk', { index: 0, total: 1, fileName: 'virus.exe', dataBase64: PDF }).ok, 'chặn tệp .exe');
ok(!call(gv2, 'files.uploadChunk', { index: 0, total: 1, fileName: 'gia.pdf', dataBase64: PNG }).ok, 'chặn tệp giả đuôi PDF');
let L6 = must(call(gv2, 'leave.save', { sourceType: 'UPLOAD', uploadedFileId: up.fileId, leaveTypeId: personal, startDate: nextWeekday(15), startSession: 'AM', endDate: nextWeekday(15), endSession: 'PM', reason: 'Theo đơn đính kèm', campusIds: [b2.user.campusIds[0]] }), 'nháp upload');
ok(!call(gv1, 'leave.save', { sourceType: 'UPLOAD', uploadedFileId: up.fileId, leaveTypeId: personal }).ok, 'không dùng tệp của người khác');
L6 = must(call(gv2, 'leave.submit', { id: L6.id }), 'gửi upload');
const src = must(call(gv2, 'leave.pdf', { id: L6.id, which: 'source' }), 'tải nguồn');
ok(src.done, 'người gửi tải được đơn gốc để chèn chữ ký');
const signed = must(call(gv2, 'files.uploadChunk', { index: 0, total: 1, fileName: 'signed.pdf', purpose: 'signed-pdf', dataBase64: PDF }), 'tải đơn đã ký');
L6 = must(call(gv2, 'leave.sign', { id: L6.id, signedFileId: signed.fileId, placement: { page: 1, x: 0.6, y: 0.7, w: 0.25 } }), 'ký upload');
ok(L6.status === 'PENDING', 'đơn upload chờ duyệt');
const signed2 = must(call(ht, 'files.uploadChunk', { index: 0, total: 1, fileName: 'final.pdf', purpose: 'signed-pdf', dataBase64: PDF }), 'ht tải bản ký');
ok(!call(ht, 'leave.approve', { id: L6.id, signedFileId: signed.fileId }).ok, 'HT không dùng tệp của GV làm bản duyệt');
L6 = must(call(ht, 'leave.approve', { id: L6.id, signedFileId: signed2.fileId }), 'duyệt upload');
ok(L6.status === 'APPROVED' && L6.hasFinalPdf, 'đơn upload đã duyệt có PDF');

console.log('13. Chống gửi lặp, nhật ký');
let L7 = must(call(gv1, 'leave.save', { leaveTypeId: personal, startDate: nextWeekday(20), startSession: 'AM', endDate: nextWeekday(20), endSession: 'AM', reason: 'x', campusIds: boot.user.campusIds }, 'req-1'), 'nháp');
const again = call(gv1, 'leave.save', { leaveTypeId: personal, startDate: nextWeekday(20), startSession: 'AM', endDate: nextWeekday(20), endSession: 'AM', reason: 'x', campusIds: boot.user.campusIds }, 'req-1');
ok(again.duplicate && again.data.id === L7.id, 'gửi lặp cùng requestId không tạo đơn mới');
must(call(gv1, 'leave.deleteDraft', { id: L7.id }), 'xóa nháp');
const qtv = login('quantri');
let v = must(call(qtv, 'audit.verify'), 'kiểm tra nhật ký');
ok(v.problems.length === 0 && v.total > 20, 'chuỗi nhật ký nguyên vẹn (' + v.total + ' dòng)');
const sh = ctx.db_sheet('AuditLogs');
sh.data[5][5] = 'sua_tay';
v = must(call(qtv, 'audit.verify'), 'kiểm tra lại');
ok(v.problems.length > 0, 'phát hiện dòng nhật ký bị sửa tay');

console.log('14. Quản trị: tạo tài khoản, đổi mật khẩu lần đầu, nhập CSV');
const cr = must(call(qtv, 'users.create', { fullName: 'Giáo Viên Mới', username: 'gvmoi', roles: ['TEACHER'], campusIds: boot.campuses.map(c => c.id).slice(0, 1) }), 'tạo tk');
const gvm = login('gvmoi', cr.tempPassword);
ok(call(gvm, 'leave.listMine').error.code === 'MUST_CHANGE_PASSWORD', 'bắt đổi mật khẩu lần đầu');
must(call(gvm, 'auth.changePassword', { oldPassword: cr.tempPassword, newPassword: 'MatKhau2026' }), 'đổi mk');
ok(call(gvm, 'leave.listMine').ok, 'đổi mật khẩu xong dùng được, phiên hiện tại vẫn giữ');
ok(!call(gv1, 'users.list').ok, 'GV không vào được quản lý tài khoản');
const csv = Buffer.from('Mã NV,Họ và tên,Tên đăng nhập,Email,SĐT,Zalo,Chức vụ,Tổ,Điểm trường,Vai trò\nGV10,Nguyễn Mười,gv10,,,,Giáo viên,Tổ Khoa học tự nhiên,Phân hiệu 1,Giáo viên\nGV11,Trùng Tên,gv1,,,,Giáo viên,,Điểm chính,GV\n').toString('base64');
const imp = must(call(qtv, 'users.import', { fileBase64: csv, fileName: 'ds.csv', dryRun: true }), 'nhập thử');
ok(imp.length === 2 && imp[0].ok && !imp[1].ok, 'dòng 1 hợp lệ, dòng 2 trùng tên đăng nhập: ' + JSON.stringify(imp));

console.log('15. Trang chủ');
const dh = must(call(ht, 'dash.home'), 'dash ht');
ok(dh.decider && dh.manager, 'HT có số liệu duyệt và quản lý');
const dg = must(call(gv1, 'dash.home'), 'dash gv');
ok(!dg.manager && dg.mine.total >= 3, 'GV chỉ thấy số liệu cá nhân');

console.log('\nKết quả: ' + pass + ' đạt, ' + failN + ' lỗi');
process.exit(failN ? 1 : 0);

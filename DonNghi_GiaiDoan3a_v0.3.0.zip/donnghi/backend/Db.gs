/**
 * Db.gs – đọc ghi Google Sheets như một cơ sở dữ liệu nhỏ.
 * Mọi Sheet định dạng văn bản thuần (@) để Sheets không tự đổi ngày, số.
 */

var COMMON_COLS = ['id', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy', 'rowVersion'];

var SCHEMA = {
  Schools: ['name', 'address', 'phone', 'email', 'logoFileId'],
  Campuses: ['name', 'shortName', 'address', 'order', 'status'],
  Departments: ['name', 'leaderUserId', 'status'],
  Users: ['staffCode', 'fullName', 'username', 'passwordHash', 'passwordSalt', 'passwordIter', 'mustChangePassword',
    'email', 'phone', 'zaloPhone', 'zaloOptIn', 'positionTitle', 'departmentId', 'status', 'failedLogins',
    'lockedUntil', 'themePref', 'signatureFileId', 'emailOnApproved'],
  Roles: ['code', 'name'],
  Permissions: ['code', 'description'],
  UserRoles: ['userId', 'roleCode', 'extraPermissions', 'isPrimaryAdmin'],
  UserCampusAssignments: ['userId', 'campusId', 'startDate', 'endDate', 'changedBy'],
  UserDepartmentHistory: ['userId', 'departmentId', 'startDate', 'endDate', 'changedBy'],
  UserPositionHistory: ['userId', 'positionTitle', 'startDate', 'endDate', 'changedBy'],
  LeaveTypes: ['name', 'code', 'deductsAnnual', 'requiresNote', 'order', 'status'],
  LeaveRequests: ['code', 'academicYearId', 'userId', 'sourceType', 'uploadedFileId', 'leaveTypeId', 'otherNote',
    'startDate', 'startSession', 'endDate', 'endSession', 'sessions', 'days', 'reason', 'contactPhone',
    'isRetroactive', 'submittedAt', 'decidedAt', 'status', 'currentVersion', 'signMode', 'finalPdfFileId',
    'snapshotJson', 'attachmentIds', 'campusIds', 'remindedMarks'],
  LeaveRequestCampuses: ['leaveRequestId', 'campusId'],
  LeaveRequestVersions: ['leaveRequestId', 'version', 'contentJson', 'contentHash', 'templateVersionId', 'pdfFileId',
    'pdfHash', 'reason'],
  LeaveStatusHistory: ['leaveRequestId', 'fromStatus', 'toStatus', 'actorId', 'delegationId', 'note', 'at'],
  LeaveRequestAttachments: ['leaveRequestId', 'version', 'fileId', 'fileName', 'mimeType', 'size', 'sha256'],
  LeaveRequestApprovals: ['leaveRequestId', 'version', 'decision', 'deciderId', 'delegationId', 'note', 'at'],
  LeaveRequestSignatures: ['leaveRequestId', 'version', 'signerId', 'role', 'mode', 'placementJson', 'transactionId',
    'status', 'signedPdfFileId', 'contentHash', 'at'],
  Delegations: ['principalId', 'viceId', 'startAt', 'endAt', 'scope', 'status', 'endedBy', 'endedAt'],
  DocumentTemplates: ['name', 'version', 'html', 'layoutJson', 'status'],
  AcademicYears: ['name', 'startDate', 'endDate', 'autoRolloverAt', 'status'],
  LeaveBalances: ['userId', 'academicYearId', 'granted', 'used', 'remaining'],
  LeaveBalanceTransactions: ['balanceId', 'userId', 'academicYearId', 'type', 'days', 'leaveRequestId', 'version',
    'note', 'actorId'],
  Notifications: ['type', 'title', 'body', 'link', 'senderId', 'scope', 'isUrgent'],
  NotificationRecipients: ['notificationId', 'userId', 'readAt', 'emailStatus', 'zaloStatus', 'pushStatus'],
  Announcements: ['title', 'body', 'scopeType', 'scopeIds', 'isUrgent', 'scheduleRule', 'nextRunAt', 'remindUnread',
    'status'],
  SupportTickets: ['userId', 'category', 'title', 'body', 'attachmentFileId', 'status', 'adminNote'],
  AuditLogs: ['at', 'actorId', 'action', 'entity', 'entityId', 'beforeJson', 'afterJson', 'prevHash', 'hash'],
  AppSettings: ['key', 'value'],
  Counters: ['name', 'value'],
  RequestKeys: ['requestId', 'action', 'resultJson', 'at'],
  Sessions: ['userId', 'tokenHash', 'deviceLabel', 'userAgent', 'lastSeenAt', 'expiresAt', 'revokedAt'],
  LoginAttempts: ['username', 'success', 'at', 'userAgent'],
  PasswordResets: ['userId', 'tokenHash', 'expiresAt', 'usedAt'],
  Backups: ['type', 'fileId', 'size', 'status', 'error'],
  BackupDownloads: ['userId', 'packageType', 'academicYearId', 'at'],
  AppVersions: ['version', 'changes', 'deployedAt', 'deployedBy', 'schemaVersion']
};

/** Các Sheet chỉ ghi thêm, không cần các cột chung. */
var APPEND_ONLY = { AuditLogs: true, LoginAttempts: true };

var _ss = null;
var _cache = {};

function db_ss() {
  if (!_ss) _ss = SpreadsheetApp.openById(cfg('SPREADSHEET_ID'));
  return _ss;
}

function db_cols(name) {
  var extra = SCHEMA[name];
  if (!extra) fail('SCHEMA', 'Không có bảng ' + name);
  return APPEND_ONLY[name] ? ['id'].concat(extra) : COMMON_COLS.concat(extra);
}

function db_sheet(name) {
  var sh = db_ss().getSheetByName(name);
  if (!sh) fail('SCHEMA', 'Thiếu Sheet ' + name + '. Hãy chạy lại hàm thiết lập.');
  return sh;
}

/** Đọc toàn bộ bảng thành mảng đối tượng (có _row = số dòng thật trong Sheet). */
function db_all(name) {
  if (_cache[name]) return _cache[name];
  var sh = db_sheet(name);
  var last = sh.getLastRow();
  var cols = db_cols(name);
  var rows = [];
  if (last >= 2) {
    var values = sh.getRange(2, 1, last - 1, cols.length).getValues();
    for (var i = 0; i < values.length; i++) {
      var v = values[i];
      if (v[0] === '' || v[0] === null) continue;
      var o = { _row: i + 2 };
      for (var c = 0; c < cols.length; c++) o[cols[c]] = v[c] === null ? '' : String(v[c]);
      rows.push(o);
    }
  }
  _cache[name] = rows;
  return rows;
}

function db_find(name, pred) {
  var all = db_all(name);
  for (var i = 0; i < all.length; i++) if (pred(all[i])) return all[i];
  return null;
}

function db_filter(name, pred) {
  return db_all(name).filter(pred);
}

function db_get(name, id) {
  if (!id) return null;
  return db_find(name, function (r) { return r.id === id; });
}

function db_rowValues(name, obj) {
  return db_cols(name).map(function (c) {
    var v = obj[c];
    if (v === undefined || v === null) return '';
    if (typeof v === 'object') return JSON.stringify(v);
    return String(v);
  });
}

function db_insert(name, obj, actorId) {
  var o = {};
  for (var k in obj) o[k] = obj[k];
  var prefix = name.slice(0, 3).toLowerCase();
  if (!o.id) o.id = newId(prefix);
  if (!APPEND_ONLY[name]) {
    o.createdAt = o.createdAt || nowIso();
    o.createdBy = o.createdBy || actorId || '';
    o.updatedAt = o.createdAt;
    o.updatedBy = o.createdBy;
    o.rowVersion = '1';
  }
  var sh = db_sheet(name);
  sh.appendRow(db_rowValues(name, o));
  var cols = db_cols(name);
  var stored = { _row: sh.getLastRow() };
  cols.forEach(function (c) { stored[c] = o[c] === undefined || o[c] === null ? '' : (typeof o[c] === 'object' ? JSON.stringify(o[c]) : String(o[c])); });
  if (_cache[name]) _cache[name].push(stored);
  return stored;
}

/**
 * Cập nhật một dòng. Nếu truyền expectedVersion mà dòng đã bị người khác sửa
 * thì từ chối để tránh ghi đè.
 */
function db_update(name, id, patch, actorId, expectedVersion) {
  var row = db_get(name, id);
  if (!row) fail('NOT_FOUND', 'Không tìm thấy dữ liệu.');
  if (expectedVersion !== undefined && expectedVersion !== null && expectedVersion !== '' &&
      String(expectedVersion) !== String(row.rowVersion)) {
    fail('CONFLICT', 'Dữ liệu vừa được người khác cập nhật. Vui lòng tải lại.');
  }
  for (var k in patch) {
    var v = patch[k];
    row[k] = v === undefined || v === null ? '' : (typeof v === 'object' ? JSON.stringify(v) : String(v));
  }
  row.updatedAt = nowIso();
  row.updatedBy = actorId || row.updatedBy;
  row.rowVersion = String((parseInt(row.rowVersion, 10) || 0) + 1);
  var sh = db_sheet(name);
  sh.getRange(row._row, 1, 1, db_cols(name).length).setValues([db_rowValues(name, row)]);
  return row;
}

/** Chỉ dùng cho bản nháp chưa gửi và dữ liệu tạm. */
function db_delete(name, id) {
  var row = db_get(name, id);
  if (!row) return;
  db_sheet(name).deleteRow(row._row);
  delete _cache[name];
}

function db_resetCache() {
  _cache = {};
}

/** Chạy hàm trong khóa ghi chung để nhiều người thao tác cùng lúc không đè nhau. */
function withLock(fn) {
  var lock = LockService.getScriptLock();
  if (!lock.tryLock(20000)) fail('BUSY', 'Hệ thống đang bận, vui lòng thử lại sau vài giây.');
  try {
    db_resetCache();
    return fn();
  } finally {
    SpreadsheetApp.flush();
    lock.releaseLock();
  }
}

/** Bộ đếm tăng dần, phải gọi bên trong withLock. */
function nextCounter(name) {
  var row = db_find('Counters', function (r) { return r.name === name; });
  if (!row) {
    db_insert('Counters', { name: name, value: '1' });
    return 1;
  }
  var v = (parseInt(row.value, 10) || 0) + 1;
  db_update('Counters', row.id, { value: String(v) });
  return v;
}

// Mô phỏng môi trường Apps Script: không có setTimeout, window, Buffer, require
const vm = require('vm'), fs = require('fs');
const src = fs.readFileSync(process.argv[2], 'utf8');
const ctx = vm.createContext({ console });
vm.runInContext(src, ctx);
vm.runInContext(`
var setTimeout = function(fn){ fn(); return 0; }; // polyfill sẽ đặt trong Apps Script
async function run(){
  const doc = await PDFLib.PDFDocument.create();
  const page = doc.addPage([595.28, 841.89]);
  // ảnh PNG 1x1 trong suốt
  const png = Uint8Array.from(atobPoly('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=='), c=>c.charCodeAt(0));
  const img = await doc.embedPng(png);
  page.drawImage(img, {x: 100, y: 100, width: 120, height: 50});
  const bytes = await doc.save();
  const doc2 = await PDFLib.PDFDocument.load(bytes);
  return 'ok pages=' + doc2.getPageCount() + ' bytes=' + bytes.length;
}
function atobPoly(b64){ var chars='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'; var out='',buf=0,bits=0; for (var i=0;i<b64.length;i++){var c=b64[i]; if(c==='=')break; buf=(buf<<6)|chars.indexOf(c); bits+=6; if(bits>=8){bits-=8; out+=String.fromCharCode((buf>>bits)&255);} } return out; }
run().then(r=>console.log(r)).catch(e=>console.log('ERR', e && e.stack));
`, ctx);

/**
 * Permissions.gs – vai trò, ủy quyền và các hàm kiểm tra quyền.
 * Mọi quyền được kiểm tra trên máy chủ; dữ liệu quyền từ trình duyệt bị bỏ qua.
 */

var ROLE = { PRINCIPAL: 'PRINCIPAL', VICE: 'VICE', LEADER: 'LEADER', TEACHER: 'TEACHER', STAFF: 'STAFF', ADMIN: 'ADMIN' };
var ROLE_NAMES = {
  PRINCIPAL: 'Hiệu trưởng', VICE: 'Phó Hiệu trưởng', LEADER: 'Tổ trưởng chuyên môn',
  TEACHER: 'Giáo viên', STAFF: 'Nhân viên', ADMIN: 'Quản trị viên'
};
/** Quyền chi tiết có thể cấp cho quản trị viên phụ. */
var ADMIN_PERMS = {
  users: 'Quản lý tài khoản',
  org: 'Quản lý tổ chuyên môn và điểm trường',
  balance: 'Quản lý quỹ phép',
  settings: 'Quản lý cấu hình, mẫu đơn, logo, con dấu',
  years: 'Quản lý năm học'
};

function userRoles(userId) {
  var rows = db_filter('UserRoles', function (r) { return r.userId === userId; });
  var codes = {};
  var perms = {};
  var primary = false;
  rows.forEach(function (r) {
    codes[r.roleCode] = true;
    if (r.roleCode === ROLE.ADMIN) {
      if (toBool(r.isPrimaryAdmin)) primary = true;
      splitList(r.extraPermissions).forEach(function (p) { perms[p] = true; });
    }
  });
  return { codes: codes, adminPerms: perms, isPrimaryAdmin: primary };
}

function has(ctx, role) { return !!ctx.roles.codes[role]; }
function isPrincipal(ctx) { return has(ctx, ROLE.PRINCIPAL); }
function isVice(ctx) { return has(ctx, ROLE.VICE); }
function isLeader(ctx) { return has(ctx, ROLE.LEADER); }
function isManager(ctx) { return isPrincipal(ctx) || isVice(ctx) || isLeader(ctx); }
function isAdmin(ctx) { return has(ctx, ROLE.ADMIN); }
function isPrimaryAdmin(ctx) { return isAdmin(ctx) && ctx.roles.isPrimaryAdmin; }
function canSubmitLeave(ctx) { return !isPrincipal(ctx) && (has(ctx, ROLE.TEACHER) || has(ctx, ROLE.STAFF) || isVice(ctx) || isLeader(ctx)); }

function adminCan(ctx, perm) {
  return isPrimaryAdmin(ctx) || (isAdmin(ctx) && !!ctx.roles.adminPerms[perm]);
}

function requireAdminPerm(ctx, perm) {
  if (!adminCan(ctx, perm)) fail('FORBIDDEN', 'Bạn không có quyền thực hiện thao tác này.');
}

function requirePrimaryAdmin(ctx) {
  if (!isPrimaryAdmin(ctx)) fail('FORBIDDEN', 'Chỉ quản trị viên chính được thực hiện thao tác này.');
}

function requirePrincipal(ctx) {
  if (!isPrincipal(ctx)) fail('FORBIDDEN', 'Chỉ Hiệu trưởng được thực hiện thao tác này.');
}

/** Ủy quyền đang hiệu lực tại thời điểm hiện tại (chỉ một). */
function activeDelegation() {
  var now = Date.now();
  return db_find('Delegations', function (d) {
    return d.status === 'ACTIVE' && new Date(d.startAt).getTime() <= now && now < new Date(d.endAt).getTime();
  });
}

/** Người này có đang được ủy quyền duyệt đơn không. Trả về bản ghi ủy quyền hoặc null. */
function delegationFor(ctx) {
  if (!isVice(ctx)) return null;
  var d = activeDelegation();
  return d && d.viceId === ctx.user.id ? d : null;
}

/** Có quyền duyệt/từ chối/yêu cầu bổ sung đơn này không. Trả về {ok, delegation}. */
function decisionRight(ctx, leave) {
  if (isPrincipal(ctx)) return { ok: true, delegation: null };
  var d = delegationFor(ctx);
  if (d && leave.userId !== ctx.user.id) return { ok: true, delegation: d };
  return { ok: false, delegation: null };
}

function canDecide(ctx) {
  return isPrincipal(ctx) || !!delegationFor(ctx);
}

var DECIDER_VISIBLE = ['WAIT_SIGN', 'PENDING', 'NEED_CHANGES', 'APPROVED', 'REJECTED', 'WITHDRAWN', 'CANCELLED'];

/** Xem được đơn này không. */
function canViewLeave(ctx, leave) {
  if (leave.userId === ctx.user.id) return true;
  if (isPrincipal(ctx)) return DECIDER_VISIBLE.indexOf(leave.status) >= 0;
  if (delegationFor(ctx) && ['PENDING', 'NEED_CHANGES'].indexOf(leave.status) >= 0) return true;
  if ((isVice(ctx) || isLeader(ctx)) && leave.status === 'APPROVED') return true;
  return false;
}

/** Tệp đính kèm: theo quyết định ngày 21/11/2026, ai xem được đơn thì xem được đính kèm. */
function canViewAttachments(ctx, leave) {
  return canViewLeave(ctx, leave);
}

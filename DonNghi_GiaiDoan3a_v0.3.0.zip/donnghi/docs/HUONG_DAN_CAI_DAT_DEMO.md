# Hướng dẫn cài bản DEMO – Hệ thống quản lý và duyệt đơn xin nghỉ

Phiên bản 0.3.0 (Giai đoạn 3a – hệ thống lõi). Thời gian cài: khoảng 30–40 phút.

Bản DEMO dùng **dữ liệu mẫu**, tách hoàn toàn khỏi bản chính thức. Mọi màn hình có dải đỏ "MÔI TRƯỜNG THỬ NGHIỆM". Khi chuyển sang dùng thật, thầy làm lại các bước với hàm `setupProd()` trên một dự án Apps Script khác.

Thầy cần chuẩn bị:

- Máy tính có trình duyệt Chrome.
- Đăng nhập **Gmail chính của trường**.
- Một tài khoản **GitHub** miễn phí. Nếu chưa có, tạo tại github.com, mục Sign up.
- Tệp nén mã nguồn em gửi, đã giải nén. Trong đó có thư mục `dist/` gồm:
  - `1_AppsScript/` – mã máy chủ: `Code.gs`, `appsscript.json`
  - `2_GitHubPages/demo/` – giao diện

---

## Phần A. Cài máy chủ (Google Apps Script)

**A1. Tạo dự án.** Mở https://script.google.com bằng Gmail của trường → **Dự án mới**. Bấm vào chữ "Dự án không có tiêu đề" ở góc trên, đặt tên `DonNghi_DEMO`.

**A2. Hiện tệp cấu hình.** Bấm biểu tượng bánh răng **Cài đặt dự án** ở cột trái → tích ô **"Hiển thị tệp kê khai appsscript.json trong trình chỉnh sửa"**.

**A3. Dán cấu hình.** Quay lại mục **Trình chỉnh sửa** (biểu tượng `< >`) → mở tệp `appsscript.json` → xóa hết nội dung → mở tệp `dist/1_AppsScript/appsscript.json` bằng Notepad, sao chép toàn bộ rồi dán vào → bấm **Lưu** (biểu tượng đĩa mềm, hoặc Ctrl+S).

**A4. Dán mã.** Mở tệp `Code.gs` trong dự án → xóa đoạn `function myFunction() {}` có sẵn → mở `dist/1_AppsScript/Code.gs` bằng Notepad, chọn tất cả (Ctrl+A), sao chép, dán vào → **Lưu**.

**A5. Bật Drive API.** Ở cột trái, bấm dấu **+** cạnh mục **Dịch vụ** → chọn **Drive API**, phiên bản **v3** → **Thêm**. Nếu Drive API đã có sẵn trong danh sách thì bỏ qua bước này.

**A6. Chạy thiết lập.**
1. Trên thanh công cụ, ở ô chọn hàm (cạnh nút Gỡ lỗi), chọn **`setupDemo`** → bấm **Chạy**.
2. Google hỏi cấp quyền. Bấm **Xem lại quyền** → chọn Gmail của trường.
3. Google báo "Google chưa xác minh ứng dụng này". Đây là bình thường với mã do chính mình viết. Bấm **Nâng cao** → **Đi tới DonNghi_DEMO (không an toàn)** → **Cho phép**.
4. Đợi khoảng 1–2 phút. Phần **Nhật ký thực thi** ở dưới hiện:
   - đường dẫn thư mục dữ liệu `HeThongDonNghi_DEMO` trên Drive,
   - đường dẫn file Sheets dữ liệu,
   - danh sách tài khoản mẫu.

> Không chia sẻ thư mục và file Sheets này cho ai. Người dùng chỉ truy cập qua ứng dụng.

**A7. Triển khai thành ứng dụng web.**
1. Bấm **Triển khai** (góc trên phải) → **Triển khai mới**.
2. Bấm biểu tượng bánh răng cạnh "Chọn loại" → **Ứng dụng web**.
3. Điền:
   - Mô tả: `DEMO 0.3.0`
   - Thực thi với tư cách: **Tôi**
   - Người có quyền truy cập: **Bất kỳ ai**
4. Bấm **Triển khai** → sao chép **URL ứng dụng web**. URL có dạng `https://script.google.com/macros/s/……/exec`.

Kiểm tra nhanh: dán URL vào trình duyệt. Nếu thấy dòng chữ có `"ok":true` và `"env":"DEMO"` là máy chủ đã chạy.

---

## Phần B. Cài giao diện (GitHub Pages – miễn phí)

**B1. Điền địa chỉ máy chủ.** Mở tệp `dist/2_GitHubPages/demo/js/config.js` bằng Notepad. Dán URL ở bước A7 vào giữa hai dấu nháy của dòng `DEMO`:

```js
  DEMO: 'https://script.google.com/macros/s/……/exec'
```

Lưu tệp.

**B2. Tạo kho mã.** Trên github.com bấm **New repository**. Điền:
- Repository name: `donnghi`
- Chọn **Public** (gói miễn phí chỉ cho bật trang web với kho công khai; kho chỉ chứa giao diện, không có dữ liệu hay mật khẩu)

Bấm **Create repository**.

**B3. Tải giao diện lên.** Trong kho vừa tạo, bấm **uploading an existing file**. Kéo **cả thư mục `demo`** (nằm trong `dist/2_GitHubPages/`) thả vào trang → đợi tải xong → bấm **Commit changes**.

**B4. Bật trang web.** Vào **Settings** → **Pages** → mục *Build and deployment*:
- Source: **Deploy from a branch**
- Branch: **main**, thư mục **/(root)**

Bấm **Save**. Đợi 1–3 phút, trang báo địa chỉ dạng `https://<tên-tài-khoản>.github.io/donnghi/`.

Địa chỉ bản DEMO là địa chỉ trên thêm `demo/`: **`https://<tên-tài-khoản>.github.io/donnghi/demo/`**

---

## Phần C. Cấu hình lần đầu trong ứng dụng

1. Mở địa chỉ DEMO → đăng nhập **`quantri`** / **`Demo@2026`**.
2. Vào **Quản trị → Cấu hình**:
   - **Địa chỉ giao diện**: dán địa chỉ DEMO ở bước B4. Liên kết trong email khôi phục mật khẩu dùng địa chỉ này.
   - **Email nhận thử (DEMO)**: điền email của thầy. Bản DEMO chỉ gửi email tới các địa chỉ trong ô này, tránh gửi nhầm cho người thật.
   - Bấm **Lưu cấu hình**.
3. Tùy chọn: tải **logo trường** và **ảnh con dấu** lên, rồi bấm **Xem thử mẫu đơn**.

---

## Phần D. Cài lên điện thoại

- **Android (Chrome):** mở địa chỉ DEMO → bấm menu ⋮ → **Thêm vào màn hình chính** hoặc **Cài đặt ứng dụng**.
- **iPhone (Safari):** mở địa chỉ DEMO → bấm nút **Chia sẻ** (ô vuông có mũi tên lên) → **Thêm vào MH chính**.

Sau đó ứng dụng có biểu tượng riêng và mở toàn màn hình như app thường.

---

## Phần E. Tài khoản mẫu và kịch bản dùng thử

Mật khẩu chung của mọi tài khoản mẫu: **`Demo@2026`**

| Tên đăng nhập | Vai trò | Điểm trường |
|---|---|---|
| hieutruong | Hiệu trưởng | Cả 3 |
| pht1, pht2, pht3 | Phó Hiệu trưởng | Điểm chính / PH1 / PH2 |
| tt1, tt2, tt3 | Tổ trưởng | Điểm chính / PH1 / Điểm chính |
| gv1 … gv4 | Giáo viên | Khác nhau (gv2, gv4 dạy 2 điểm) |
| nv1 | Nhân viên | Điểm chính |
| quantri | Quản trị viên chính | – |

Mỗi tài khoản giáo viên, nhân viên có sẵn 12 ngày phép năm. Thầy nên thử lần lượt trên điện thoại:

1. **Ảnh chữ ký:** đăng nhập `gv1` → Cá nhân → Ảnh chữ ký. Thử cả hai cách:
   - **Chụp chữ ký:** ký trên giấy trắng, chụp lại; ứng dụng tự xóa nền.
   - **Vẽ chữ ký:** vẽ bằng ngón tay.
2. **Tạo đơn theo mẫu:** Tạo đơn → chọn loại nghỉ, thời gian, điểm trường, lý do → **Ký và gửi**.
3. **Duyệt:** đăng nhập `hieutruong`, tạo ảnh chữ ký → mở đơn → **Duyệt và ký** → mở **Xem đơn đã duyệt** để xem PDF.
4. **Yêu cầu bổ sung, từ chối, thu hồi, hủy đơn đã duyệt:** thử với vài đơn khác.
5. **Đơn tải lên:** đăng nhập `gv2` → Tạo đơn → **Tải đơn của tôi lên** → **Chụp đơn** viết tay hoặc chọn tệp PDF/Word → điền nhanh → **Ký và gửi** → chạm vào chỗ cần ký trên trang → **Chèn vào đơn**.
6. **Ủy quyền:** `hieutruong` → Trang chủ → Ủy quyền duyệt đơn → chọn `pht1`. Đăng nhập `pht1` sẽ thấy mục **Duyệt đơn**; PDF ghi "KT. HIỆU TRƯỞNG – PHÓ HIỆU TRƯỞNG".
7. **Chặn trùng:** `gv1` thử gửi đơn thứ hai trùng buổi với đơn đã có → hệ thống báo và không cho gửi.
8. **Quản trị:** `quantri` → tạo tài khoản, nhập danh sách từ Excel (mẫu cột có ghi trong màn hình Nhập từ Excel), khóa/mở khóa, đặt lại mật khẩu, nhập quỹ phép.

---

## Phần F. Những điểm cần kiểm tra trên bản thật

Em đã chạy thử toàn bộ nghiệp vụ trên môi trường giả lập Google (142 bài kiểm tra đạt) và chạy giao diện trên trình duyệt điện thoại giả lập. Tuy vậy, mấy điểm sau chỉ kiểm chứng được trên Google thật. Thầy thử và báo lại giúp em:

| # | Cần kiểm tra | Nếu có vấn đề |
|---|---|---|
| 1 | Bố cục PDF mẫu đơn (bộ chuyển HTML → PDF của Google có thể khác Chrome, nhất là vị trí con dấu chồng lên chữ ký) | Chụp màn hình PDF gửi em để chỉnh |
| 2 | Tốc độ: mỗi thao tác khoảng 1–3 giây; ký và duyệt lâu hơn vì phải tạo PDF | Báo em thao tác nào chậm quá 10 giây |
| 3 | Email khôi phục mật khẩu tới được hộp thư (kể cả mục Thư rác) | Kiểm tra ô "Địa chỉ giao diện" và "Email nhận thử" |
| 4 | Tải đơn Word (.docx) lên có chuyển thành PDF đúng không | Gửi em tệp Word bị lỗi |
| 5 | Chụp ảnh và chèn chữ ký trên iPhone | Ghi lại loại máy, phiên bản iOS |
| 6 | Thời gian băm mật khẩu: trong trình soạn thảo Apps Script, chạy hàm `benchmarkHash` | Nếu 3000 vòng mất trên 2 giây, báo em để giảm |

---

## Phần G. Sự cố thường gặp

- **Trang báo "Chưa cấu hình địa chỉ máy chủ"**: chưa dán URL vào `demo/js/config.js`, hoặc dán sai dòng.
- **"Không kết nối được máy chủ"**: kiểm tra lại bước A7. Phải chọn **Bất kỳ ai** và URL phải kết thúc bằng `/exec`.
- **Sửa mã mà ứng dụng không đổi**: mỗi lần sửa `Code.gs` phải làm như sau, giữ nguyên URL:
  1. Vào **Triển khai → Quản lý triển khai**.
  2. Bấm biểu tượng bút chì.
  3. Ở mục Phiên bản, chọn **Phiên bản mới** → **Triển khai**.
- **Giao diện vẫn là bản cũ sau khi cập nhật GitHub**: đợi 1–3 phút, rồi tắt hẳn ứng dụng và mở lại. Ứng dụng cũng tự báo "Có phiên bản mới – chạm để tải lại".
- **Quên mật khẩu `quantri`**: trong trình soạn thảo Apps Script, chọn hàm `resetPrimaryAdminPassword` → **Chạy**. Mật khẩu tạm hiện trong Nhật ký thực thi. Không sửa tay trong file Sheets.

---

## Phần H. Giới hạn hiện tại (nói rõ, không giả lập)

- **SmartCA:** chưa tích hợp vì chưa có tài khoản tích hợp từ VNPT. Hiện dùng chế độ **ảnh chữ ký – xác nhận nội bộ**. PDF luôn ghi rõ "không phải chữ ký số".
- **Đơn tải lên:** chữ ký được chèn vào PDF ngay trên điện thoại. Máy chủ ghi lại người ký, thời điểm và mã băm của tệp. Với đơn theo mẫu, máy chủ tự tạo PDF và đặt chữ ký.
- **Zalo và thông báo đẩy lên màn hình khóa:** chưa bật. Thông báo hiện trong ứng dụng và qua email.
- **Email:** Gmail cá nhân gửi tối đa khoảng 100 người nhận mỗi ngày. Khi hết hạn mức, email được giữ lại và tự gửi tiếp hôm sau.
- **Chưa có trong bản này** (thuộc Giai đoạn 3b):
  - báo cáo, sổ nghỉ điện tử, xuất Excel/PDF báo cáo,
  - thông báo của Ban Giám hiệu và thông báo định kỳ,
  - chuyển năm học tự động,
  - sao lưu tự động và gói tải về cho PHT,
  - trung tâm hỗ trợ,
  - sửa mẫu đơn trên giao diện.

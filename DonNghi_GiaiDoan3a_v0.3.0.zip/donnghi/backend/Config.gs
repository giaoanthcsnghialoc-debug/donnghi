/**
 * Config.gs – cấu hình môi trường (Script Properties) và cài đặt ứng dụng (Sheet AppSettings).
 * Mỗi môi trường DEMO/PROD là một dự án Apps Script riêng với Script Properties riêng.
 */

var DEFAULT_SETTINGS = {
  SCHOOL_NAME: 'TRƯỜNG THCS ...',
  SCHOOL_PARENT: 'UBND ...',
  SCHOOL_PLACE: '...',
  FRONTEND_URL: '',
  SIGN_MODE: 'NONE',            // NONE | IMAGE | SMARTCA – quản trị viên chính bật
  SESSION_IDLE_DAYS: '7',
  LOGIN_MAX_FAIL: '5',
  LOGIN_LOCK_MINUTES: '15',
  PBKDF2_ITER: '3000',
  EMAIL_RESERVE: '10',
  REMIND_HOURS: '4,12,24,48',
  EMAIL_TEST_WHITELIST: '',     // DEMO: chỉ gửi email tới các địa chỉ này
  STAMP_FILE_ID: '',
  STAMP_WIDTH_MM: '34',
  SIGNATURE_WIDTH_MM: '38',
  LOGO_WIDTH_MM: '20'
};

var PUBLIC_SETTING_KEYS = ['SCHOOL_NAME', 'SCHOOL_PARENT', 'SCHOOL_PLACE', 'SIGN_MODE', 'SESSION_IDLE_DAYS'];
var EDITABLE_SETTING_KEYS = ['SCHOOL_NAME', 'SCHOOL_PARENT', 'SCHOOL_PLACE', 'FRONTEND_URL', 'SIGN_MODE',
  'SESSION_IDLE_DAYS', 'LOGIN_MAX_FAIL', 'LOGIN_LOCK_MINUTES', 'EMAIL_RESERVE', 'REMIND_HOURS',
  'EMAIL_TEST_WHITELIST', 'STAMP_WIDTH_MM', 'SIGNATURE_WIDTH_MM', 'LOGO_WIDTH_MM'];

function cfg(key) {
  var v = PropertiesService.getScriptProperties().getProperty(key);
  if (v === null && key !== 'ENV') fail('CONFIG', 'Chưa thiết lập ' + key + '. Hãy chạy hàm thiết lập.');
  return v;
}

function envName() {
  return PropertiesService.getScriptProperties().getProperty('ENV') || 'DEMO';
}

function isDemo() {
  return envName() !== 'PROD';
}

function setting(key) {
  var row = db_find('AppSettings', function (r) { return r.key === key; });
  if (row) return row.value;
  return DEFAULT_SETTINGS[key] !== undefined ? DEFAULT_SETTINGS[key] : '';
}

function settingInt(key) {
  return parseInt(setting(key), 10) || parseInt(DEFAULT_SETTINGS[key], 10) || 0;
}

function setSetting(key, value, actorId) {
  var row = db_find('AppSettings', function (r) { return r.key === key; });
  if (row) db_update('AppSettings', row.id, { value: value }, actorId);
  else db_insert('AppSettings', { key: key, value: value }, actorId);
}

function rootFolder() {
  return DriveApp.getFolderById(cfg('ROOT_FOLDER_ID'));
}

/** Lấy (hoặc tạo) thư mục con theo đường dẫn dạng 'PDF/2026-2027/DXN-2026-0001'. */
function folderPath(path) {
  var f = rootFolder();
  String(path).split('/').filter(String).forEach(function (name) {
    var it = f.getFoldersByName(name);
    f = it.hasNext() ? it.next() : f.createFolder(name);
  });
  return f;
}

/**
 * LeaveCalc.gs – tính buổi và ngày nghỉ. Không phụ thuộc dữ liệu, kiểm thử được độc lập.
 * Quy tắc (đặc tả mục VII.4): 1 ngày = 2 buổi; tự loại thứ Bảy, Chủ nhật; không tự loại ngày lễ.
 */

function parseYmd(s) {
  var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(s || ''));
  if (!m) return null;
  var d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3]));
  if (d.getUTCMonth() !== +m[2] - 1) return null;
  return d;
}

function ymd(d) {
  return d.toISOString().slice(0, 10);
}

/**
 * Trả về {sessions, days, slots:['2026-11-23:AM', ...]} hoặc ném lỗi nếu dữ liệu sai.
 * startSession/endSession: 'AM' (sáng) | 'PM' (chiều).
 */
function calcLeave(startDate, startSession, endDate, endSession) {
  var s = parseYmd(startDate), e = parseYmd(endDate);
  if (!s || !e) fail('INVALID_DATE', 'Ngày nghỉ không hợp lệ.');
  if (['AM', 'PM'].indexOf(startSession) < 0 || ['AM', 'PM'].indexOf(endSession) < 0) fail('INVALID_DATE', 'Chọn buổi sáng hoặc chiều.');
  if (e < s) fail('INVALID_DATE', 'Ngày kết thúc phải sau hoặc bằng ngày bắt đầu.');
  if (+e === +s && startSession === 'PM' && endSession === 'AM') fail('INVALID_DATE', 'Trong cùng một ngày, buổi kết thúc phải sau buổi bắt đầu.');
  var spanDays = Math.round((e - s) / 86400000) + 1;
  if (spanDays > 366) fail('INVALID_DATE', 'Khoảng nghỉ quá dài (tối đa 1 năm).');
  var slots = [];
  for (var i = 0; i < spanDays; i++) {
    var d = new Date(s.getTime() + i * 86400000);
    var wd = d.getUTCDay();
    if (wd === 0 || wd === 6) continue;
    var key = ymd(d);
    var first = i === 0, last = i === spanDays - 1;
    if (!(first && startSession === 'PM')) slots.push(key + ':AM');
    if (!(last && endSession === 'AM')) slots.push(key + ':PM');
  }
  if (!slots.length) fail('INVALID_DATE', 'Khoảng thời gian chỉ gồm thứ Bảy, Chủ nhật nên không có buổi nghỉ nào.');
  return { sessions: slots.length, days: slots.length / 2, slots: slots };
}

/** Hai đơn có trùng ít nhất một buổi không. */
function leavesOverlap(a, b) {
  if (a.endDate < b.startDate || b.endDate < a.startDate) return false;
  var sa = calcLeaveSafe(a), sb = calcLeaveSafe(b);
  if (!sa || !sb) return false;
  var set = {};
  sa.slots.forEach(function (x) { set[x] = true; });
  return sb.slots.some(function (x) { return set[x]; });
}

function overlapSlots(a, b) {
  var sa = calcLeaveSafe(a), sb = calcLeaveSafe(b);
  if (!sa || !sb) return [];
  var set = {};
  sa.slots.forEach(function (x) { set[x] = true; });
  return sb.slots.filter(function (x) { return set[x]; });
}

function calcLeaveSafe(l) {
  try { return calcLeave(l.startDate, l.startSession, l.endDate, l.endSession); } catch (e) { return null; }
}

/** Mô tả thời gian nghỉ bằng tiếng Việt cho PDF và thông báo. */
function describePeriod(l) {
  var sv = { AM: 'sáng', PM: 'chiều' };
  if (l.startDate === l.endDate) {
    if (l.startSession === l.endSession) return 'Buổi ' + sv[l.startSession] + ' ngày ' + viDate(l.startDate);
    return 'Cả ngày ' + viDate(l.startDate);
  }
  return 'Từ ' + sv[l.startSession] + ' ngày ' + viDate(l.startDate) + ' đến ' + sv[l.endSession] + ' ngày ' + viDate(l.endDate);
}

function formatDays(n) {
  var x = Number(n) || 0;
  return (x % 1 === 0 ? String(x) : String(x).replace('.', ',')) + ' ngày';
}
